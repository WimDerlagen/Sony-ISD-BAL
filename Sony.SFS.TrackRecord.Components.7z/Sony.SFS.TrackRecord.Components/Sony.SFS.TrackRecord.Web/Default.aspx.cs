using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.DirectoryServices;
using System.Security;
using System.Security.Principal;
using System.Threading;
using Sony.SFS.TrackRecord.Components;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        TRContext context = TRContext.Current;

        HttpApplication app = context.Context.ApplicationInstance;

        TRApplication trapp = app as TRApplication;


        string[] roles = Roles.GetRolesForUser();
        if (roles.Length == 1)
            if (roles[0] == "Everyone")
                Entry.Text = "Onvoldoende toegangsrechten";
        //Imperonate user to access the AD
        RolePrincipal wp = (RolePrincipal)Thread.CurrentPrincipal;
        WindowsIdentity wi = (WindowsIdentity)wp.Identity;
        WindowsImpersonationContext wc = wi.Impersonate();

        //Membership.DeleteUser("EU\\NLDerlaW");

        string domainUserName = WindowsIdentity.GetCurrent().Name.Replace("\\", "/");


        //DirectorySearcher search = new DirectorySearcher("LDAP://eu.sony.com");

        //string searchFilter = "SAMAccountName=NLHarinM";
        
        //string commonName = string.Empty;

        //search.Filter = searchFilter;
        //search.PropertiesToLoad.Add("mail");

        //SearchResult res = search.FindOne();

        //commonName =
        //Path.Text = res.Properties["mail"][0].ToString();

//        System.DirectoryServices.DirectoryEntry dirEntry = new System.DirectoryServices.DirectoryEntry("LDAP://eu.sony.com");

        bool online = false;
        string _fullName = string.Empty;
        if (online)
        {
            System.DirectoryServices.DirectoryEntry dirEntry = new System.DirectoryServices.DirectoryEntry("WinNT://" + domainUserName);
            _fullName = dirEntry.Properties["FullName"].Value.ToString();
        }
        string[] _roles = Roles.GetRolesForUser();

        foreach (string s in _roles)
        {
            CN.Text += s;
            CN.Text += ", ";
        }

        Path.Text = _fullName;
        //CN.Text = _fullName;

        wc.Undo();
    }
}
