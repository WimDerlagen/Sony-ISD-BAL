using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Sony.SFS.TrackRecord.Controls;

public partial class System_Education_Disciplines_Default : System.Web.UI.Page
{

    protected void Page_Init(object sender, EventArgs e){}

    protected override bool OnBubbleEvent(object source, EventArgs args)
    {
        if (args is ButtonClickEventArgs)
        {
            ButtonClickEventArgs e = args as ButtonClickEventArgs;
            switch (e.ButtonType)
            {
                case IconButtonType.New:
                    ManageDisciplines.New();
                    break;
                case IconButtonType.Overview:
                    ManageDisciplines.SetOverview();
                    break;
                case IconButtonType.Delete:
                    ManageDisciplines.Delete();
                    break;
                case IconButtonType.Save:
                    ManageDisciplines.Save();
                    break;

            }
            return true;
        }
        return false;
    }
}
