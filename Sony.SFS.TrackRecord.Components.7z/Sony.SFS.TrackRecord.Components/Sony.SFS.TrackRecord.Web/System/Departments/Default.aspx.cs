using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Sony.SFS.TrackRecord.Controls;

public partial class System_Departments_Default : System.Web.UI.Page
{
    protected override bool OnBubbleEvent(object source, EventArgs args)
    {
        if (args is ButtonClickEventArgs)
        {
            ButtonClickEventArgs e = args as ButtonClickEventArgs;
            switch (e.ButtonType)
            {
                case IconButtonType.New:
                    list.New();
                    break;
                case IconButtonType.Overview:
                    list.SetOverview();
                    break;
                case IconButtonType.Delete:
                    list.Delete();
                    break;
                case IconButtonType.Save:
                    list.Save();
                    break;

            }
            return true;
        }
        return false;
    }
}
