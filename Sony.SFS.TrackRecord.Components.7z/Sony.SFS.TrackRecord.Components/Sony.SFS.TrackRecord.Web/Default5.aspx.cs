using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Default5 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Date1.Text = DateTime.Now.ToLongTimeString();
        Button Clicker = (Button) DateUpdater.FindControl("Clicker");
        Clicker.Click += new EventHandler(Clicker_Click);
    }

    void Clicker_Click(object sender, EventArgs e)
    {
        Label Date2 = (Label) DateUpdater.FindControl("Date2");
        Date2.Text = DateTime.Now.ToLongTimeString();
    }
}
