using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Services;
using System.Xml;
using System.Web.Services.Protocols;
using System.Web.Script.Services;


/// <summary>
/// Summary description for AjaxTest
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
[ScriptService]
public class AjaxTest : WebService
{
    
    
    public AjaxTest()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    [WebMethod]
    public string GetServerString()
    {
        return "Here's Johnny";
    }
}
