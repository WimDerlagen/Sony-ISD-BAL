using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

public partial class Report_Default : System.Web.UI.Page
{
    string url = "~/Report/Report.aspx?Report={0}";
    TRContext context = TRContext.Current; 

    protected void Page_Load(object sender, EventArgs e)
    {
        Rep1.Click += new EventHandler(Rep1_Click);
        Rep2.Click += new EventHandler(Rep2_Click);
        Rep3.Click += new EventHandler(Rep3_Click);
        Rep4.Click += new EventHandler(Rep4_Click);
        Rep5.Click += new EventHandler(Rep5_Click);
        Rep6.Click += new EventHandler(Rep6_Click);
        Rep7.Click += new EventHandler(Rep7_Click);
       

    }

    void Back_Click(object sender, EventArgs e)
    {
        
    }

    void Rep1_Click(object sender, EventArgs e)
    {
        string url1 = string.Format(url, (int) ReportType.WorkforcePositions);
        context.Redirect(url1);
    }

    void Rep2_Click(object sender, EventArgs e)
    {

    }

    void Rep3_Click(object sender, EventArgs e)
    {

    }

    void Rep4_Click(object sender, EventArgs e)
    {
    }

    void Rep5_Click(object sender, EventArgs e)
    {
        
    }

    void Rep6_Click(object sender, EventArgs e)
    {
        
    }

    void Rep7_Click(object sender, EventArgs e)
    {
        
    }
    
}
