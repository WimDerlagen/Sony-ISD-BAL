using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

public partial class Report_Report : System.Web.UI.Page
{
    TRContext context = TRContext.Current;
    protected void Page_Load(object sender, EventArgs e)
    {
        LoadReport();
       // PreRenderComplete += new EventHandler(Report_Report_PreRenderComplete);
     
    }

    /// <summary>
    /// The PreRender event is fired after Controls PreRender and CreateChildControls.
    /// The ReportViewer is initialized in the CreateChildControlMethod, so loading of the report should occur after this
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    void Report_Report_PreRenderComplete(object sender, EventArgs e)
    {
        LoadReport();
    }

    private void LoadReport()
    {
        switch (context.ReportType)
        {
            case ReportType.EGradings:
                break;
            case ReportType.EGradingsCrossTable:
                break;
            case ReportType.SexeDivision:
                break;
            case ReportType.WorkforceCrossTable:
                break;
            case ReportType.WorkforcePlayers:
                break;
            case ReportType.WorkforcePositions:
                Report.ReportName = "WorkforcePositions.rpt";
                //Report.LoadReport();
                break;
            case ReportType.WorkforceProgression:
                break;
        }
    }
}
