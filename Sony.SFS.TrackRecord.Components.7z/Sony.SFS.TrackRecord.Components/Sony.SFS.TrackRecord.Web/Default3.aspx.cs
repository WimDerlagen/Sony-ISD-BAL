using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Ratings1TableAdapters;
using RatingsDetailedTableAdapters;

using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared; 

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ConfigureCrystalReports(); 

    }

    private void ConfigureCrystalReports()
    {
        string reportPath = Server.MapPath("~/Reports/Report4.rpt");

        ReportDocument RatingsRep = new ReportDocument();

        RatingsRep.Load(reportPath);

        RatingsDetailed rds = new RatingsDetailed();
        vw_RatingsDetailedTableAdapter ta = new vw_RatingsDetailedTableAdapter();
        RatingsDetailed.vw_RatingsDetailedDataTable dt = ta.GetData();

        //DataTable table = Ratings1.vw_RatingOverviewDataTable;
        RatingsRep.SetDataSource((System.Data.DataTable) dt);

        CrystalReportViewer.ReportSource = RatingsRep;
        TextBox1.Text = "G";

        
    }

}
