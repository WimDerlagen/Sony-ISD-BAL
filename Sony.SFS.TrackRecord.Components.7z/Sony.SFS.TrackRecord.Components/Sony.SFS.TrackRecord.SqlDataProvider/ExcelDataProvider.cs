using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.Configuration.Provider;
using System.Web;
using System.Web.Configuration;
using System.Data.Odbc;
using System.Data;
using System.Data.Common;

using Sony.SFS.TrackRecord.Collections;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.SqlDataProvider
{
    public class ExcelDataProvider : CommonExcelDataProvider
    {
        private string _applicationName = "TrackRecord";
        private string _connectionString;
        private string _connectionStringName;

        #region initialization/provider

        public override string ApplicationName
        {
            get
            {
                return _applicationName;
            }
            set
            {
                _applicationName = value;
            }
        }

        public string ConnectionStringName
        {
            get { return _connectionStringName; }
            set { _connectionStringName = value; }
        }

        public override void Initialize(string name, NameValueCollection config)
        {
            // Verify that config isn't null
            if (config == null)
                throw new ArgumentNullException("config");

            // Assign the provider a default name if it doesn't have one
            if (String.IsNullOrEmpty(name))
                name = "ExcelDataProvider";

            // Add a default "description" attribute to config if the
            // attribute doesn't exist or is empty
            if (string.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description",
                    "Excel data provider");
            }

            // Call the base class's Initialize method
            base.Initialize(name, config);

            // Initialize _applicationName
            _applicationName = config["applicationName"];

            if (string.IsNullOrEmpty(_applicationName))
                _applicationName = "/";

            config.Remove("applicationName");

            // Initialize _connectionString
            string connect = config["connectionStringName"];

            if (String.IsNullOrEmpty(connect))
                throw new ProviderException
                    ("Empty or missing connectionStringName");

            config.Remove("connectionStringName");

            if (WebConfigurationManager.ConnectionStrings[connect] == null)
                throw new ProviderException("Missing connection string");

            _connectionString = WebConfigurationManager.ConnectionStrings[connect].ConnectionString;

            if (String.IsNullOrEmpty(_connectionString))
                throw new ProviderException("Empty connection string");

            // Throw an exception if unrecognized attributes remain
            if (config.Count > 0)
            {
                string attr = config.GetKey(0);
                if (!String.IsNullOrEmpty(attr))
                    throw new ProviderException
                        ("Unrecognized attribute: " + attr);
            }
        }

        protected DbConnection GetConnection(string filePath)
        {
            string conn = string.Format(_connectionString, filePath);

            DbProviderFactory factory = DbProviderFactories.GetFactory("System.Data.OleDb");

            DbConnection connection = factory.CreateConnection();
            connection.ConnectionString = conn;
            return connection;

        }

        #endregion

        #region count methods

        public override int GetDepartmentCount(string filePath)
        {
            using (DbConnection connection = GetConnection(filePath))
            {
                int recordCount = 0;

                using (DbCommand command = connection.CreateCommand())
                {
                    //select count from distinct selection
                    command.CommandText = "SELECT COUNT(*) AS Records FROM (SELECT DISTINCT [Afdelingsnummer], [Afdeling] FROM [Primusblad$]) As derTbl";

                    connection.Open();

                    using (DbDataReader dr = command.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            recordCount = (int)dr["Records"];
                        }
                    }
                }

                return recordCount;
            }
        }

        public override int GetFunctionCount(string filePath)
        {
            using (DbConnection connection = GetConnection(filePath))
            {
                int recordCount = 0;

                using (DbCommand command = connection.CreateCommand())
                {
                    //select count from distinct selection
                    command.CommandText = "SELECT COUNT(*) AS Records FROM (SELECT DISTINCT [Functie Omschrijving] FROM [Primusblad$]) As derTbl";

                    connection.Open();

                    using (DbDataReader dr = command.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            recordCount = (int)dr["Records"];
                        }
                    }
                }

                return recordCount;
            }
        }

        public override int GetEmployeeCount(string filePath)
        {
            using (DbConnection connection = GetConnection(filePath))
            {
                int recordCount = 0;

                using (DbCommand command = connection.CreateCommand())
                {
                    //select count from distinct selection
                    command.CommandText = "SELECT COUNT(*) AS Records FROM [Primusblad$]";

                    connection.Open();

                    using (DbDataReader dr = command.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            recordCount = (int)dr["Records"];
                        }
                    }
                }

                return recordCount;
            }
        }

        #endregion
        
        #region getters

        public override ArrayList GetFunctions(string filePath)
        {
            using (DbConnection connection = GetConnection(filePath))
            {
                //Hashtable ht = new Hashtable();
                ArrayList al = new ArrayList();


                using (DbCommand command = connection.CreateCommand())
                {
                    //select count from distinct selection
                    command.CommandText = "SELECT DISTINCT [Functie Omschrijving] FROM [Primusblad$]";

                    connection.Open();

                    using (DbDataReader dr = command.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            string functie = string.Empty;

                            functie = Translator.FirstCap(Convert.ToString(dr["Functie Omschrijving"]));

                            al.Add(functie);
                        }
                    }
                }

                return al;
            }
        }

        public override ArrayList GetDepartments(string filePath)
        {
            using (DbConnection connection = GetConnection(filePath))
            {
                //Hashtable ht = new Hashtable();
                ArrayList al = new ArrayList();

                
                using (DbCommand command = connection.CreateCommand())
                {
                    //select count from distinct selection
                    command.CommandText = "SELECT DISTINCT [Afdelingsnummer], [Afdeling] FROM [Primusblad$]";

                    connection.Open();

                    using (DbDataReader dr = command.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            int afdelingsNummer = -1;
                            bool numOK = Int32.TryParse(Convert.ToString(dr["Afdelingsnummer"]), out afdelingsNummer);
                            
                            string afdeling = string.Empty;
                            afdeling = Convert.ToString(dr["Afdeling"]);

                            Department dept = new Department();


                            if (numOK && afdeling != string.Empty)
                            {
                                dept.Name = afdeling;
                                dept.DepartmentNumber = afdelingsNummer;

                                al.Add(dept);
                                
                                
                            }
                            else
                            {
                                dept.Name = afdeling;

                                al.Add(dept);
                            }
                        }
                    }
                }

                return al;
            }
        }


        public override ArrayList GetEmployees(string filePath, RunningJob job)
        {
            using (DbConnection connection = GetConnection(filePath))
            {
                ArrayList al = new ArrayList();

                using (DbCommand command = connection.CreateCommand())
                {
                    //select count from distinct selection
                    command.CommandText = "SELECT * FROM [Primusblad$]";

                    connection.Open();

                    using (DbDataReader dr = command.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            al.Add(PopulatePrimusEmployee2FromDbReader(dr));

                            job.CurrentRecord++;
                            Jobs.UpdateJob(job);
                        }
                    }
                }

                return al;
            }
        }

        #endregion


    }
}
