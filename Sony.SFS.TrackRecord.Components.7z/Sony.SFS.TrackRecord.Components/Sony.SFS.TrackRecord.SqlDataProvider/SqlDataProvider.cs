using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.Configuration.Provider;
using System.Web;
using System.Web.Configuration;
using System.Data;
using System.Data.SqlClient;

using Sony.SFS.TrackRecord.Collections;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.SqlDataProvider
{
    public class SqlDataProvider : CommonDataProvider
    {
        #region provider
        private string _connectionString;
        private string _connectionStringName;

        protected string databaseOwner = "dbo";	// overwrite in web.config
        private string _applicationName = "TrackRecord";


        public override string ApplicationName
        {
            get { return _applicationName; }
            set { _applicationName = value; }
        }

        public string ConnectionStringName
        {
            get { return _connectionStringName; }
            set { _connectionStringName = value; }
        }

        public override void Initialize(string name, NameValueCollection config)
        {
            // Verify that config isn't null
            if (config == null)
                throw new ArgumentNullException("config");

            // Assign the provider a default name if it doesn't have one
            if (String.IsNullOrEmpty(name))
                name = "SqlDataProvider";

            // Add a default "description" attribute to config if the
            // attribute doesn't exist or is empty
            if (string.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description",
                    "SQL data provider");
            }

            // Call the base class's Initialize method
            base.Initialize(name, config);

            // Initialize _applicationName
            _applicationName = config["applicationName"];

            if (string.IsNullOrEmpty(_applicationName))
                _applicationName = "/";

            config.Remove("applicationName");

            // Initialize _connectionString
            string connect = config["connectionStringName"];

            if (String.IsNullOrEmpty(connect))
                throw new ProviderException
                    ("Empty or missing connectionStringName");

            config.Remove("connectionStringName");

            if (WebConfigurationManager.ConnectionStrings[connect] == null)
                throw new ProviderException("Missing connection string");

            //set connection string based on configuration
#if local
            _connectionString = WebConfigurationManager.ConnectionStrings
                ["TrackRecordLocal"].ConnectionString;
#endif

#if dev
            _connectionString = WebConfigurationManager.ConnectionStrings
                ["TrackRecordDev"].ConnectionString;
#endif

#if acc
            _connectionString = WebConfigurationManager.ConnectionStrings
                ["TrackRecordAcc"].ConnectionString;
#endif

#if prod
            _connectionString = WebConfigurationManager.ConnectionStrings
                [connect].ConnectionString;
#endif



            if (String.IsNullOrEmpty(_connectionString))
                throw new ProviderException("Empty connection string");

            // Throw an exception if unrecognized attributes remain
            if (config.Count > 0)
            {
                string attr = config.GetKey(0);
                if (!String.IsNullOrEmpty(attr))
                    throw new ProviderException
                        ("Unrecognized attribute: " + attr);
            }
        }

        protected SqlConnection GetSqlConnection()
        {

            try
            {
                return new SqlConnection(_connectionString);
            }
            catch
            {
                throw new Exception();
            }

        }

        #endregion


        #region crud methods

        public override void CreateUpdateDeleteSuggestion(Suggestion sugg, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteSuccessionSuggestion", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //
                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int)dpa;
                myCommand.Parameters.Add("@SuggestionID", SqlDbType.Int).Value = sugg.SuggestionId;
                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = sugg.EmployeeId;
                myCommand.Parameters.Add("@FunctionID", SqlDbType.Int).Value = sugg.FunctionId;
                myCommand.Parameters.Add("@Term", SqlDbType.Int).Value = sugg.Term;
                myCommand.Parameters.Add("@SetDate", SqlDbType.DateTime).Value = sugg.SetDate;
                myCommand.Parameters.Add("@DepartmentID", SqlDbType.Int).Value = sugg.DepartmentID;


                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteAmbitionChoice(AmbitionChoice choice, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteAmbitionChoice", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //
                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int) dpa;
                myCommand.Parameters.Add("@AmbitionChoice", SqlDbType.Int).Value = choice.AmbitionChoiceID;
                myCommand.Parameters.Add("@AmbitionTypeID", SqlDbType.Int).Value = choice.AmbitionTypeID;
                myCommand.Parameters.Add("@Choice", SqlDbType.VarChar, 100).Value = choice.Choice;

                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteAmbitionType(AmbitionType ambition, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteAmbitionType", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //
                
                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int) dpa;
                myCommand.Parameters.Add("@AmbitionTypeID", SqlDbType.Int).Value = ambition.AmbitionTypeID;
                myCommand.Parameters.Add("@AmbitionType", SqlDbType.VarChar, 100).Value = ambition.AmbitionTypeText;
                myCommand.Parameters.Add("@Description", SqlDbType.VarChar, 250).Value = ambition.Description;

                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteDepartment(Department department, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteDepartment", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //
                
                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int) dpa;
                myCommand.Parameters.Add("@DepartmentID", SqlDbType.Int).Value = department.DepartmentID;
                myCommand.Parameters.Add("@Name", SqlDbType.VarChar, 80).Value = department.Name;
                myCommand.Parameters.Add("@Description", SqlDbType.VarChar, 300).Value = department.Description;
                myCommand.Parameters.Add("@DepartmentNumber", SqlDbType.Int).Value = department.DepartmentNumber;


                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteEducationDiscipline(EducationDiscipline dis, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteEducationDiscipline", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //
                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int) dpa;
                myCommand.Parameters.Add("@EducationDisciplineID", SqlDbType.Int).Value = dis.EducationDisciplineID;
                myCommand.Parameters.Add("@Discipline", SqlDbType.VarChar, 50).Value = dis.Discipline;
                myCommand.Parameters.Add("@Description", SqlDbType.VarChar, 300).Value = dis.Description;

                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteEducationLevel(EducationLevel level, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteEducationLevel", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //
                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int) dpa;
                myCommand.Parameters.Add("@EducationLevelID", SqlDbType.Int).Value = level.EducationLevelID;
                myCommand.Parameters.Add("@Level", SqlDbType.VarChar, 50).Value = level.Level;
                myCommand.Parameters.Add("@Description", SqlDbType.VarChar, 200).Value = level.Description;

                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteEmployee(Employee employee, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteEmployee", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //

                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int) dpa;
                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = employee.EmployeeId;
                myCommand.Parameters.Add("@FirstName", SqlDbType.VarChar, 80).Value = employee.FirstName;
                myCommand.Parameters.Add("@MiddleName", SqlDbType.VarChar, 50).Value = employee.MiddleName;
                myCommand.Parameters.Add("@LastName", SqlDbType.VarChar, 80).Value = employee.LastName;
                myCommand.Parameters.Add("@Address1", SqlDbType.VarChar, 80).Value = employee.Address1;
                myCommand.Parameters.Add("@Address2", SqlDbType.VarChar, 80).Value = employee.Address2;
                myCommand.Parameters.Add("@ZipCode", SqlDbType.VarChar, 50).Value = employee.ZipCode;
                myCommand.Parameters.Add("@City", SqlDbType.VarChar, 80).Value = employee.City;
                myCommand.Parameters.Add("@Gender", SqlDbType.VarChar, 10).Value = employee.Gender;
                myCommand.Parameters.Add("@Birthdate", SqlDbType.DateTime).Value = employee.Birthdate;
                myCommand.Parameters.Add("@EmployeeSince", SqlDbType.DateTime).Value = employee.EmployeeSince;
                myCommand.Parameters.Add("@Ambition", SqlDbType.VarChar, 500).Value = employee.Ambition;


                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void FlushPrimusEmployees()
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeletePrimusEmplyee", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //
                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = 9;

                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }    

        public override void CreateUpdateDeletePrimusEmployee(PrimusEmployee employee, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeletePrimusEmplyee", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //

                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int)dpa;
                SqlParameter param = new SqlParameter("@PrimusID", SqlDbType.Int);
                param.Direction = ParameterDirection.InputOutput;
                param.Value = employee.PrimusId;
                myCommand.Parameters.Add(param);

                myCommand.Parameters.Add("@EmployeeNumber", SqlDbType.Int).Value = employee.EmployeeNumber;
                myCommand.Parameters.Add("@Aanhef", SqlDbType.Int).Value = employee.Aanhef;
                myCommand.Parameters.Add("@Roepnaam", SqlDbType.VarChar, 50).Value = employee.RoepNaam;
                myCommand.Parameters.Add("@Naam", SqlDbType.VarChar, 80).Value = employee.Naam;
                myCommand.Parameters.Add("@Straatnaam", SqlDbType.VarChar, 100).Value = employee.StraatNaam;
                myCommand.Parameters.Add("@Huisnummer", SqlDbType.Int).Value = employee.Huisnummer;
                myCommand.Parameters.Add("@HuisnummerToev", SqlDbType.VarChar, 10).Value = employee.HuisnummerToev;
                myCommand.Parameters.Add("@Postcode", SqlDbType.VarChar, 50).Value = employee.Postcode;
                myCommand.Parameters.Add("@Woonplaats", SqlDbType.VarChar, 80).Value = employee.Woonplaats;
                myCommand.Parameters.Add("@Land", SqlDbType.VarChar, 50).Value = employee.Land;
                myCommand.Parameters.Add("@GeboorteDatum", SqlDbType.DateTime).Value = employee.GeboorteDatum;
                myCommand.Parameters.Add("@DatumInDienst", SqlDbType.DateTime).Value = employee.DatumInDienst;
                myCommand.Parameters.Add("@DatumInDienstSony", SqlDbType.DateTime).Value = employee.DatumInDienstSony;
                myCommand.Parameters.Add("@Beroep", SqlDbType.VarChar, 80).Value = employee.Beroep;
                myCommand.Parameters.Add("@Afdelingsnummer", SqlDbType.Int).Value = employee.AfdelingsNummer;
                myCommand.Parameters.Add("@BusinessGroup", SqlDbType.VarChar, 50).Value = employee.BusinessGroep;
                myCommand.Parameters.Add("@FTE", SqlDbType.Decimal).Value = employee.FTE;
                myCommand.Parameters.Add("@FunctieOmschrijving", SqlDbType.VarChar, 200).Value = employee.FunctieOmschrijving;
                myCommand.Parameters.Add("@Nationaliteit", SqlDbType.Int).Value = employee.Nationaliteit;
                myCommand.Parameters.Add("@Vestiging", SqlDbType.Int).Value = employee.VestigingsNummer;
                myCommand.Parameters.Add("@Voorvoegsel", SqlDbType.VarChar, 50).Value = employee.Voorvoegsel;
                myCommand.Parameters.Add("@Remarks", SqlDbType.VarChar, 500).Value = employee.Remarks;
                myCommand.Parameters.Add("@EmployeeType", SqlDbType.Int).Value = employee.EmployeeType;

                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();

                if (dpa == DataProviderAction.Create)
                    employee.PrimusId = (int) param.Value;
            }
        }

        public override void CreateUpdateDeleteEmployeeAmbition(EmployeeAmbition ambition, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteEmployeeAmbition", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //
                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int)dpa;
                myCommand.Parameters.Add("@EmployeeAmbitionID", SqlDbType.Int).Value = ambition.EmployeeAmbitionID;
                myCommand.Parameters.Add("@AmbitionType", SqlDbType.Int).Value = ambition.AmbitionChoiceType;
                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = ambition.EmployeeID;
                myCommand.Parameters.Add("@AmbitionID", SqlDbType.Int).Value = ambition.AmbitionID;
                myCommand.Parameters.Add("@ChoiceID", SqlDbType.Int).Value = ambition.ChoiceID;
                myCommand.Parameters.Add("@AmbitionText", SqlDbType.VarChar, 100).Value = ambition.AmbitionText;

                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteEmployeeEducation(EmployeeEducation edu, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteEmployeeEducation", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //

                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int)dpa;
                myCommand.Parameters.Add("@EmployeeEducationID", SqlDbType.Int).Value = edu.EmployeeEducationID;
                myCommand.Parameters.Add("@LevelID", SqlDbType.Int).Value = edu.LevelID;
                myCommand.Parameters.Add("@DisciplineID", SqlDbType.Int).Value = edu.DisciplineID;
                myCommand.Parameters.Add("@StartDate", SqlDbType.DateTime).Value = edu.StartDate;
                myCommand.Parameters.Add("@EndDate", SqlDbType.DateTime).Value = edu.EndDate;
                myCommand.Parameters.Add("@Location", SqlDbType.VarChar, 100).Value = edu.Location;
                myCommand.Parameters.Add("@Description", SqlDbType.VarChar, 300).Value = edu.Description;
                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = edu.EmployeeID;
                myCommand.Parameters.Add("@EducationType", SqlDbType.Int).Value = (int) edu.EducationType;
                myCommand.Parameters.Add("@Completed", SqlDbType.Bit).Value = edu.Completed;
                myCommand.Parameters.Add("@Title", SqlDbType.VarChar, 50).Value = edu.Title;


                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }
      

        public override void CreateUpdateDeleteEmployeeFunction(EmployeeFunction function, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteEmployeeFunction", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //
      
                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int) dpa;
                myCommand.Parameters.Add("@EmployeeFunctionID", SqlDbType.Int).Value = function.EmployeeFunctionID;
                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = function.EmployeeID;
                myCommand.Parameters.Add("@FunctionID", SqlDbType.Int).Value = function.FunctionID;
                myCommand.Parameters.Add("@DepartmentID", SqlDbType.Int).Value = function.DepartmentID;
                myCommand.Parameters.Add("@StartDate", SqlDbType.DateTime).Value = function.StartDate;
                myCommand.Parameters.Add("@EndDate", SqlDbType.DateTime).Value = function.EndDate;
                myCommand.Parameters.Add("@PreferredDuration", SqlDbType.Int).Value = function.PreferredDuration;
                myCommand.Parameters.Add("@Current", SqlDbType.Bit).Value = function.Current;



                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteEmployeeLanguage(EmployeeLanguage language, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteEmployeeLanguage", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //
    
                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int) dpa;
                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = language.EmployeeID;
                myCommand.Parameters.Add("@LanguageID", SqlDbType.Int).Value = language.LanguageID;
                myCommand.Parameters.Add("@Writing", SqlDbType.Int).Value = language.Writing;
                myCommand.Parameters.Add("@Speaking", SqlDbType.Int).Value = language.Speaking;
              

                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteEmployeeSkills(int employeeId, int skillId, SkillLevel level, bool remove)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteEmployeeSkills", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //

                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = employeeId;
                myCommand.Parameters.Add("@SkillID", SqlDbType.Int).Value = skillId;
                myCommand.Parameters.Add("@SkillLevel", SqlDbType.Int).Value = (int) level;
                myCommand.Parameters.Add("@Remove", SqlDbType.Bit).Value = remove;

                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteRating(Rating rating, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteRating", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //

                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int) dpa;
                myCommand.Parameters.Add("@EmployeeRatingID", SqlDbType.Int).Value = rating.RatingId;
                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = rating.EmployeeId;
                myCommand.Parameters.Add("@RateDate", SqlDbType.DateTime).Value = rating.RateDate;
                myCommand.Parameters.Add("@Year", SqlDbType.VarChar, 50).Value = rating.Year;
                myCommand.Parameters.Add("@Rating", SqlDbType.Int).Value = rating.RatingValue;
                myCommand.Parameters.Add("@RatingType", SqlDbType.Int).Value = rating.RatingType;


                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteFunction(Function function, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteFunction", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //
                
                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int) dpa;
                myCommand.Parameters.Add("@FunctionID", SqlDbType.Int).Value = function.FunctionID;
                myCommand.Parameters.Add("@Title", SqlDbType.VarChar, 100).Value = function.Title;
                myCommand.Parameters.Add("@Description", SqlDbType.VarChar, 500).Value = function.Description;
                myCommand.Parameters.Add("@DesiredDuration", SqlDbType.Int).Value = function.DesiredDuration;
                myCommand.Parameters.Add("@Devision", SqlDbType.VarChar, 50).Value = function.Division;
                myCommand.Parameters.Add("@Department", SqlDbType.Int).Value = function.DepartmentID;
                myCommand.Parameters.Add("@Location", SqlDbType.VarChar, 50).Value = function.Location;
                myCommand.Parameters.Add("@Manages", SqlDbType.VarChar, 100).Value = function.Manages;
                myCommand.Parameters.Add("@FunctionRequirements", SqlDbType.VarChar, 500).Value = function.Requirements;
                myCommand.Parameters.Add("@FunctionGoals", SqlDbType.VarChar, 500).Value = function.FunctionGoals;
                myCommand.Parameters.Add("@Responsibilities", SqlDbType.VarChar, 500).Value = function.Responsibilities;
                myCommand.Parameters.Add("@KeyPerformanceIndicators", SqlDbType.VarChar, 500).Value = function.KeyPerformanceIndicators;
                myCommand.Parameters.Add("@Managing", SqlDbType.Bit).Value = function.Managing;


                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteImage(Image image, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteImage", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //

                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int) dpa;
                myCommand.Parameters.Add("@ImageID", SqlDbType.Int).Value = image.ImageId;
                myCommand.Parameters.Add("@Filename", SqlDbType.VarChar, 100).Value = image.Filename;

                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteLanguage(Language lang, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteLanguage", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //
                
                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int) dpa;
                myCommand.Parameters.Add("@LanguageID", SqlDbType.Int).Value = lang.LanguageId;
                myCommand.Parameters.Add("@Name", SqlDbType.VarChar, 50).Value = lang.Name;

                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteLicense(License license, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteLicense", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //

                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int) dpa;
                myCommand.Parameters.Add("@LicenseID", SqlDbType.Int).Value = license.LicenseId;
                myCommand.Parameters.Add("@License", SqlDbType.VarChar, 50).Value = license.LicenseName;

                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteSkill(Skill skill, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteSkill", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //
                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int) dpa;
                myCommand.Parameters.Add("@SkillID", SqlDbType.Int).Value = skill.SkillID;
                myCommand.Parameters.Add("@Name", SqlDbType.VarChar, 100).Value = skill.Name;
                myCommand.Parameters.Add("@Description", SqlDbType.VarChar, 300).Value = skill.Desciption;


                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteTraining(Training training, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteTraining", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //

                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int) dpa;
                myCommand.Parameters.Add("@TrainingID", SqlDbType.Int).Value = training.TrainigID;
                myCommand.Parameters.Add("@Training", SqlDbType.VarChar, 100).Value = training.TrainingName;


                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteWorkStyleRating(WorkstyleRating work, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_CreateUpdateDeleteWorkStyleRating", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //

                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int) dpa;
                myCommand.Parameters.Add("@WorkstyleRatingID", SqlDbType.Int).Value = work.WorkstyleId;
                myCommand.Parameters.Add("@Year", SqlDbType.VarChar,50).Value = work.Year;
                myCommand.Parameters.Add("@Rating", SqlDbType.Int).Value = work.Rating;
                myCommand.Parameters.Add("@Attachment", SqlDbType.VarChar, 100).Value = work.Attachment;
                myCommand.Parameters.Add("@EmployeeNumber", SqlDbType.Int).Value = work.EmployeeID;

                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteRunningJob(RunningJob job, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".CreateUpdateDeleteRunningJob", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //

                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int)dpa;
                myCommand.Parameters.Add("@JobID", SqlDbType.Int).Value = job.JobID;
                myCommand.Parameters.Add("@JobName", SqlDbType.VarChar, 50).Value = job.JobName;
                myCommand.Parameters.Add("@TotalRecords", SqlDbType.Int).Value = job.TotalRecords;
                myCommand.Parameters.Add("@CurrentRecord", SqlDbType.Int).Value = job.CurrentRecord;
                myCommand.Parameters.Add("@FileID", SqlDbType.Int).Value = job.FileID;
                myCommand.Parameters.Add("@Complete", SqlDbType.Bit).Value = job.Complete;
                myCommand.Parameters.Add("@Running", SqlDbType.Bit).Value = job.Running;
                myCommand.Parameters.Add("@Errors", SqlDbType.Int).Value = job.Errors;


                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override void CreateUpdateDeleteUploadedFile(UploadedFile file, DataProviderAction dpa)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".CreateUpdateDeleteUploadedFile", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Set the parameters
                //

                myCommand.Parameters.Add("@Action", SqlDbType.Int).Value = (int)dpa;
                myCommand.Parameters.Add("@FilePath", SqlDbType.VarChar, 300).Value = file.FilePath;
                myCommand.Parameters.Add("@FileName", SqlDbType.VarChar, 100).Value = file.FileName;
                myCommand.Parameters.Add("@FileType", SqlDbType.Int).Value = file.FileType;
                myCommand.Parameters.Add("@Delimiter", SqlDbType.VarChar, 10).Value = file.Delimiter;
                myCommand.Parameters.Add("@FileRead", SqlDbType.Bit).Value = file.FileRead;
                myCommand.Parameters.Add("@Processed", SqlDbType.Bit).Value = file.Processed;
                myCommand.Parameters.Add("@ImportType", SqlDbType.Int).Value = file.ImportType;

                SqlParameter param1 = new SqlParameter("@FileID", SqlDbType.Int, 4);
                param1.Direction = ParameterDirection.InputOutput;
                myCommand.Parameters.Add(param1);


                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close(); 


                file.FileID = (int) param1.Value;
            }
        }

        #endregion

        #region getter methods

        public override Suggestion GetSuggestion(int suggestionId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetSuggestion", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                Suggestion sugg = new Suggestion();

                // Set parameters
                //
                myCommand.Parameters.Add("@SuggestionID", SqlDbType.Int).Value = suggestionId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        sugg = PopulateSuggestionFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return sugg;
            }
        }

        public override List<Suggestion> GetSuggestionsByFunction(int functionId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetSuggestionsByFunctionID", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<Suggestion> suggestions = new List<Suggestion>();

                myCommand.Parameters.Add("@FunctionID", SqlDbType.Int).Value = functionId;


                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        suggestions.Add(PopulateSuggestionFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return suggestions;
            }
        }

        public override List<Suggestion> GetSuggestions(int employeeId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetSuggestions", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<Suggestion> suggestions = new List<Suggestion>();

                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = employeeId;


                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        suggestions.Add(PopulateSuggestionFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return suggestions;
            }
        }

        public override AmbitionType GetAmbition(int ambitionId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetAmbitionType", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                AmbitionType amb = new AmbitionType();

                // Set parameters
                //
                myCommand.Parameters.Add("@AmbitionTypeID", SqlDbType.Int).Value = ambitionId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        amb = PopulateAmbitionTypeFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return amb;
            }
        }

        public override List<AmbitionType> GetAmbitions()
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetAmbitionTypes", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<AmbitionType> ambitions = new List<AmbitionType>();



                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        ambitions.Add(PopulateAmbitionTypeFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return ambitions;
            }
        }

        public override AmbitionChoice GetAmbitionChoice(int Id)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetAmbitionChoice", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                AmbitionChoice amb = null;

                // Set parameters
                //
                myCommand.Parameters.Add("@AmbitionChoiceID", SqlDbType.Int).Value = Id;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        amb = PopulateAmbitionChoiceFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return amb;
            }
        }

        public override List<AmbitionChoice> GetAmbitionChoices(int ambitionTypeId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetAmbitionChoices", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<AmbitionChoice> ambitions = new List<AmbitionChoice>();
                myCommand.Parameters.Add("@AmbitionTypeID", SqlDbType.Int).Value = ambitionTypeId;



                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        ambitions.Add(PopulateAmbitionChoiceFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return ambitions;
            }
        }

        public override bool DepartmentExists(int departmentNumber)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_DepartmentExists", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                Department dep = null;

                myCommand.Parameters.Add("@DepartmentNumber", SqlDbType.Int).Value = departmentNumber;
                SqlParameter param = new SqlParameter("@Exists", SqlDbType.Bit);
                param.Direction = ParameterDirection.Output;
                myCommand.Parameters.Add(param);

                // Execute the command
                //
                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();

                return (bool) param.Value;
            }
        }

        public override Department GetDepartment(int departmentNumber)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetDepartment", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                Department dep = null;

                myCommand.Parameters.Add("@DepartmentNumber", SqlDbType.Int).Value = departmentNumber;

                
                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        dep = PopulateDepartmentTypeFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return dep;
            }
        }

        public override void FlushDepartments()
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_FlushDepartments", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                // Execute the command
                //
                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        public override List<Department> GetDepartments()
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetAllDepartments", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<Department> departments = new List<Department>();
                
                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        departments.Add(PopulateDepartmentTypeFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return departments;
            }
        }

        public override EducationDiscipline GetEducationDiscipline(int disciplineId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEducationDiscipline", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                EducationDiscipline dis = null;

                myCommand.Parameters.Add("@DisciplineID", SqlDbType.Int).Value = disciplineId;
                
                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        dis = PopulateEducationDisciplineTypeFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return dis;
            }
        }

        public override List<IAutoDropDownItem> GetEducationDisciplines()
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEducationDisciplines", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<IAutoDropDownItem> diss = new List<IAutoDropDownItem>();

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        diss.Add(PopulateEducationDisciplineTypeFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return diss;
            }
        }

        public override EducationLevel GetEducationLevel(int levelId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEducationLevel", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                EducationLevel level = null;

                myCommand.Parameters.Add("@LevelID", SqlDbType.Int).Value = levelId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        level = PopulateEducationLevelFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return level;
            }
        }

        public override List<IAutoDropDownItem> GetEducationLevels()
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEducationLevels", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<IAutoDropDownItem> levels = new List<IAutoDropDownItem>();

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        levels.Add(PopulateEducationLevelFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return levels;
            }
        }

        public override bool EmployeeExists(int employeeNumber)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_EmployeeExists", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                bool exists = false;

                myCommand.Parameters.Add("@EmployeeNumber", SqlDbType.Int).Value = employeeNumber;

                // Execute the command
                //
                myConnection.Open();
                object does = myCommand.ExecuteScalar();
                myConnection.Close();

                exists = Convert.ToBoolean(does);
                return exists;
            }
        }

        public override bool EmployeeFunctionChanged(string employeeFunction, int employeeNumber)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_EmployeeFunctionChanged", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                bool exists = false;

                myCommand.Parameters.Add("@EmployeeNumber", SqlDbType.Int).Value = employeeNumber;
                myCommand.Parameters.Add("@EmployeeFunction", SqlDbType.VarChar, 100).Value = employeeFunction;


                // Execute the command
                //
                myConnection.Open();
                object does = myCommand.ExecuteScalar();
                myConnection.Close();

                exists = Convert.ToBoolean(does);
                return exists;
            }
        }


        public override PrimusEmployee GetEmployee(int employeeNumber)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployee", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                PrimusEmployee emp = null;

                myCommand.Parameters.Add("@EmployeeNumber", SqlDbType.Int).Value = employeeNumber;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        emp = PopulatePrimusEmployeeFromIReader(reader);
                              

                    reader.Close();
                }

                myConnection.Close();

                return emp;
            }
        }
        public override void GetEmployeesRatings(PrimusEmployee employee)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeesRatings", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                PrimusEmployee emp = null;

                myCommand.Parameters.Add("@EmployeeNumber", SqlDbType.Int).Value = employee.EmployeeNumber;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        PopulateEmployeeRatingsFromIDataReader(reader, employee);


                    reader.Close();
                }

                myConnection.Close();

            }
        }

        public override EmployeeAmbition GetEmployeeAmbition(int ambitionId)
        {
             using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeAmbition", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                EmployeeAmbition amb = null;

                myCommand.Parameters.Add("@EmployeeAmbitionID", SqlDbType.Int).Value = ambitionId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        amb = PopulateEmployeeAmbitionFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return amb;
            }
        }

        public override List<EmployeeAmbition> GetEmployeeAmbitions(int employeeId, AmbitionChoiceType type)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeAmbitions", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<EmployeeAmbition> ambitions = new List<EmployeeAmbition>();

                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = employeeId;
                myCommand.Parameters.Add("@AmbitionType", SqlDbType.Int).Value = (int) type;


                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        ambitions.Add(PopulateEmployeeAmbitionFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return ambitions;
            }
        }

        public override EmployeeEducation GetEmployeeEducation(int eduId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeEducation", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                EmployeeEducation edu = null;

                myCommand.Parameters.Add("@EmployeeEducationID", SqlDbType.Int).Value = eduId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        edu = PopulateEmployeeEducationFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return edu;
            }
        }

        public override EmployeeEducation GetEmployeeAssessment(int employeeId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeAssessment", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                EmployeeEducation edu = null;

                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = employeeId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        edu = PopulateEmployeeEducationFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return edu;
            }
        }

        public override System.Collections.ArrayList GetEmployeeEducations(int employeeId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeEducations", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                ArrayList edus = new ArrayList();

                myCommand.Parameters.Add("@EmployeeNumber", SqlDbType.Int).Value = employeeId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        edus.Add(PopulateEmployeeEducationFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return edus;
            }
        }

        public override EmployeeFunction GetEmployeeFunction(int employeefunctionId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeFunction", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                EmployeeFunction func = null;

                myCommand.Parameters.Add("@EmployeeFunctionID", SqlDbType.Int).Value = employeefunctionId;


                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        func = PopulateEmployeeFunctionFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return func;
            }
        }

        public override EmployeeFunction GetCurrentEmployeeFunction(int employeeId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeFunction", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                EmployeeFunction func = null;

                myCommand.Parameters.Add("@EmployeeNumber", SqlDbType.Int).Value = employeeId;
                myCommand.Parameters.Add("@Current", SqlDbType.Bit).Value = true;
                
                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        func = PopulateEmployeeFunctionFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return func;
            }
        }

        public override ArrayList GetEmployeeFunctions(int employeeNumber, bool withCurrent)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeFunction", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                ArrayList funcs = new ArrayList();

                myCommand.Parameters.Add("@EmployeeNumber", SqlDbType.Int).Value = employeeNumber;
                myCommand.Parameters.Add("@WithCurrent", SqlDbType.Bit).Value = withCurrent;


                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        funcs.Add(PopulateEmployeeFunctionFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return funcs;
            }
        }

        public override EmployeeLanguage GetEmployeeLanguage(int employeeId, int languageId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeLanguages", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                EmployeeLanguage lang = null;

                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = employeeId;
                myCommand.Parameters.Add("@LanguageID", SqlDbType.Int).Value = languageId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        lang = PopulateEmployeeLanguageFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return lang;
            }
        }

        public override ArrayList GetLanguagesEmployees(int languageId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeLanguages", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                ArrayList langs = null;

                myCommand.Parameters.Add("@LanguageID", SqlDbType.Int).Value = languageId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        langs.Add(PopulateEmployeeLanguageFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return langs;
            }
        }

        public override List<EmployeeLanguage> GetEmployeeLanguages(int employeeId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeLanguages", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<EmployeeLanguage> langs = null;

                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = employeeId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        langs.Add(PopulateEmployeeLanguageFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return langs;
            }
        }

        public override Rating GetEmployeeRating(int ratingId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeRating", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                Rating rating = null;

                myCommand.Parameters.Add("@RatingID", SqlDbType.Int).Value = ratingId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        rating = PopulateRatingFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return rating;
            }
        }

        public override Rating GetEmployeeRating(int employeeID, RatingType type, string fiscalYear)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeRatingByYear", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                Rating rating = null;
             
                myCommand.Parameters.Add("@EmployeeNumber", SqlDbType.Int).Value = employeeID;
                myCommand.Parameters.Add("@RatingType", SqlDbType.Int).Value = type;
                myCommand.Parameters.Add("@FiscalYear", SqlDbType.VarChar, 50).Value = fiscalYear;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        rating = PopulateRatingFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return rating;
            }
        }

        public override List<Rating> GetEmployeesRatings(int employeeNumber, RatingType type)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeRatings", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<Rating> ratings = new List<Rating>();

                myCommand.Parameters.Add("@EmployeeNumber", SqlDbType.Int).Value = employeeNumber;
                myCommand.Parameters.Add("@RatingType", SqlDbType.Int).Value = (int) type;


                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        ratings.Add(PopulateRatingFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return ratings;
            }
        }

        public override Sony.SFS.TrackRecord.Collections.EmployeeSet GetEmployees(int pageIndex, int pageSize, SortEmployeesBy sortBy, SortOrder sortOrder, bool returnRecordCount)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployees", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                EmployeeSet inSet = new EmployeeSet();

                // Set parameters
                //
                myCommand.Parameters.Add("@PageIndex", SqlDbType.Int).Value = pageIndex;
                myCommand.Parameters.Add("@PageSize", SqlDbType.Int).Value = pageSize;
                myCommand.Parameters.Add("@SortBy", SqlDbType.Int).Value = (int)sortBy;
                myCommand.Parameters.Add("@SortOrder", SqlDbType.Int).Value = (int)sortOrder;
                myCommand.Parameters.Add("@ReturnRecordCount", SqlDbType.Bit).Value = returnRecordCount;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {

                    // Get the results
                    //
                    while (reader.Read())
                        inSet.Items.Add(PopulatePrimusEmployeeFromIReader(reader));

                    // Are we expecting more results?
                    //
                    if ((returnRecordCount) && (reader.NextResult()))
                    {
                        reader.Read();

                        // Read the value
                        //
                        inSet.TotalRecords = (int)reader[0];
                    }
                    reader.Close();
                }

                myConnection.Close();

                return inSet;
            }
        }

        public override ArrayList GetEmployeesByLastName(string lastName)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeesByLastName", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                ArrayList list = new ArrayList();

                // Set parameters
                //
                myCommand.Parameters.Add("@LastName", SqlDbType.VarChar, 100).Value = lastName;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {

                    // Get the results
                    //
                    while (reader.Read())
                        list.Add(PopulatePrimusEmployeeFromIReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return list;
            }
        }

        public override EmployeeSkill GetEmployeeSkill(int employeeId, int skillId)
        {
           using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeSkill", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                EmployeeSkill skill = null;

                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = employeeId;
                myCommand.Parameters.Add("@SkillID", SqlDbType.Int).Value = skillId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        skill = PopulateEmployeeSkillFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return skill;
            }
        }

        public override List<EmployeeSkill> GetEmployeeSkills(int employeeId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeSkills", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<EmployeeSkill> skills = null;

                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = employeeId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        skills.Add(PopulateEmployeeSkillFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return skills;
            }
        }

        public override Function GetFunctionByName(string functionName)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetFunctionByName", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                Function function = null;

                myCommand.Parameters.Add("@Name", SqlDbType.VarChar, 100).Value = functionName;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        function = PopulateFunctionFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return function;
            }
        }

        public override Function GetFunction(int functionId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetFunction", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                Function function = null;

                myCommand.Parameters.Add("@FunctionID", SqlDbType.Int).Value = functionId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        function = PopulateFunctionFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return function;
            }
        }

        public override bool FunctionExists(string function)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_FunctionExists", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                bool exists = false;

                myCommand.Parameters.Add("@Name", SqlDbType.VarChar, 100).Value = function;

                // Execute the command
                //
                myConnection.Open();
                object ex = myCommand.ExecuteScalar();
                myConnection.Close();

                try
                {
                    exists = Convert.ToBoolean(ex);
                }
                catch 
                {
                    string tst = "tst";
                }

                return exists;
            }
        }

        public FunctionSet GetFunctions()
        {
            return GetFunctions(0, 0, SortFunctionsBy.Title, SortOrder.Ascending, true);
        }

        public override FunctionSet GetFunctions(int pageIndex, int pageSize, SortFunctionsBy sortBy, SortOrder sortOrder, bool returnRecordCount)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetFunctions", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                FunctionSet fset = new FunctionSet();

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        fset.Items.Add(PopulateFunctionFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return fset;
            }
        }

        public override Image GetImage(int imageId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetImage", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                Image img = null;

                myCommand.Parameters.Add("@ImageID", SqlDbType.Int).Value = imageId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        img = PopulateImageFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return img;
            }
        }

        public override Language GetLanguage(int languageId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetLanguage", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                Language lang = null;

                myCommand.Parameters.Add("@LanguageID", SqlDbType.Int).Value = languageId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        lang = PopulateLanguageFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return lang;
            }
        }

        public override List<Language> GetLanguages()
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetLanguages", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<Language> langs = new List<Language>();

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        langs.Add(PopulateLanguageFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return langs;
            }
        }

        public override License GetLicense(int licenseId)
        {
            
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetLicense", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                License lic = null;

                myCommand.Parameters.Add("@LicenseID", SqlDbType.Int).Value = licenseId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        lic = PopulateLicenseFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return lic;
            }
        }

        public override List<License> GetLicenses()
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetAllLicenses", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<License> lic = null;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        lic.Add(PopulateLicenseFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return lic;
            }
        }

        public override List<License> GetLicenses(int employeeId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetLicenses", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<License> lic = null;
                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = employeeId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        lic.Add(PopulateLicenseFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return lic;
            }
        }

        public override Skill GetSkill(int skillId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetSkill", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                Skill skill = null;

                myCommand.Parameters.Add("@SkillID", SqlDbType.Int).Value = skillId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        skill = PopulateSkillFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return skill;
            }
        }

        public override List<Skill> GetSkills()
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetSkills", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<Skill> skills = new List<Skill>();

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        skills.Add(PopulateSkillFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return skills;
            }
        }

         

        public override Training GetTraining(int trainingId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetTraining", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                Training train = null;

                myCommand.Parameters.Add("@TrainingID", SqlDbType.Int).Value = trainingId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        train = PopulateTrainingFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return train;
            }
        }

        public override List<Training> GetTrainings()
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetTrainings", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<Training> trains = new List<Training>();

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        trains.Add(PopulateTrainingFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return trains;
            }
        }

        public override List<Training> GetEmployeeTrainings(int employeeId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetEmployeeTrainigs", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                List<Training> trains = null;
                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = employeeId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        trains.Add(PopulateTrainingFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return trains;
            }
        }
        public override WorkstyleRating GetWorkStyleRating(int workstyleId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetWorkstyleRating", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                WorkstyleRating rate = null;

                myCommand.Parameters.Add("@WorkstyleRatingID", SqlDbType.Int).Value = workstyleId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        rate = PopulateWorkstyleRatingFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return rate;
            }
        }

        public override WorkstyleRating GetWorkStyleRating(string fiscalYear, int employeeId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetWorkstyleRatingByFiscalYear", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                WorkstyleRating rate = null;

                myCommand.Parameters.Add("@FiscalYear", SqlDbType.VarChar, 50).Value = fiscalYear;
                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = employeeId;


                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        rate = PopulateWorkstyleRatingFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return rate;
            }
        }

        public override ArrayList GetWorkstyleRatings(int employeeNumber)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetWorkstyleRatings", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                ArrayList rates = new ArrayList();
                myCommand.Parameters.Add("@EmployeeNumber", SqlDbType.Int).Value = employeeNumber;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        rates.Add(PopulateWorkstyleRatingFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return rates;
            }
        }

        public override WorkstyleRating GetLatestWorkstyleRating(int employeeId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_GetLatestWorkstyleRating", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                WorkstyleRating rate = null;

                myCommand.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = employeeId;

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        rate = PopulateWorkstyleRatingFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return rate;
            }
        }


        public override RunningJob GetRunningJob(int jobId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".GetRunningJob", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                RunningJob job = null;

                myCommand.Parameters.Add("@JobID", SqlDbType.Int).Value = jobId;


                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        job = PopulateRunningJobFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return job;
            }
        }

       

        public override ArrayList GetPendingJobs()
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".GetPendingJobs", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                ArrayList jobs = new ArrayList();

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        jobs.Add(PopulateRunningJobFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return jobs;
            }
        }


        public override UploadedFile GetUploadedFile(int fileId)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".GetUploadedFile", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                UploadedFile file = null;

                myCommand.Parameters.Add("@FileID", SqlDbType.Int).Value = fileId;


                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        file = PopulateUploadedFileFromIDataReader(reader);

                    reader.Close();
                }

                myConnection.Close();

                return file;
            }
        }

        public override ArrayList GetUploadedFiles()
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".GetUploadedFiles", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                ArrayList files = new ArrayList();

                // Execute the command
                //
                myConnection.Open();
                using (SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    // Get the results
                    //
                    while (reader.Read())
                        files.Add(PopulateUploadedFileFromIDataReader(reader));

                    reader.Close();
                }

                myConnection.Close();

                return files;
            }
        }



        public override void ReportError(int jobId, string error)
        {
            using (SqlConnection myConnection = GetSqlConnection())
            {
                SqlCommand myCommand = new SqlCommand(databaseOwner + ".tr_ReportImportError", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                ArrayList files = new ArrayList();

                myCommand.Parameters.Add("@JobID", SqlDbType.Int).Value = jobId;
                myCommand.Parameters.Add("@ErrorMessage", SqlDbType.VarChar, 300).Value = error;


                // Execute the command
                //
                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
        }

        #endregion


    }
}
