using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.Profile;


namespace Sony.SFS.TrackRecord.SqlDataProvider
{
    public class SqlCustomProfileProvider : SqlProfileProvider
    {
        public override void Initialize(string name, System.Collections.Specialized.NameValueCollection config)
        {
            //System.Collections.Specialized.NameValueCollection config1 = new System.Collections.Specialized.NameValueCollection();
            //config1.Add("applicationName", "/TrackRecord");
            config.Remove("connectionStringName");

#if local
            config.Add("connectionStringName", "TrackRecordLocal");
#endif

#if dev
            config.Add("connectionStringName", "TrackRecordDev");
#endif

#if acc
            config.Add("connectionStringName", "TrackRecordAcc");
#endif


            base.Initialize(name, config);
        }
    }
}
