using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Controls
{
    public class CrudOverviewStatusChangedEventArgs : EventArgs
    {
        private CrudOverviewStatus status;

        public CrudOverviewStatus Status
        {
            get { return status; }
            set { status = value; }
        }

        public CrudOverviewStatusChangedEventArgs(CrudOverviewStatus status)
        {
            this.status = status;
        }
    }
}
