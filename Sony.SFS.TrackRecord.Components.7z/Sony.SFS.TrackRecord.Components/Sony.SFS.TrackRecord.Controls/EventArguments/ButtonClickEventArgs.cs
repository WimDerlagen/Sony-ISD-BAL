using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Controls
{
    public class ButtonClickEventArgs : EventArgs
    {
        private IconButtonType buttonType;

        public IconButtonType ButtonType
        {
            get { return this.buttonType; }
            set { this.buttonType = value; }
        }

        public ButtonClickEventArgs() { }

        public ButtonClickEventArgs(IconButtonType type)
        {
            buttonType = type;
        }

    }
}
