using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class ThemedImageButton : System.Web.UI.WebControls.ImageButton
    {
        protected override void Render(HtmlTextWriter writer)
        {
            this.ImageUrl = this.ResolveUrl(Globals.GetSkinPath() + this.ImageUrl);
            base.Render(writer);
        }
    }
}
