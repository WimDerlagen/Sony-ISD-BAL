using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;
using AjaxControlToolkit;

namespace Sony.SFS.TrackRecord.Controls
{
    public class AutoCompleteBox : TemplatedWebControl
    {
        TextBox AutoCompleter;
        AutoCompleteExtender autoComplete1;

        public string Text
        {
            get { return AutoCompleter.Text; }
            set { AutoCompleter.Text = value; }
        }

        public int Value
        {
            get {
                if (Text != string.Empty)
                {
                    
                    List<IAutoDropDownItem> edd = GetObjects();

                    foreach (IAutoDropDownItem ed in edd)
                    {
                        if (Text == ed.Text)
                            return ed.Value;
                    }
                }

                return 0;
            }
            set
            {
                switch (AutoCompleteType)
                {
                    case AutoDropDownType.EducationDiscipline:
                        EducationDiscipline edu = StemDataService.GetEducationDiscipline(value);
                        Text = edu.Text;
                        break;
                    case AutoDropDownType.EducationLevel:
                        EducationLevel elu = StemDataService.GetEducationLevel(value);
                        Text = elu.Text;
                        break;
                }
            }
           
        }

        private List<IAutoDropDownItem> GetObjects()
        {
            switch (AutoCompleteType)
            {
                case AutoDropDownType.EducationDiscipline:
                    return StemDataService.GetEducationDisciplines();
                case AutoDropDownType.EducationLevel:
                    return StemDataService.GetEducationLevels();
                default:
                    return null;
            }
        }

        public AutoDropDownType AutoCompleteType
        {
            get
            {
                object s = ViewState["AutoDropDownType"];

                if (s == null)
                {
                    s = AutoDropDownType.EducationDiscipline;

                    ViewState["AutoDropDownType"] = AutoDropDownType.EducationDiscipline;
                }

                return (AutoDropDownType) s;
            }
            set {ViewState["AutoDropDownType"] = value;}
        }

        protected override void AttachChildControls()
        {
            AutoCompleter = (TextBox)FindControl("AutoCompleter");
            autoComplete1 = (AutoCompleteExtender)FindControl("autoComplete1");

            InitializeControls();
        }

        private void InitializeControls()
        {
            

            switch (AutoCompleteType)
            {
                case AutoDropDownType.EducationDiscipline:
                    //autoComplete1.ServicePath = string.Format("~/AutoComplete.asmx?op=GetEducationDisciplines", (int)AutoCompleteType);

                    //autoComplete1.ServiceMethod = " ";

                    autoComplete1.ServicePath = "~/AutoComplete.asmx";//string.Format(, (int)AutoCompleteType);

                    autoComplete1.ServiceMethod = "GetEducationDisciplines";
                    break;

                case AutoDropDownType.EducationLevel:
                    autoComplete1.ServicePath = string.Format("~/AutoComplete.asmx", (int)AutoCompleteType);

                    autoComplete1.ServiceMethod = "GetEducationLevels";
                    break;
            }

        }

    }
}
