using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Text;

namespace Sony.SFS.TrackRecord.Controls
{
    public class YesNoRadioButtonList : RadioButtonList
    {
        public YesNoRadioButtonList()
        {
            this.Items.Clear();
            ListItem yes = new ListItem();
            yes.Text = "Yes";
            yes.Value = "True";

            ListItem no = new ListItem();
            no.Text = "No";
            no.Value = "False";

            this.Items.Add(yes);
            this.Items.Add(no);
        }

        public bool SelectedAnswer
        {
            get
            {
                return Convert.ToBoolean(this.SelectedValue);
            }
        }

        public void Select(bool value)
        {
            
            if (value)
                this.SelectedIndex = 0;
            else
                this.SelectedIndex = 1;

        }
    }
}
