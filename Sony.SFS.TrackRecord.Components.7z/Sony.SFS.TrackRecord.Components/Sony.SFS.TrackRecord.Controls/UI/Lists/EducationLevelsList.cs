using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class EducationLevelsList : TemplatedWebControl
    {
        RepeaterPlusNone EducationLevels;

        protected override void AttachChildControls()
        {
            EducationLevels = (RepeaterPlusNone)FindControl("EducationLevels");    


            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            EducationLevels.ItemDataBound += new RepeaterItemEventHandler(EducationLevels_ItemDataBound);
            EducationLevels.ItemCommand += new RepeaterCommandEventHandler(EducationLevels_ItemCommand);

            this.DataBind();
        }

        void EducationLevels_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item ||e.Item.ItemType == ListItemType.AlternatingItem)
            {
                Literal LevelID = (Literal) e.Item.FindControl("LevelID");
                LinkButton Name = (LinkButton) e.Item.FindControl("Name");
                Literal Description = (Literal)e.Item.FindControl("Description");

                EducationLevel level = (EducationLevel)e.Item.DataItem;

                LevelID.Text = level.EducationLevelID.ToString();
                Name.Text = level.Level;
                Description.Text = level.Description;

                Name.CommandName = "select";
                Name.CommandArgument = level.EducationLevelID.ToString();
            }
        }

        void EducationLevels_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            //Get siteUrls

            switch (e.CommandName)
            {
                case "select":
                    int levelId = Convert.ToInt32(e.CommandArgument);

                    //redirect to crud
                    break;
            }
        }

       
    }
}
