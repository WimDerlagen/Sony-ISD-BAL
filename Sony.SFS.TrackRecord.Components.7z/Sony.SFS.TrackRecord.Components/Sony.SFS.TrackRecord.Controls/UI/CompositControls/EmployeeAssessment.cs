using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;


namespace Sony.SFS.TrackRecord.Controls
{
    public class EmployeeAssessment : TemplatedWebControl
    {
        YesNoRadioButtonList YesNoRadioButtonList1;
        Literal GetDate;
        Literal RemarksLit;
        YesNoRadioButtonList YesNo;
        ValidatingDateBox SetDate;
        TextBox Remarks;

        Panel Overview;
        Panel Edit;


        IconButton New;
        IconButton Save;
        IconButton Cancel;
        IconButton EditButton;


        TRContext context = TRContext.Current;


        private bool IsNew
        {
            get
            {
                object isn = ViewState["IsNew"];

                if (isn == null)
                {
                    isn = true;

                    ViewState["IsNew"] = true;
                }

                return (bool)isn;

            }

            set { ViewState["IsNew"] = value; }
        }

        protected override void AttachChildControls()
        {
             YesNoRadioButtonList1 = (YesNoRadioButtonList)FindControl("YesNoRadioButtonList1");
             GetDate = (Literal)FindControl("GetDate");
             RemarksLit = (Literal)FindControl("RemarksLit");
             YesNo = (YesNoRadioButtonList)FindControl("YesNo");
             SetDate = (ValidatingDateBox)FindControl("SetDate");
             Remarks = (TextBox)FindControl("Remarks");

             Overview = (Panel)FindControl("Overview");
             Edit = (Panel)FindControl("Edit");

             New = (IconButton)FindControl("New");
             Save = (IconButton)FindControl("Save");
             Cancel = (IconButton)FindControl("Cancel");
             EditButton = (IconButton)FindControl("EditButton");


            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            New.Click += new EventHandler(New_Click);
            Save.Click += new EventHandler(Save_Click);
            Cancel.Click += new EventHandler(Cancel_Click);
            EditButton.Click += new EventHandler(New_Click);

            EmployeeEducation assess = EmployeesDataService.GetAssessment(context.Employee.EmployeeId);

            if (assess != null)
            {
                YesNoRadioButtonList1.Select(assess.Completed);
                GetDate.Text = assess.StartDate.ToShortDateString();
                SetDate.Date = assess.StartDate;
                RemarksLit.Text = assess.Description;
                Remarks.Text = assess.Description;
                YesNo.Select(assess.Completed);

                IsNew = false;
                New.Visible = false;
                EditButton.Visible = true;
            }
            else
            {
                IsNew = true;
                New.Visible = true;
                EditButton.Visible = false;
            }
        }

        void Cancel_Click(object sender, EventArgs e)
        {
            Edit.Visible = false;
            Overview.Visible = true;
        }

        void Save_Click(object sender, EventArgs e)
        {
            if (IsNew)
            {
                EmployeeEducation edu = new EmployeeEducation();
                edu.Completed = YesNo.SelectedAnswer;
                edu.Description = Remarks.Text;
                edu.StartDate = SetDate.Date;
                edu.EmployeeID = context.Employee.EmployeeId;
                
                edu.EducationType = EducationType.Assessment;
                edu.LevelID = 0;
                edu.DisciplineID = 0;

                EmployeesDataService.CreateEmployeeEducation(edu);
            }
            else
            {
                EmployeeEducation edu1 = EmployeesDataService.GetAssessment(context.Employee.EmployeeId);

                edu1.Completed = YesNo.SelectedAnswer;
                edu1.Description = Remarks.Text;
                edu1.StartDate = SetDate.Date;
                edu1.EmployeeID = context.Employee.EmployeeId;
                edu1.EducationType = EducationType.Assessment;

                EmployeesDataService.UpdateEmployeeEducation(edu1);
            }


            Edit.Visible = false;
            Overview.Visible = true;
        }

        void New_Click(object sender, EventArgs e)
        {
            Edit.Visible = true;
            Overview.Visible = false;
        }
    }
}
