using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class ManageAmbitions : BaseCrudOverviewControl
    {
        Literal AmbitionID;
        TextBox AmbitionType;
        TextBox Description;
    
        Literal KeuzeLit;
        TextBox NewChoice;
        Button AddChoice;
        Literal ChoicesHeader;
        MultiView Choices;

        View ListView;
        View EditView;

        TextBox EditChoiceText;
        Button UpdateChanges;

        RepeaterPlusNone ChoiceList;


        AmbitionType ambition;

        private AmbitionType Ambition
        {
            get
            {
                if (ambition == null)
                    LoadObject(ObjecID);

                return ambition;
            }
        }

        public int ChoiceID
        {
            get
            {
                object cid = ViewState["ChoiceID"];

                if (cid == null)
                {
                    cid = 0;

                    ViewState["ChoiceID"] = 0;
                }

                return (int) cid;
            }

            set { ViewState["ChoiceID"] = value; }
        }

        
        #region TemplatedWebControl members

        protected override void AttachChildControls()
        {
            base.AttachChildControls();

            AmbitionID = (Literal)CrudView.FindControl("AmbitionID");
            AmbitionType = (TextBox)CrudView.FindControl("AmbitionType");
            Description = (TextBox)CrudView.FindControl("Description");

            KeuzeLit = (Literal)CrudView.FindControl("KeuzeLit");
            NewChoice = (TextBox)CrudView.FindControl("NewChoice");
            AddChoice = (Button)CrudView.FindControl("AddChoice");


            Choices = (MultiView)FindControl("Choices");
            ListView = (View)Choices.FindControl("ListView");
            EditView = (View)Choices.FindControl("EditView");

            EditChoiceText = (TextBox)EditView.FindControl("EditChoiceText");
            UpdateChanges = (Button)EditView.FindControl("UpdateChanges");

            ChoiceList = (RepeaterPlusNone)ListView.FindControl("ChoiceList");
            ChoicesHeader = (Literal) CrudView.FindControl("ChoicesHeader");

            InitializeChildControls();
        }

        protected override void InitializeChildControls()
        {
            OverviewHeader.Text = "Ambities";
            CrudHeader.Text = "Ambities";
            ChoicesHeader.Text = "Keuzes";

            if (!Page.IsPostBack)
                ManageMV.SetActiveView(OverviewView);

            Overview.ItemCommand += new RepeaterCommandEventHandler(Overview_ItemCommand);
            this.StatusChanged += new StatusChangedHandler(ManageAmbitionTypes_StatusChanged);

            AddChoice.Text = "Toevoegen";
            AddChoice.Click += new EventHandler(AddChoice_Click);

            LoadObject(ObjecID);
            

            ChoiceList.ItemCommand += new RepeaterCommandEventHandler(ChoiceList_ItemCommand);
            ChoiceList.ItemDataBound += new RepeaterItemEventHandler(ChoiceList_ItemDataBound);

            UpdateChanges.Click += new EventHandler(UpdateChanges_Click);

            BindChoices();
            SetListChoiceView();

            base.InitializeChildControls();
        }

        void ChoiceList_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
            {
                Literal ChoiceID = (Literal)e.Item.FindControl("ChoiceID");
                Literal ChoiceText = (Literal)e.Item.FindControl("ChoiceText");
                LinkButton Edit = (LinkButton)e.Item.FindControl("Edit");

                AmbitionChoice ch = (AmbitionChoice)e.Item.DataItem;

                ChoiceID.Text = ch.AmbitionChoiceID.ToString();
                ChoiceText.Text = ch.Choice;
                Edit.CommandArgument = ch.AmbitionChoiceID.ToString();
                Edit.Text = "Bewerken";
            }
        }

        void ChoiceList_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "edit":
                    int choiceId = Convert.ToInt32(e.CommandArgument);
                    ChoiceID = choiceId;
                    SetEditChoiceView();
                    break;
            }
        }

        private void BindChoices()
        {
            List<AmbitionChoice> ch = StemDataService.GetAmbitionChoices(Ambition.AmbitionTypeID);
            ChoiceList.DataSource = ch;
            ChoiceList.DataBind();
        }

        private void SetEditChoiceView()
        {
            AmbitionChoice choice = StemDataService.GetAmbitionChoice(ChoiceID);

            EditChoiceText.Text = choice.Choice;
            UpdateChanges.Text = "Bijwerken";
            
            Choices.SetActiveView(EditView);
        }

        void UpdateChanges_Click(object sender, EventArgs e)
        {
            AmbitionChoice choice = new AmbitionChoice();
            choice.AmbitionChoiceID = ChoiceID;
            choice.AmbitionTypeID = this.ObjecID;
            choice.Choice = EditChoiceText.Text;

            StemDataService.UpdateAmbitionChoice(choice);

            BindChoices();

        }

        private void SetListChoiceView()
        {
            Choices.SetActiveView(ListView);
        }
       

        void AddChoice_Click(object sender, EventArgs e)
        {
            if (NewChoice.Text.Trim() != string.Empty)
            {
                AmbitionChoice choice = new AmbitionChoice();
                choice.AmbitionTypeID = Ambition.AmbitionTypeID;
                choice.Choice = NewChoice.Text;

                StemDataService.CreateAmbitionChoice(choice);
                BindChoices();

                NewChoice.Text = string.Empty;
                ResetCrud();
            }
        }

        void ManageAmbitionTypes_StatusChanged(object sender, CrudOverviewStatusChangedEventArgs e)
        {
            if (e.Status == CrudOverviewStatus.Crud)
            {
                if (!IsNew)
                {
                    
                }
            }
        }

        #endregion

        #region event handlers
        void Overview_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "select":
                    this.ObjecID = Convert.ToInt32(e.CommandArgument);
                    Edit(ObjecID);
                    BindChoices();
                    break;
            }
        }

        #endregion

        #region BaseCrudOverviewControl members

        protected override IList GetData()
        {
            List<AmbitionType> ambs = StemDataService.GetAmbitions();

            return ambs;
        }

        protected override void LoadCrud()
        {
            if (IsNew)
            {
                ambition = new AmbitionType();
                AmbitionID.Text = "n.v.t.";
            }
            else
            {
                AmbitionID.Text = ambition.AmbitionTypeID.ToString();
            }

            AmbitionType.Text = ambition.AmbitionTypeText;
            Description.Text = ambition.Description;

        
        }

        

        protected override void LoadObject(int id)
        {
            ambition = StemDataService.GetAmbition(id);
            //overflows the stack
           // LoadAmbitionChoices();
        }

        #endregion


        #region user interactions
       

        public void Save()
        {
            ambition = new AmbitionType();

            ambition.AmbitionTypeText = AmbitionType.Text;
            ambition.Description = Description.Text;

            if (IsNew)
            {
                StemDataService.CreateAmbition(ambition);
            }
            else
            {
                ambition.AmbitionTypeID = Convert.ToInt32(AmbitionID.Text);

                StemDataService.UpdateAmbition(ambition);
            }

            IsNew = false;

            Reset();
        }

        public void Delete()
        {
            ambition = new AmbitionType();
            ambition.AmbitionTypeID = Convert.ToInt32(AmbitionID.Text);

            StemDataService.DeleteAmbition(ambition);

            Reset();
        }

        #endregion
    }
}
