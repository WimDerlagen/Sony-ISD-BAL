using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class EmployeeFunctionOverview : TemplatedWebControl
    {
        #region member variables
        Panel FunctionData;
        Panel NewFunction;
        Panel EditFunction;
        Panel NonePanel;

        Literal WorkingSince;
        Literal FunctionLit;
        Literal Department;
        Literal Division;
        Literal Location;
        Literal Manager;
        Literal StartDate;
        Literal EndDate;

        Literal NewWorkingSince;
        FunctionDropDown Functions;
        Literal NewDepartment;
        Literal NewDivision;
        Literal NewLocation;
        Literal NewManager;
        TextBox NewStartDate;
        TextBox NewEndDate;

        TextBox EditWorkingSince;
        FunctionDropDown EditFunctionDrop;
        Literal EditDepartment;
        Literal EditDivision;
        Literal EditLocation;
        Literal EditManager;
        TextBox EditStartDate;
        TextBox EditEndDate;

        IconButton New;
        IconButton Edit;
        IconButton Save;
        IconButton Cancel;


        PrimusEmployee prim;
        TRContext context = TRContext.Current;
        EmployeeFunction efunction;
        //Function selectedFunction;

        #endregion

        #region properties

        public int PanelIndex
        {
            get
            {
                object pi = ViewState["PanelIndex"];

                if (pi == null)
                {
                    pi = 0;
                    ViewState["PanelIndex"] = 0;
                }

                return (int)pi;
            }
            set
            {
                ViewState["PanelIndex"] = value;
            }
        }

        public bool IsNew
        {
            get {
                object isn = ViewState["IsNew"];

                if (isn == null)
                {
                    isn = false;

                    ViewState["IsNew"] = false;
                 
                }

                return (bool)isn;
            }
            set { ViewState["IsNew"] = value; }
        }

        private Function selectedFunction
        {
            get
            {
                object self = ViewState["SelectedFunction"];

                if (self == null)
                {
                    //self = new Function();

                    //ViewState["SelectedFunction"] = false;

                    return null;

                }

                return (Function)self;
            }
            set { ViewState["SelectedFunction"] = value; }
        }

        #endregion

        #region TemplatedWebControl implementations
        protected override void AttachChildControls()
        {
            FunctionData = (Panel)FindControl("FunctionData");
            NewFunction = (Panel)FindControl("NewFunction");
            EditFunction = (Panel)FindControl("EditFunction");
            NonePanel = (Panel)FindControl("NonePanel");

            WorkingSince = (Literal)FindControl("WorkingSince");
            FunctionLit = (Literal)FindControl("Function");
            Department = (Literal)FindControl("Department");
            Division = (Literal)FindControl("Division");
            Location = (Literal)FindControl("Location");
            Manager = (Literal)FindControl("Manager");
            StartDate = (Literal)FindControl("StartDate");
            EndDate = (Literal)FindControl("EndDate");

            NewWorkingSince = (Literal)FindControl("NewWorkingSince");
            Functions = (FunctionDropDown)FindControl("Functions");
            NewDepartment = (Literal)FindControl("NewDepartment");
            NewDivision = (Literal)FindControl("NewDivision");
            NewLocation = (Literal)FindControl("NewLocation");
            NewManager = (Literal)FindControl("NewManager");
            NewStartDate = (TextBox)FindControl("NewStartDate");
            NewEndDate = (TextBox)FindControl("NewEndDate");

            EditWorkingSince = (TextBox)FindControl("EditWorkingSince");
            EditFunctionDrop = (FunctionDropDown)FindControl("EditFunctionDrop");
            EditDepartment = (Literal)FindControl("EditDepartment");
            EditDivision = (Literal)FindControl("EditDivision");
            EditLocation = (Literal)FindControl("EditLocation");
            EditManager = (Literal)FindControl("EditManager");
            EditStartDate = (TextBox)FindControl("EditStartDate");
            EditEndDate = (TextBox)FindControl("EditEndDate");

            New = (IconButton)FindControl("New");
            Edit = (IconButton)FindControl("Edit");
            Save = (IconButton)FindControl("Save");
            Cancel = (IconButton)FindControl("Cancel");

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            prim = EmployeesDataService.GetEmployee(context.EmployeeNumber);
            efunction = EmployeesDataService.GetCurrentEmployeeFunction(prim.EmployeeNumber);
            Cancel.Click += new EventHandler(Cancel_Click);
           
            if (efunction == null)
            {
                New.Click += new EventHandler(New_Click);
                Save.Click += new EventHandler(Save_Click);
                PanelIndex = 3;
                LoadPanel();
                LoadEmployeeDataWithoutFunction();
            }
            else
            {
                LoadEmployeeData();

                PanelIndex = 0;
                LoadPanel();

                New.Click += new EventHandler(New_Click);
                Edit.Click += new EventHandler(Edit_Click);
                Save.Click += new EventHandler(Save_Click);
            }

            New.Visible = false;

            Functions.SelectedIndexChanged += new EventHandler(Functions_SelectedIndexChanged);
            EditFunctionDrop.SelectedIndexChanged += new EventHandler(EditFunctionDrop_SelectedIndexChanged);

            Functions.AutoPostBack = true;
            EditFunctionDrop.AutoPostBack = true;
        }

      

       

        private void LoadEmployeeData()
        {
            WorkingSince.Text = prim.DatumInDienstSony.ToShortDateString();
            NewWorkingSince.Text = prim.DatumInDienstSony.ToShortDateString();
            EditWorkingSince.Text = prim.DatumInDienstSony.ToShortDateString();

            FunctionLit.Text = prim.Function.Function.Title;
            Functions.Select(prim.Function.Function.FunctionID);
            EditFunctionDrop.Select(prim.Function.Function.FunctionID);

            Department.Text = prim.Function.Department.Name;
            NewDepartment.Text = prim.Function.Department.Name;
            EditDepartment.Text = prim.Function.Department.Name;

            Division.Text = prim.Function.Function.Division;
            NewDivision.Text = prim.Function.Function.Division;
            EditDivision.Text = prim.Function.Function.Division;

            Location.Text = prim.Function.Function.Location;
            NewLocation.Text = prim.Function.Function.Location;
            EditLocation.Text = prim.Function.Function.Location;

            //to implement
            Manager.Text = string.Empty;
            NewManager.Text = string.Empty;
            EditManager.Text = string.Empty;

            StartDate.Text = prim.Function.StartDate.ToShortDateString();
            NewStartDate.Text = prim.Function.StartDate.ToShortDateString();
            EditStartDate.Text = prim.Function.StartDate.ToShortDateString();

            EndDate.Text = prim.Function.EndDate.ToShortDateString();
            NewEndDate.Text = prim.Function.EndDate.ToShortDateString();
            EditEndDate.Text = prim.Function.EndDate.ToShortDateString();

        }

        private void LoadEmployeeDataWithoutFunction()
        {
            WorkingSince.Text = prim.DatumInDienstSony.ToShortDateString();
            NewWorkingSince.Text = prim.DatumInDienstSony.ToShortDateString();
            EditWorkingSince.Text = prim.DatumInDienstSony.ToShortDateString();
        }

        private void LoadPanel()
        {
            switch (PanelIndex)
            {
                case 0:
                    FunctionData.Visible = true;
                    NewFunction.Visible = false;
                    EditFunction.Visible = false;
                    NonePanel.Visible = false;

                    Save.Visible = false;
                    Edit.Visible = false;
                    New.Visible = true;
                    Cancel.Visible = false;
                    break;
                case 1:
                    FunctionData.Visible = false;
                    NewFunction.Visible = true;
                    EditFunction.Visible = false;
                    NonePanel.Visible = false;

                    Save.Visible = true;
                    Edit.Visible = false;
                    New.Visible = false;
                    Cancel.Visible = true;
                    break;
                case 2:
                    FunctionData.Visible = false;
                    NewFunction.Visible = false;
                    EditFunction.Visible = true;
                    NonePanel.Visible = false;

                    Save.Visible = true;
                    Edit.Visible = false;
                    New.Visible = false;
                    Cancel.Visible = true;

                    break;
                case 3:
                    FunctionData.Visible = false;
                    NewFunction.Visible = false;
                    EditFunction.Visible = false;
                    NonePanel.Visible = true;
                    
                    Save.Visible = false;
                    Edit.Visible = false;
                    New.Visible = true;
                    Cancel.Visible = false;
                    break;
            }
        }


        #endregion


        #region event handlers

        void EditFunctionDrop_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedFunction = StemDataService.GetFunction(Convert.ToInt32(EditFunctionDrop.SelectedValue));
            
            EditDepartment.Text = selectedFunction.Department.Name;
            EditDivision.Text = selectedFunction.Division;
            EditLocation.Text = selectedFunction.Location;
            EditManager.Text = selectedFunction.Department.Name;

        }

        void Functions_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                selectedFunction = StemDataService.GetFunction(Convert.ToInt32(Functions.SelectedValue));

                NewDepartment.Text = selectedFunction.Department.Name;
                NewDivision.Text = selectedFunction.Division;
                NewLocation.Text = selectedFunction.Location;
                NewManager.Text = selectedFunction.Department.Name;
            }
            catch { }
        }


        void Save_Click(object sender, EventArgs e)
        {
            if (IsNew)
            {
                if (efunction != null)
                {
                    efunction.EndDate = Convert.ToDateTime(NewStartDate.Text);
                    efunction.Current = false;

                    EmployeesDataService.UpdateEmployeeFunction(efunction);
                }

                EmployeeFunction newFunction = new EmployeeFunction();

                newFunction.Current = true;
                newFunction.DepartmentID = selectedFunction.DepartmentID;
                newFunction.EmployeeID = prim.EmployeeId;
                newFunction.FunctionID = Convert.ToInt32(Functions.SelectedValue);
                newFunction.PreferredDuration = 12;
                newFunction.StartDate = Convert.ToDateTime(NewStartDate.Text);

                if (NewEndDate.Text != string.Empty)
                    newFunction.EndDate = Convert.ToDateTime(NewEndDate.Text);


                EmployeesDataService.CreateEmployeeFunction(newFunction);

                efunction = newFunction;
            }
            else
            {
                efunction.DepartmentID = selectedFunction.DepartmentID;
                efunction.EmployeeID = prim.EmployeeId;
                efunction.FunctionID = Convert.ToInt32( EditFunctionDrop.SelectedValue);
                efunction.PreferredDuration = 12;
                efunction.StartDate = Convert.ToDateTime(EditStartDate.Text);

                if (EditEndDate.Text != string.Empty)
                    efunction.EndDate = Convert.ToDateTime(EditEndDate.Text);

                EmployeesDataService.UpdateEmployeeFunction(efunction);
            }

            
            PanelIndex = 0;
            LoadPanel();
        }

        void Cancel_Click(object sender, EventArgs e)
        {
            if (efunction == null)
                PanelIndex = 3;
            else
                PanelIndex = 0;

            LoadPanel();
        }
       
        void Edit_Click(object sender, EventArgs e)
        {
            IsNew = false;
            PanelIndex = 2;
            LoadPanel();
        }

        void New_Click(object sender, EventArgs e)
        {
            IsNew = true;
            PanelIndex = 1;
            LoadPanel();
        }

        #endregion

    }
}
