using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class ManageLanguages : BaseCrudOverviewControl
    {
        Literal LanguageID;
        TextBox Language;
        Language lang;

        #region TemplatedWebControl members

        protected override void AttachChildControls()
        {
            base.AttachChildControls();

            LanguageID = (Literal)CrudView.FindControl("LanguageID");
            Language = (TextBox)CrudView.FindControl("Language");

            InitializeChildControls();
        }

        protected override void InitializeChildControls()
        {
            OverviewHeader.Text = "Talen";
            CrudHeader.Text = "Talen";
            ManageMV.SetActiveView(OverviewView);

            Overview.ItemCommand += new RepeaterCommandEventHandler(Overview_ItemCommand);

            base.InitializeChildControls();
        }

        #endregion

        #region event handlers
        void Overview_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "select":
                    int id = Convert.ToInt32(e.CommandArgument);
                    Edit(id);
                    break;
            }
        }

        #endregion

        #region BaseCrudOverviewControl members

        protected override IList GetData()
        {
            List<Language> langs = StemDataService.GetLanguages();

            return langs;
        }

        protected override void LoadCrud()
        {
            if (!IsNew)
            {
                LanguageID.Text = lang.LanguageId.ToString();
                Language.Text = lang.Name;
            }
            else
            {
                lang = new Language();
                LanguageID.Text = "n.v.t.";
                Language.Text = string.Empty;
            }
        }

        protected override void LoadObject(int id)
        {
            lang = StemDataService.GetLanguage(id);
        }

        #endregion


        #region user interactions

        public void Save()
        {
            if (IsNew)
            {
                Language lang = new Language();
                lang.Name = Language.Text;

                StemDataService.CreateLanguage(lang);
            }
            else
            {
                lang = new Language();
                lang.LanguageId = Convert.ToInt32(LanguageID.Text);
                lang.Name = Language.Text;

                StemDataService.UpdateLanguage(lang);
            }

            Reset();
        }

        public void Delete()
        {
            Language lang = new Language();
            lang.LanguageId = Convert.ToInt32(LanguageID.Text);
            lang.Name = Language.Text;

            StemDataService.DeleteLanguage(lang);

            Reset();
        }

        #endregion
    }
}
