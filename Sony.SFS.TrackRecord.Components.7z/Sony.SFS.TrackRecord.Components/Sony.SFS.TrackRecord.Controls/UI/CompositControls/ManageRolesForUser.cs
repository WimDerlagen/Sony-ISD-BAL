using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class ManageRolesForUser : TemplatedWebControl
    {
        Literal UserName;
        ListBox AvailableRoles;
        ListBox RolesUserIsIn;
        Button Add;
        Button Remove;

        MembershipUser user = null;
        TRContext context = TRContext.Current;

        protected override void AttachChildControls()
        {
            UserName = (Literal)FindControl("UserName");
            AvailableRoles = (ListBox)FindControl("AvailableRoles");
            RolesUserIsIn = (ListBox)FindControl("RolesUserIsIn");
            Add = (Button)FindControl("Add");
            Remove = (Button)FindControl("Remove");

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            Add.Click += new EventHandler(Add_Click);
            Remove.Click += new EventHandler(Remove_Click);
            
            BindData();            
        }

        void Remove_Click(object sender, EventArgs e)
        {
            Roles.RemoveUserFromRole(user.UserName, RolesUserIsIn.SelectedValue);

            BindData();
        }

        void Add_Click(object sender, EventArgs e)
        {
            Roles.AddUserToRole(user.UserName, AvailableRoles.SelectedValue);

            BindData();
        }

        private void BindData()
        {
            Guid? userKey = context.UserID;

            if (userKey != null)
            {
                user = Membership.GetUser(userKey);

                UserName.Text = user.UserName;

                string[] rolesForUser = Roles.GetRolesForUser(user.UserName);
                string[] allRoles = Roles.GetAllRoles();


                LoadUserRoles(rolesForUser);
                LoadAvailableRoles(allRoles, rolesForUser);
                
            }

        }

        private void LoadUserRoles(string[] roles)
        {
            RolesUserIsIn.Items.Clear();

            foreach (string s in roles)
            {
                ListItem li = new ListItem();
                li.Text = s;
                li.Value = s;

                RolesUserIsIn.Items.Add(li);
            }
        }

        private void LoadAvailableRoles(string[] roles, string[] userRoles)
        {
            AvailableRoles.Items.Clear();

            ArrayList avail = new ArrayList();

            foreach (string s in roles)
            {
                bool userIsIn = false;

                foreach (string p in userRoles)
                {
                    if (p == s)
                        userIsIn = true;
                }

                if (!userIsIn)
                    avail.Add(s);
            }


            foreach (string srole in avail)
            {
                ListItem li = new ListItem();
                li.Text = srole;
                li.Value = srole;

                AvailableRoles.Items.Add(li);
            }
        }

    }
}
