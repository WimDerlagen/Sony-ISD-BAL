using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class EmployeeFunctionHistory : TemplatedWebControl
    {
        RepeaterPlusNone EarlierPositions;
        TRContext context = TRContext.Current;

        protected override void AttachChildControls()
        {
            EarlierPositions = (RepeaterPlusNone)FindControl("EarlierPositions");

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            EarlierPositions.ItemDataBound += new RepeaterItemEventHandler(EarlierPositions_ItemDataBound);

            DataBind();
        }

        void EarlierPositions_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                EmployeeFunction func = (EmployeeFunction)e.Item.DataItem;
                Function function = StemDataService.GetFunction(func.FunctionID);
                func.Department = StemDataService.GetDepartment(func.DepartmentID);

                //Literal FunctionCode = (Literal)e.Item.FindControl("FunctionCode");
                Literal FunctionTitle = (Literal)e.Item.FindControl("FunctionTitle");
                Literal Department = (Literal)e.Item.FindControl("Department");
                Literal StartDate = (Literal)e.Item.FindControl("StartDate");
                Literal EndDate = (Literal)e.Item.FindControl("EndDate");

                //FunctionCode.Text = func.FunctionID.ToString();
                FunctionTitle.Text = function.Title;
                Department.Text = func.Department.Name;
                StartDate.Text = func.StartDate.ToShortDateString();

                if (!func.Current)
                    EndDate.Text = func.EndDate.ToShortDateString();

            }

        }

        public override void DataBind()
        {
            ArrayList functions = EmployeesDataService.GetEmployeeFunctions(context.EmployeeNumber);

            EarlierPositions.DataSource = functions;
            EarlierPositions.DataBind();
        }

    }
}
