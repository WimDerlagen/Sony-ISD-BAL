using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class ImportPrimusData : TemplatedWebControl
    {
        private RadioButtonList importType;
        private TextBox cchar;
        private FileUpload FileUpload1;
        private IconButton Import;
        private Label Errors;

        string employeesPath = "~/Import/Employees";

        protected override void AttachChildControls()
        {
            importType = (RadioButtonList)FindControl("importType");
            cchar = (TextBox)FindControl("cchar");
            FileUpload1 = (FileUpload)FindControl("FileUpload1");
            Import = (IconButton)FindControl("Import");
            Errors = (Label)FindControl("Errors");

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            Import.Click += new EventHandler(ImportFile_Click);
        }

        void ImportFile_Click(object sender, EventArgs e)
        {
            UploadedFile file = new UploadedFile();
            file.FileName = FileUpload1.FileName;
            file.FilePath = TRContext.Current.MapPath(Path.Combine(employeesPath, file.FileName));
            file.FileType = FileType.EmployeesTable;
            if (importType.SelectedValue == "CSV")
            {
                file.ImportType = ImportType.CSV;
                file.Delimiter = cchar.Text[0];
            }
            else
            {
                file.ImportType = ImportType.Excel;
            }

            if (File.Exists(file.FilePath))
            {
                File.Delete(file.FilePath);
            }

            FileUpload1.PostedFile.SaveAs(file.FilePath);

            Jobs.CreateUploadedFile(file);

            ImportService.CreateRunningJobs(file);

            TRContext.Current.Redirect("~/Employees/Primus");

        }



        #region old
        void Import_Click(object sender, EventArgs e)
        {
            ImportJob job = new ImportJob();
            ImportService service = new ImportService();

            if (importType.SelectedValue == "CSV")
            {
                if (cchar.Text.Trim() != string.Empty)
                    if (FileUpload1.HasFile)
                    {
                        job.ImportType = ImportType.CSV;
                        job.FileName = FileUpload1.FileName;
                        job.PostedFile = FileUpload1.PostedFile;
                        job.SeperationCharacter = cchar.Text[0];

                        service.ImportEmployeeTable(job);
                    }
                    else
                    {
                        Errors.Text = "Geen bestand geselecteerd";
                    }
                else
                    Errors.Text = "Geen scheidingsteken opgegeven";
            }
            else if (importType.SelectedValue == "Excel")
            {
                if (FileUpload1.HasFile)
                {
                    job.ImportType = ImportType.Excel;
                    job.FileName = FileUpload1.FileName;
                    job.PostedFile = FileUpload1.PostedFile;

                    service.ImportEmployeeTable(job);

                }
                else
                {
                    Errors.Text = "Geen bestand geselecteerd";
                }
            }
        }

        #endregion
    }
}
