using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class EmployeeRemarks : TemplatedWebControl
    {
        Panel RemarkPanel;
        Panel EditRemarkPanel;
        Literal Remarks;
        TextBox EditRemarks;
        

        IconButton Edit;
        IconButton Save;
        IconButton Cancel;

        TRContext context = TRContext.Current;


        protected override void AttachChildControls()
        {
            RemarkPanel = (Panel)FindControl("RemarkPanel");
            EditRemarkPanel = (Panel)FindControl("EditRemarkPanel");
            Remarks = (Literal)FindControl("Remarks");
            EditRemarks = (TextBox)FindControl("EditRemarks");
            
            Edit = (IconButton)FindControl("Edit");
            Save = (IconButton)FindControl("Save");
            Cancel = (IconButton)FindControl("Cancel");


            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            RemarkPanel.Visible = true;
            EditRemarkPanel.Visible = false;

            Remarks.Text = context.Employee.Remarks;
            EditRemarks.Text = context.Employee.Remarks;

            Edit.Click += new EventHandler(Edit_Click);
            Save.Click += new EventHandler(Save_Click);
            Cancel.Click += new EventHandler(Cancel_Click);
        }

        void Cancel_Click(object sender, EventArgs e)
        {
            RemarkPanel.Visible = true;
            EditRemarkPanel.Visible = false;
        }

        void Save_Click(object sender, EventArgs e)
        {
            context.Employee.Remarks = EditRemarks.Text;

            PrimusEmployee prim = EmployeesDataService.GetEmployee(context.Employee.EmployeeNumber);
            prim.Remarks = EditRemarks.Text;

            EmployeesDataService.UpdatePrimusEmployee(prim);
            Remarks.Text = EditRemarks.Text;

            RemarkPanel.Visible = true;
            EditRemarkPanel.Visible = false;
        }

        void Edit_Click(object sender, EventArgs e)
        {
            RemarkPanel.Visible = false;
            EditRemarkPanel.Visible = true;
        }

    }
}
