using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class EmployeePicture : TemplatedWebControl
    {
        System.Web.UI.WebControls.Image employeePicture;
        TRContext context = TRContext.Current;
        Panel Upload;
        Panel Picture;
        FileUpload File;
        IconButton Edit;
        IconButton Save;
        IconButton Cancel;


        PrimusEmployee prim;


        protected override void AttachChildControls()
        {
            employeePicture = (System.Web.UI.WebControls.Image)FindControl("EmployeePicture");
            Upload = (Panel)FindControl("Upload");
            Picture = (Panel)FindControl("Picture");
            File = (FileUpload)Upload.FindControl("File");
            Edit = (IconButton)Picture.FindControl("Edit");
            Save = (IconButton)Picture.FindControl("Save");
            Cancel = (IconButton)Picture.FindControl("Cancel");

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            prim = EmployeesDataService.GetEmployee(context.EmployeeNumber);
            string imageUrl = Globals.PathCombine(Globals.ImagePath,prim.Image.Filename);
            employeePicture.ImageUrl = imageUrl;

            Edit.Click += new EventHandler(Edit_Click);
            Save.Click += new EventHandler(Save_Click);
            Cancel.Click += new EventHandler(Cancel_Click);
        }

        void Cancel_Click(object sender, EventArgs e)
        {
            Upload.Visible = false;
            Picture.Visible = true;
        }

        void Save_Click(object sender, EventArgs e)
        {
            if (File.HasFile)
            {
                string fileName = prim.EmployeeNumber + File.FileName;

                File.PostedFile.SaveAs(context.MapPath(Globals.PathCombine(Globals.ImagePath, fileName)));

                prim.Image.Filename = fileName;

                EmployeesDataService.UpdateImage(prim.Image);

                prim = EmployeesDataService.GetEmployee(context.EmployeeNumber);

                employeePicture.ImageUrl = Globals.PathCombine(Globals.ImagePath, prim.Image.Filename);
            }


            Upload.Visible = false;
            Picture.Visible = true;
        }

        void Edit_Click(object sender, EventArgs e)
        {
            Upload.Visible = true;
            Picture.Visible = false;
        }

    }
}
