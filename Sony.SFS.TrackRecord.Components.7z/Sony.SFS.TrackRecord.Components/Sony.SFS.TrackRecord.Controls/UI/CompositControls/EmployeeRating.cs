using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class EmployeeRating : TemplatedWebControl
    {
        RepeaterPlusNone Ratings;
        Panel RatingEdit;
        Literal NewDate;
        RatingDropDown RatingValue;
        IconButton New;
        IconButton Save;
        IconButton Cancel;
        RatingType ratingType;
        Literal BoxHeader;
        YearDropDown FYears;

        TRContext context = TRContext.Current;

        public RatingType RatingType
        {
            get { return ratingType; }
            set { ratingType = value; }
        }

        public bool EnableEdit
        {
            get
            {
                object o = ViewState["Edit"];

                if (o == null)
                {
                    o = true;

                    ViewState["Edit"] = true;
                }

                return (bool)o;
            }
            set { ViewState["Edit"] = value; }
        }

        private bool IsNew
        {
            get
            {
                object isn = ViewState["IsNew"];

                if (isn == null)
                {
                    isn = true;

                    ViewState["IsNew"] = true;
                }

                return (bool)isn;

            }

            set { ViewState["IsNew"] = value; }
        }

        public int RatingID
        {
            get
            {
                object aid = ViewState["RatingID"];

                if (aid == null)
                {
                    aid = 0;

                    ViewState["RatingID"] = 0;
                }

                return (int)aid;
            }
            set { ViewState["RatingID"] = value; }
        }

        protected override void AttachChildControls()
        {
            BoxHeader = (Literal)FindControl("BoxHeader");
            Ratings = (RepeaterPlusNone)FindControl("Ratings");
            RatingEdit = (Panel)FindControl("RatingEdit");
            NewDate = (Literal)FindControl("NewDate");
            RatingValue = (RatingDropDown)FindControl("RatingValue");
            New = (IconButton)FindControl("New");
            Save = (IconButton)FindControl("Save");
            Cancel = (IconButton)FindControl("Cancel");
            FYears = (YearDropDown)FindControl("FYears");

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            Ratings.ItemCommand += new RepeaterCommandEventHandler(Ratings_ItemCommand);
            Ratings.ItemDataBound += new RepeaterItemEventHandler(Ratings_ItemDataBound);

            RatingValue.RatingType = ratingType;

            New.Click += new EventHandler(New_Click);
            Save.Click += new EventHandler(Save_Click);
            Cancel.Click += new EventHandler(Cancel_Click);

            Save.Visible = false;
            Cancel.Visible = false;

            if (EnableEdit)
                New.Visible = true;
            else
                New.Visible = false;


            SetBoxHeader();

            DataBind();
        }

        private void SetBoxHeader()
        {
            switch (ratingType)
            {
                case RatingType.EGrading:
                    BoxHeader.Text = "E gradings";
                    break;
                case RatingType.WorkforcePlayer:
                    BoxHeader.Text = "Workforce player";
                    break;
                case RatingType.WorkforcePosition:
                    BoxHeader.Text = "Workforce position";
                    break;
                case RatingType.PRatingHr:
                    BoxHeader.Text = "P Rating HR";
                    break;
                case RatingType.PRatingMgr:
                    BoxHeader.Text = "P Rating Manager";
                    break;

            }
        }

        public override void DataBind()
        {
            switch(ratingType)
            {
                case RatingType.EGrading:
                    Ratings.DataSource = EmployeesDataService.GetEGradings(context.Employee.EmployeeNumber);
                    break;
                case RatingType.WorkforcePlayer:
                    Ratings.DataSource = EmployeesDataService.GetWorkforceplayerRatings(context.Employee.EmployeeNumber);

                    break;
                case RatingType.WorkforcePosition:
                    Ratings.DataSource = EmployeesDataService.GetWorkforcePositionRatings(context.Employee.EmployeeNumber);
                    break;
                case RatingType.PRatingHr:
                    Ratings.DataSource = EmployeesDataService.GetPHrRatings(context.Employee.EmployeeNumber);
                    break;
                case RatingType.PRatingMgr:
                    Ratings.DataSource = EmployeesDataService.GetPMgrRatings(context.Employee.EmployeeNumber);
                    break;
            }
            
            Ratings.DataBind();
        }

        void Cancel_Click(object sender, EventArgs e)
        {
            RatingEdit.Visible = false;
            Save.Visible = false;
            Cancel.Visible = false;
            New.Visible = true;
            ClearRatingEdit();
        }

        private void ClearRatingEdit()
        {
            RatingValue.SelectedIndex = 0;
        }

        void Save_Click(object sender, EventArgs e)
        {
            if (IsNew)
            {
                Rating rating = new Rating();
                rating.RatingType = ratingType;
                rating.RateDate = DateTime.Now;
                rating.RatingValue = Convert.ToInt32(RatingValue.SelectedValue);
                rating.EmployeeId = context.Employee.EmployeeNumber;
                rating.Year = FYears.SelectedValue;

                EmployeesDataService.CreateRating(rating);
            }
            else
            {
                Rating rating1 = EmployeesDataService.GetEmployeeRating(RatingID);

                rating1.RatingType = ratingType;
                //rating.RateDate = DateTime.Now;
                rating1.RatingValue = Convert.ToInt32(RatingValue.SelectedValue);
                rating1.EmployeeId = context.Employee.EmployeeNumber;
                rating1.Year = FYears.SelectedValue;

                EmployeesDataService.UpdateRating(rating1);
            }

            Save.Visible = false;
            Cancel.Visible = false;
            New.Visible = true;
            RatingEdit.Visible = false;
            DataBind();
        }

        void New_Click(object sender, EventArgs e)
        {
            IsNew = true;
            NewDate.Text = DateTime.Now.ToShortDateString();
            RatingEdit.Visible = true;

            Cancel.Visible = true;
            Save.Visible = true;
            New.Visible = false;
        }

        void Ratings_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                Rating rating = (Rating)e.Item.DataItem;

                Literal RateDate = (Literal)e.Item.FindControl("RateDate");
                Literal Rating = (Literal)e.Item.FindControl("Rating");
                Literal FiscalYear = (Literal)e.Item.FindControl("FiscalYear");
                LinkButton RowEdit = (LinkButton)e.Item.FindControl("Edit");
                LinkButton RowDelete = (LinkButton)e.Item.FindControl("Delete");

                RateDate.Text = rating.RateDate.ToShortDateString();
                Rating.Text = Translator.Rating(rating.RatingValue, RatingType);
                FiscalYear.Text = rating.Year;

                RowEdit.CommandArgument = rating.RatingId.ToString();
                RowEdit.CommandName = "edit";

                RowDelete.CommandArgument = rating.RatingId.ToString();
                RowDelete.CommandName = "delete";


            }
        }

        void Ratings_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            RatingID = Convert.ToInt32(e.CommandArgument);

            switch (e.CommandName)
            {
                case "edit":
                    EditRating();
                    break;

                case "delete":
                    Rating rr = new Rating();
                    rr.RatingId = RatingID;
                    EmployeesDataService.DeletRating(rr);
                    DataBind();
                    break;
            }
        }

        private void EditRating()
        {
            IsNew = false;
            RatingEdit.Visible = true;

            Rating rt = EmployeesDataService.GetEmployeeRating(RatingID);

            NewDate.Text = rt.RateDate.ToShortDateString();
            FYears.Select(rt.Year);
            RatingValue.Select(rt.RatingValue);

            Cancel.Visible = true;
            Save.Visible = true;
            New.Visible = false;

        }

    }
}
