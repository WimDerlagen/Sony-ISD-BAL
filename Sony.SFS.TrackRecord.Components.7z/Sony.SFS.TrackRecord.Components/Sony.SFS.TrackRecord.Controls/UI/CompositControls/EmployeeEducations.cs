using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class EmployeeEducations : TemplatedWebControl
    {
        RepeaterPlusNone Educations;
        Panel EducationEdit;
        AutoCompleteBox NewDiscipline;
        AutoCompleteBox NewLevel;
        DateBox NewStartDate;
        TextBox NewEndDate;
        TextBox NewLocation;

        TextBox NewDescription;
        EducationTypeDropDown NewEducationType;
        CheckBox NewCompleted;
        TextBox NewTitle;

        IconButton New;
        IconButton Save;
        IconButton Cancel;

        TRContext context = TRContext.Current;

        private bool IsNew
        {
            get
            {
                object isn = ViewState["IsNew"];

                if (isn == null)
                {
                    isn = true;

                    ViewState["IsNew"] = true;
                }

                return (bool)isn;

            }

            set { ViewState["IsNew"] = value; }
        }

        public int EducationID
        {
            get
            {
                object aid = ViewState["EducationID"];

                if (aid == null)
                {
                    aid = 0;

                    ViewState["EducationID"] = 0;
                }

                return (int)aid;
            }
            set { ViewState["EducationID"] = value; }
        }

        protected override void AttachChildControls()
        {
            Educations = (RepeaterPlusNone)FindControl("Educations");
            EducationEdit = (Panel)FindControl("EducationEdit");
            NewDiscipline = (AutoCompleteBox)FindControl("NewDiscipline");
            NewLevel = (AutoCompleteBox)FindControl("NewLevel");
            NewStartDate = (DateBox)FindControl("NewStartDate");
            NewEndDate = (TextBox)FindControl("NewEndDate");
            NewLocation = (TextBox)FindControl("NewLocation");

            NewDescription = (TextBox)FindControl("NewDescription");
            NewEducationType = (EducationTypeDropDown)FindControl("NewEducationType");
            NewCompleted = (CheckBox)FindControl("NewCompleted");
            NewTitle = (TextBox)FindControl("NewTitle");
            
            
            New = (IconButton)FindControl("New");
            Save = (IconButton)FindControl("Save");
            Cancel = (IconButton)FindControl("Cancel");

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            New.Click += new EventHandler(New_Click);
            Save.Click += new EventHandler(Save_Click);
            Cancel.Click += new EventHandler(Cancel_Click);

            Educations.ItemCommand += new RepeaterCommandEventHandler(Educations_ItemCommand);
            Educations.ItemDataBound += new RepeaterItemEventHandler(Educations_ItemDataBound);

            DataBind();
        }

        public override void DataBind()
        {
            ArrayList edus = EmployeesDataService.GetEducations(context.Employee.EmployeeId);
            Educations.DataSource = edus;
            Educations.DataBind();
        }

        void Educations_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.Item)
            {
                Literal Discipline = (Literal)e.Item.FindControl("Discipline");
                Literal Level = (Literal)e.Item.FindControl("Level");
                Literal StartDate = (Literal)e.Item.FindControl("StartDate");
                Literal EndDate = (Literal)e.Item.FindControl("EndDate");
                Literal Location = (Literal)e.Item.FindControl("Location");
                CheckBox Completed = (CheckBox)e.Item.FindControl("Completed");
                LinkButton Edit = (LinkButton)e.Item.FindControl("Edit");
                LinkButton Delete = (LinkButton)e.Item.FindControl("Delete");

                EmployeeEducation edu = (EmployeeEducation)e.Item.DataItem;

                Discipline.Text = edu.Discipline.Text;
                Level.Text = edu.EducationLevel.Text;
                StartDate.Text = edu.StartDate.ToShortDateString();
                EndDate.Text = edu.EndDate.ToShortDateString();
                Location.Text = edu.Location;
                Completed.Checked = edu.Completed;

                Edit.CommandName = "edit";
                Edit.CommandArgument = edu.EmployeeEducationID.ToString();

                Delete.CommandName = "delete";
                Delete.CommandArgument = edu.EmployeeEducationID.ToString();
                

            }
        }

        void Educations_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            EducationID = Convert.ToInt32(e.CommandArgument);

            switch (e.CommandName)
            {
                case "edit":

                    EmployeeEducation edu = EmployeesDataService.GetEducation(EducationID);
                    EditEducation(edu);
                    break;
                case "delete":
                    EmployeeEducation edu2 = new EmployeeEducation();
                    edu2.EmployeeEducationID = EducationID;
                    EmployeesDataService.DeleteEmployeeEducation(edu2);
                    break;
            }
        }

        #region button click=s
        void Cancel_Click(object sender, EventArgs e)
        {
            ClearEducationEdit();
        }

        void LoadObject(EmployeeEducation edu)
        {
            NewCompleted.Checked = edu.Completed;
            NewDescription.Text = edu.Description;
            NewDiscipline.Text = edu.Discipline.Text;
            NewDiscipline.Value = edu.Discipline.Value;
            NewLevel.Text = edu.EducationLevel.Text;
            NewLevel.Value = edu.EducationLevel.Value;
            NewEducationType.Select((int)edu.EducationType);
            NewEndDate.Text = edu.EndDate.ToShortDateString();
            NewStartDate.Date = edu.StartDate;
            NewLocation.Text = edu.Location;
            NewTitle.Text = edu.Title;
        }

        void Save_Click(object sender, EventArgs e)
        {
            if (IsNew)
            {
                EmployeeEducation edu = new EmployeeEducation();
                edu.Completed = NewCompleted.Checked;
                edu.Description = NewDescription.Text;
                edu.DisciplineID = NewDiscipline.Value;
                edu.LevelID = NewLevel.Value;
                edu.EducationType = (EducationType)Convert.ToInt32(NewEducationType.SelectedValue);
                edu.EmployeeID = context.Employee.EmployeeId;
                edu.EndDate = Convert.ToDateTime(NewEndDate.Text);
                edu.Location = NewLocation.Text;
                edu.StartDate = NewStartDate.Date;
                edu.Title = NewTitle.Text;

                EmployeesDataService.CreateEmployeeEducation(edu);
                
            }
            else
            {
                EmployeeEducation edu = EmployeesDataService.GetEducation(EducationID);

                edu.Completed = NewCompleted.Checked;
                edu.Description = NewDescription.Text;
                edu.DisciplineID = NewDiscipline.Value;
                edu.LevelID = NewLevel.Value;
                edu.EducationType = (EducationType)Convert.ToInt32(NewEducationType.SelectedValue);
                edu.EmployeeID = context.Employee.EmployeeId;
                edu.EndDate = Convert.ToDateTime(NewEndDate.Text);
                edu.Location = NewLocation.Text;
                edu.StartDate = NewStartDate.Date;
                edu.Title = NewTitle.Text;

                EmployeesDataService.UpdateEmployeeEducation(edu);
            }
        }

        void New_Click(object sender, EventArgs e)
        {
            IsNew = true;
            EducationEdit.Visible = true;
        }

        #endregion

        private void EditEducation(EmployeeEducation edu)
        {
            IsNew = false;
            EducationEdit.Visible = true;

            LoadObject(edu);
        }

        private void ClearEducationEdit()
        {
            EducationEdit.Visible = false;
            NewDiscipline.Text = string.Empty;
            NewLevel.Text = string.Empty;
            NewStartDate.Text = string.Empty;
            NewEndDate.Text = string.Empty;
            NewLocation.Text = string.Empty;

            NewDescription.Text = string.Empty;
            NewEducationType.Select(0);
            NewCompleted.Checked = false;
            NewTitle.Text = string.Empty;
        }

    }
}
