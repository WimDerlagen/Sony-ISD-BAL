using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class EmployeeSuccessionSuggestion : TemplatedWebControl
    {
        RepeaterPlusNone SuccessionSuggestions;
        HtmlTable AddedSuggestion;
        DepartmentDropDown NewDepartment;
        FunctionDropDown Functions;
        //Literal NewDepartment;
        Literal NewDate;
        DropDownList Term;
        LinkButton AddSuggestion;
        Literal NamePlaceHolder;
        
        TRContext context = TRContext.Current;

        protected override void AttachChildControls()
        {
            SuccessionSuggestions = (RepeaterPlusNone)FindControl("SuccessionSuggestions");

            AddedSuggestion = (HtmlTable)FindControl("AddedSuggestion");
            NewDepartment = (DepartmentDropDown)FindControl("NewDepartment");
            
            Functions = (FunctionDropDown)FindControl("Functions");
           // NewDepartment = (Literal)FindControl("NewDepartment");
            NewDate = (Literal)FindControl("NewDate");
            Term = (DropDownList)FindControl("Term");
            AddSuggestion = (LinkButton)FindControl("AddSuggestion");
            NamePlaceHolder = (Literal)FindControl("NamePlaceHolder");

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            AddSuggestion.Click += new EventHandler(AddSuggestion_Click);
            Functions.SelectedIndexChanged += new EventHandler(Functions_SelectedIndexChanged);

            NewDepartment.DataBind();

            NamePlaceHolder.Text = context.Employee.FullName;

            SuccessionSuggestions.ItemDataBound += new RepeaterItemEventHandler(SuccessionSuggestions_ItemDataBound);
            SuccessionSuggestions.ItemCommand += new RepeaterCommandEventHandler(SuccessionSuggestions_ItemCommand);

            DataBind();
        }

        void SuccessionSuggestions_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            int suggId = Convert.ToInt32(e.CommandArgument);

            switch (e.CommandName)
            {
                case "select":

                    break;

                case "delete":
                    Suggestion sug = new Suggestion();
                    sug.SuggestionId = suggId;
                    EmployeesDataService.DeleteSuggestion(sug);

                    DataBind();
                    break;
            }
        }

        void SuccessionSuggestions_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
            {
                Suggestion sugg = (Suggestion)e.Item.DataItem;

                
                LinkButton xFunctionTitle = (LinkButton)e.Item.FindControl("FunctionTitle");
                Literal xDepartment = (Literal)e.Item.FindControl("Department");
                Literal xDate = (Literal)e.Item.FindControl("Date");
                Literal xTerm = (Literal)e.Item.FindControl("Term");
                ThemedImageButton xDelete = (ThemedImageButton)e.Item.FindControl("Delete");

                
                xFunctionTitle.Text = sugg.Function.Title;
                xDepartment.Text = sugg.Department;
                xDate.Text = sugg.SetDate.ToString("dd-MM-yyyy");
                xTerm.Text = sugg.Term.ToString();

                
                xFunctionTitle.CommandName = "select";
                //xDepartment.CommandName = "select";
                //xDate.CommandName = "select";
                //xTerm.CommandName = "select";
                xDelete.CommandName = "delete";

                
                xFunctionTitle.CommandArgument = sugg.SuggestionId.ToString();
                //xDepartment.CommandArgument = sugg.SuggestionId.ToString();
                //xDate.CommandArgument = sugg.SuggestionId.ToString();
                //xTerm.CommandArgument = sugg.SuggestionId.ToString();
                xDelete.CommandArgument = sugg.SuggestionId.ToString();
            }
        }

        void AddSuggestion_Click(object sender, EventArgs e)
        {
            if (AddedSuggestion.Visible == true)
            {
                Suggestion sugg = new Suggestion();
                sugg.EmployeeId = context.EmployeeNumber;
                sugg.FunctionId = Convert.ToInt32(Functions.SelectedValue);
                sugg.SetDate = DateTime.Now;
                sugg.Term = Convert.ToInt32(Term.SelectedValue);
                sugg.DepartmentID = NewDepartment.SelectedID;
                EmployeesDataService.AddSuggestion(sugg);

                AddedSuggestion.Visible = false;
                AddSuggestion.Text = "[+] Suggestie toevoegen";

                DataBind();

            }
            else
            {
                AddedSuggestion.Visible = true;
                AddSuggestion.Text = "Opslaan";
            }
        }

        void Functions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Functions.SelectedIndex == 0)
                return;

            int functionId = Convert.ToInt32(Functions.SelectedValue);
            Function func = StemDataService.GetFunction(functionId);

            
           // NewDepartment.Text = func.Department.Name;
            NewDate.Text = DateTime.Now.ToShortDateString();

            
        }

        public override void DataBind()
        {
            List<Suggestion> suggs = EmployeesDataService.GetSuggestions(context.EmployeeNumber);

            SuccessionSuggestions.DataSource = suggs;
            SuccessionSuggestions.DataBind();
        }

    }
}
