using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;
using System.Web;
using System.Web.Security;

namespace Sony.SFS.TrackRecord.Controls
{
    public class ManageRoles : TemplatedWebControl
    {
        Repeater RoleRepeater;

        protected override void AttachChildControls()
        {
            RoleRepeater = (Repeater)FindControl("RoleRepeater");

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            RoleRepeater.ItemDataBound += new RepeaterItemEventHandler(RoleRepeater_ItemDataBound);
            DataBind();
        }

        void RoleRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
            {
                Literal RoleLiteral = (Literal)e.Item.FindControl("RoleLiteral");
                HyperLink Memberslink = (HyperLink)e.Item.FindControl("MembersLink");

                string role = (string)e.Item.DataItem;

                RoleLiteral.Text = role;
                Memberslink.Text = "gebruikers";

                string url = "~/Users/Default.aspx?Role={0}";
                Memberslink.NavigateUrl = string.Format(url, role);
                
            }
        }

        public override void DataBind()
        {
            string[] roles = Roles.GetAllRoles();
            RoleRepeater.DataSource = roles;
            RoleRepeater.DataBind();
        }

    }
}
