using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;
using System.Web;
using System.Web.Profile;
using System.Web.Security;


namespace Sony.SFS.TrackRecord.Controls
{
    public class ManageUsers : TemplatedWebControl
    {
        RepeaterPlusNone Users;
        Pager Pager;

        protected override void AttachChildControls()
        {
            Users = (RepeaterPlusNone)FindControl("Users");
            Pager = (Pager)FindControl("Pager");


            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            Users.ItemDataBound += new RepeaterItemEventHandler(Users_ItemDataBound);
            Users.ItemCommand += new RepeaterCommandEventHandler(Users_ItemCommand);

            DataBind();
        }

        void Users_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "sort":
                    break;

                case "select":

                    break;
            }
        }

        void Users_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
            {
                HyperLink Name = (HyperLink)e.Item.FindControl("Name");
                HyperLink UserName = (HyperLink)e.Item.FindControl("UserName");
                Literal _Roles = (Literal)e.Item.FindControl("Roles");

                MembershipUser user = (MembershipUser)e.Item.DataItem;

                string url = "~/Users/RolesForUser/Default.aspx?UserID={0}";

                Name.NavigateUrl = string.Format(url, user.ProviderUserKey.ToString());
                UserName.NavigateUrl = string.Format(url, user.ProviderUserKey.ToString());

                TRProfileCommon profile = (TRProfileCommon)ProfileBase.Create(user.UserName, true);

                Name.Text = profile.CommonName;
                UserName.Text = user.UserName;
                _Roles.Text = GetRolesString(Roles.GetRolesForUser(user.UserName));

            }
        }

        private string GetRolesString(string[] roles)
        {
            string output = string.Empty;

            foreach (string s in roles)
            {
                output += s;
                output += ", ";
            }

            if (output.Length > 1)
                output = output.Substring(0, output.Length - 2);

            return output;
        }

        public override void DataBind()
        {
            TRContext context = TRContext.Current;

            if (context.Role == string.Empty)
            {
                MembershipUserCollection uc = Membership.GetAllUsers();

                Users.DataSource = uc;
                Users.DataBind();
            }
            else
            {
                string[] users = Roles.GetUsersInRole(context.Role);

                ArrayList usersInRole = new ArrayList();

                foreach (string s in users)
                {
                    usersInRole.Add(Membership.GetUser(s));

                }

                Users.DataSource = usersInRole;
                Users.DataBind();
            }
        }

    }
}
