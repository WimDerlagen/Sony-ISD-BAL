using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class EmployeeDataOverview : TemplatedWebControl
    {
        Literal WorkstyleRating;
        Literal EGrading;
        Literal WorkforcePosition;
        Literal WorkforcePlayer;
        Literal PratingHR;
        Literal PratingMgr;


        Repeater Ambitions;
        TRContext context = TRContext.Current;

        protected override void AttachChildControls()
        {
            WorkstyleRating = (Literal)FindControl("WorkstyleRating");
            EGrading = (Literal)FindControl("EGrading");
            WorkforcePosition = (Literal)FindControl("WorkforcePosition");
            WorkforcePlayer = (Literal)FindControl("WorkforcePlayer");
            PratingHR = (Literal)FindControl("PratingHR");
            PratingMgr = (Literal)FindControl("PratingMgr");

            Ambitions = (Repeater)FindControl("Ambitions");

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            WorkstyleRating.Text = context.Employee.WorkstyleRating;
            EGrading.Text = context.Employee.EGrading;
            WorkforcePosition.Text = context.Employee.WorkforcePosition;
            WorkforcePlayer.Text = context.Employee.WorkforcePlayer;
            PratingHR.Text = context.Employee.PRatingHR;
            PratingMgr.Text = context.Employee.PRatingMgr;

            Ambitions.ItemDataBound += new RepeaterItemEventHandler(Ambitions_ItemDataBound);

            DataBind();
        }

        void Ambitions_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                Literal AmbitionName = (Literal)e.Item.FindControl("AmbitionName");
                Literal AmbitionValue = (Literal)e.Item.FindControl("AmbitionValue");
                EmployeeAmbition amb = (EmployeeAmbition)e.Item.DataItem;

                switch (amb.AmbitionChoiceType)
                {
                    case AmbitionChoiceType.Choice:
                        AmbitionName.Text = amb.AmbitionType.AmbitionTypeText;
                        AmbitionValue.Text = amb.AmbitionChoice.Choice;
                        break;

                    case AmbitionChoiceType.Function:
                        Function func = StemDataService.GetFunction(amb.AmbitionID);
                        AmbitionName.Text = "Functie";
                        AmbitionValue.Text = func.Title;
                        break;

                    case AmbitionChoiceType.Text:
                        //AmbitionName.Text =  
                        break;
                }

            }
        }

        public override void DataBind()
        {
            List<EmployeeAmbition> ambs1 = EmployeesDataService.GetEmployeeAmbitionChoices(context.EmployeeNumber);
            List<EmployeeAmbition> ambs2 = EmployeesDataService.GetEmployeeFunctionAmbitions(context.EmployeeNumber);

            List<EmployeeAmbition> ambitions = new List<EmployeeAmbition>();

            foreach (EmployeeAmbition am in ambs1)
                ambitions.Add(am);

            foreach (EmployeeAmbition am2 in ambs2)
                ambitions.Add(am2);

            Ambitions.DataSource = ambitions;
            Ambitions.DataBind();


            base.DataBind();
        }

    }
}
