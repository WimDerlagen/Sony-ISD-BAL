using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class FunctionSuccessionSuggestion : TemplatedWebControl
    {
        RepeaterPlusNone SuccessionSuggestions;
        Literal FunctionName;
        
        TRContext context = TRContext.Current;
        PrimusEmployee prim;

        protected override void AttachChildControls()
        {
            SuccessionSuggestions = (RepeaterPlusNone)FindControl("SuccessionSuggestions");
            FunctionName = (Literal)FindControl("FunctionName");

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            SuccessionSuggestions.ItemDataBound += new RepeaterItemEventHandler(SuccessionSuggestions_ItemDataBound);
            prim = EmployeesDataService.GetEmployee(context.EmployeeNumber);

            //FunctionName.Text = context.Employee.Function.Function.Title + " / " + context.Employee.FullName;
            if (context.Employee.Function != null)
                FunctionName.Text = context.Employee.Function.Function.Title + " / " + context.Employee.FullName;

            DataBind();
        }

        void SuccessionSuggestions_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
            {
                Suggestion sugg = (Suggestion) e.Item.DataItem;

                Literal Medewerker = (Literal)e.Item.FindControl("Medewerker");
                Literal Functie = (Literal)e.Item.FindControl("Functie");
                Literal Term = (Literal)e.Item.FindControl("Term");

                Medewerker.Text = sugg.Employee.FullName;
                Functie.Text = sugg.Function.Title;
                Term.Text = sugg.Term.ToString();

            }
        }

        
        public override void DataBind()
        {
            if (prim.Function != null)
            {
                List<Suggestion> suggs = EmployeesDataService.GetSuggestionsByFunction(prim.Function.FunctionID);

                SuccessionSuggestions.DataSource = suggs;
                SuccessionSuggestions.DataBind();
            }
        }

    }
}
