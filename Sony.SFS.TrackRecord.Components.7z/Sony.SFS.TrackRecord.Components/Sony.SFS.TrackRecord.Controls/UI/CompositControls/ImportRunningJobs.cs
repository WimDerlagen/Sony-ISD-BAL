using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class ImportRunningJobs : TemplatedWebControl
    {
        //private string outerImageString = "<img style=\"width: 280px;height: 20px;border: 0px;\" src=\"/TrackRecord/Themes/default/images/container.gif\" alt=\"\" />";
        //private string innerImageString = "<img id=\"{0}\" style=\"width: 0px;height: 16px;border: 0px;margin-top: -36px;margin-left:2px;\" src=\"/TrackRecord/Themes/default/images/bar.gif\" alt=\"\" />";
        
        private string progressContainer = "<div style=\"font-size: 8px;padding: 0px;height: 20px;width:280px;background: url(/TrackRecord/Themes/default/images/pbbackground.gif);background-repeat: no-repeat;\">{0}</div>";
        private string progressBar = "<img id=\"{0}\" style=\"width: 0px;height: 16px;border: 0px;margin-top: 2px;margin-left:2px;\" src=\"/TrackRecord/Themes/default/images/bar.gif\" alt=\"\" />";
        private string importButton = "<input type=\"button\" OnClick=\"ExecuteJob({0})\" value=\"Importeer\" />";
        private string records = "<span id=\"{0}_records\"></span>";
        private string errors = "<span id=\"{0}_errors\"></span>";


        Repeater RunningJobs;


        protected override void AttachChildControls()
        {
            RunningJobs = (Repeater) FindControl("RunningJobs");


            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            RunningJobs.ItemDataBound += new RepeaterItemEventHandler(RunningJobs_ItemDataBound);

            DataBind();
        }

        public override void DataBind()
        {
            ArrayList jobs = Jobs.GetPendingJobs();
            RunningJobs.DataSource = jobs;
            RunningJobs.DataBind();


            base.DataBind();
        }

        void RunningJobs_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                RunningJob job = (RunningJob)e.Item.DataItem;

                Literal JobID = (Literal)e.Item.FindControl("JobID");
                Literal JobName = (Literal)e.Item.FindControl("JobName");

                //PlaceHolder OuterImage = (PlaceHolder)e.Item.FindControl("OuterImage");
                PlaceHolder InnerImage = (PlaceHolder)e.Item.FindControl("InnerImage");
                PlaceHolder ImportButton = (PlaceHolder)e.Item.FindControl("ImportButton");
                PlaceHolder Errors = (PlaceHolder)e.Item.FindControl("Errors");
                PlaceHolder Records = (PlaceHolder)e.Item.FindControl("Records");

                JobName.Text = job.JobName;
                JobID.Text = job.JobID.ToString();

                string progb = string.Format(progressContainer, string.Format(progressBar, job.JobName));

                LiteralControl inner = new LiteralControl(progb);
                LiteralControl imbut = new LiteralControl(string.Format(importButton, job.JobID));

                LiteralControl erfld = new LiteralControl(string.Format(errors, job.JobName));
                LiteralControl recfld = new LiteralControl(string.Format(records, job.JobName));

                //OuterImage.Controls.Add(outer);
                InnerImage.Controls.Add(inner);
                ImportButton.Controls.Add(imbut);
                Errors.Controls.Add(erfld);
                Records.Controls.Add(recfld);
            }
        }

    }
}
