using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class EmployeeAmbitions : TemplatedWebControl
    {
        RepeaterPlusNone Ambitions;
        Panel AmbitionEdit;
        AmbitionTypeDropDown AmbitionTypes;
        AmbitionChoiceDropDown AmbitionChoices;
        IconButton New;
        IconButton Save;
        IconButton Cancel;
        TRContext context = TRContext.Current;

        private bool IsNew
        {
            get
            {
                object isn = ViewState["IsNew"];

                if (isn == null)
                {
                    isn = true;

                    ViewState["IsNew"] = true;
                }

                return (bool)isn;

            }

            set { ViewState["IsNew"] = value; }
        }

        public int AmbitionID
        {
            get
            {
                object aid = ViewState["AmbitionID"];

                if (aid == null)
                {
                    aid = 0;

                    ViewState["AmbitionID"] = 0;
                }

                return (int)aid;
            }
            set { ViewState["AmbitionID"] = value; }
        }

        protected override void AttachChildControls()
        {
            Ambitions = (RepeaterPlusNone)FindControl("Ambitions");
            AmbitionEdit = (Panel)FindControl("AmbitionEdit");
            AmbitionTypes = (AmbitionTypeDropDown)FindControl("AmbitionTypes");
            AmbitionChoices = (AmbitionChoiceDropDown)FindControl("AmbitionChoices");
            New = (IconButton)FindControl("New");
            Save = (IconButton)FindControl("Save");
            Cancel = (IconButton)FindControl("Cancel");

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            Ambitions.ItemDataBound += new RepeaterItemEventHandler(Ambitions_ItemDataBound);
            Ambitions.ItemCommand += new RepeaterCommandEventHandler(Ambitions_ItemCommand);
            AmbitionTypes.SelectedIndexChanged += new EventHandler(AmbitionTypes_SelectedIndexChanged);
            New.Click += new EventHandler(New_Click);
            Save.Click += new EventHandler(Save_Click);
            Cancel.Click += new EventHandler(Cancel_Click);

            DataBind();
        }

        void AmbitionTypes_SelectedIndexChanged(object sender, EventArgs e)
        {
            AmbitionChoices.LoadChoices(AmbitionTypes.SelectedID);
        }

        void Cancel_Click(object sender, EventArgs e)
        {
            AmbitionEdit.Visible = false;
            ClearAmbitionEdit();
        }

        void Save_Click(object sender, EventArgs e)
        {
            if (IsNew)
            {
                EmployeeAmbition ambition = new EmployeeAmbition();
                ambition.AmbitionChoiceType = AmbitionChoiceType.Choice;
                ambition.AmbitionID = AmbitionTypes.SelectedID;
                ambition.ChoiceID = AmbitionChoices.SelectedID;
                ambition.EmployeeID = context.Employee.EmployeeId;
                EmployeesDataService.CreateEmployeeAmbition(ambition);
            }
            else
            {
                EmployeeAmbition ambition1 = EmployeesDataService.GetEmployeeAmbition(AmbitionID);

                ambition1.AmbitionChoiceType = AmbitionChoiceType.Choice;
                ambition1.AmbitionID = AmbitionTypes.SelectedID;
                ambition1.ChoiceID = AmbitionChoices.SelectedID;
                ambition1.EmployeeID = context.Employee.EmployeeId;
                EmployeesDataService.UpdateEmployeeAmbition(ambition1);
            }

            AmbitionEdit.Visible = false;
            DataBind();
        }

        void New_Click(object sender, EventArgs e)
        {
            IsNew = true;
            AmbitionEdit.Visible = true;
        }

        private void ClearAmbitionEdit()
        {
            AmbitionTypes.SelectedIndex = 0;
        }

        public override void DataBind()
        {
            Ambitions.DataSource = EmployeesDataService.GetEmployeeAmbitionChoices(context.EmployeeNumber);
            Ambitions.DataBind();
            base.DataBind();
        }

        void Ambitions_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            AmbitionID = Convert.ToInt32(e.CommandArgument);

            switch (e.CommandName)
            {
                case "edit":
                    EditAmbition();
                    
                    break;

                case "delete":
                    EmployeesDataService.DeleteEmployeeAmbition(new EmployeeAmbition(AmbitionID));
                    DataBind();
                    break;
            }
        }

        void Ambitions_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                EmployeeAmbition ambition = (EmployeeAmbition)e.Item.DataItem;
                
                Literal Ambition = (Literal)e.Item.FindControl("Ambition");
                Literal AmbitionChoice = (Literal)e.Item.FindControl("AmbitionChoice");
                LinkButton RowEdit = (LinkButton)e.Item.FindControl("Edit");
                LinkButton RowDelete = (LinkButton)e.Item.FindControl("Delete");

                Ambition.Text = ambition.AmbitionType.AmbitionTypeText;
                AmbitionChoice.Text = ambition.AmbitionChoice.Choice;

                RowEdit.CommandArgument = ambition.EmployeeAmbitionID.ToString();
                RowEdit.CommandName = "edit";

                RowDelete.CommandArgument = ambition.EmployeeAmbitionID.ToString();
                RowDelete.CommandName = "delete";
                

            }
        }

        private void EditAmbition()
        {
            IsNew = false;
            AmbitionEdit.Visible = true;

            EmployeeAmbition amb = EmployeesDataService.GetEmployeeAmbition(AmbitionID);

            AmbitionTypes.Select(amb.AmbitionID);
            AmbitionChoices.Select(amb.ChoiceID);

        }

    }
}
