using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class EmployeeFunctionAmbitions : TemplatedWebControl
    {
        RepeaterPlusNone Functions;
        Literal NewFunctionCode;
        FunctionDropDown NewFunction;
        Literal NewDepartment;
        IconButton Save;
        IconButton New;
        IconButton Cancel;

        Panel AmbitionEdit;

        TRContext context = TRContext.Current;

        private bool IsNew
        {
            get
            {
                object isn = ViewState["IsNew"];

                if (isn == null)
                {
                    isn = true;

                    ViewState["IsNew"] = true;
                }

                return (bool) isn;
                
            }

            set { ViewState["IsNew"] = value; }
        }

        public int AmbitionID
        {
            get
            {
                object aid = ViewState["AmbitionID"];

                if (aid == null)
                {
                    aid = 0;

                    ViewState["AmbitionID"] = 0;
                }

                return (int)aid;
            }
            set { ViewState["AmbitionID"] = value; }
        }

        protected override void AttachChildControls()
        {
            Functions = (RepeaterPlusNone)FindControl("Functions");
            NewFunctionCode = (Literal)FindControl("NewFunctionCode");
            NewFunction = (FunctionDropDown)FindControl("NewFunction");
            NewDepartment = (Literal)FindControl("NewDepartment");
            Save = (IconButton)FindControl("Save");
            New = (IconButton)FindControl("New");
            Cancel = (IconButton)FindControl("Cancel");

            AmbitionEdit = (Panel) FindControl("AmbitionEdit");

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            NewFunction.SelectedIndexChanged += new EventHandler(NewFunction_SelectedIndexChanged);
            Save.Click += new EventHandler(Save_Click);
            New.Click += new EventHandler(New_Click);
            Cancel.Click += new EventHandler(Cancel_Click);

            Functions.ItemDataBound += new RepeaterItemEventHandler(Functions_ItemDataBound);
            Functions.ItemCommand += new RepeaterCommandEventHandler(Functions_ItemCommand);

            DataBind();
        }

        void Cancel_Click(object sender, EventArgs e)
        {
            ClearAmbitionEdit();
            AmbitionEdit.Visible = false;
            IsNew = true;
        }

        void New_Click(object sender, EventArgs e)
        {
            IsNew = true;
            AmbitionEdit.Visible = true;
        }

        void Functions_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "edit":
                    int aid = Convert.ToInt32(e.CommandArgument);
                    AmbitionID = aid;
                    EditAmbition(aid);
                    break;

                case "delete":
                    int ambid = Convert.ToInt32(e.CommandArgument);
                    EmployeesDataService.DeleteEmployeeAmbition(new EmployeeAmbition(ambid));
                    DataBind();
                    break;
            }
        }

        void Functions_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                EmployeeAmbition amb = (EmployeeAmbition)e.Item.DataItem;
                Function func = StemDataService.GetFunction(amb.AmbitionID);

                Literal FunctionCode = (Literal) e.Item.FindControl("FunctionCode");
                Literal FunctionTitle = (Literal)e.Item.FindControl("FunctionTitle");
                Literal Department = (Literal)e.Item.FindControl("Department");
                LinkButton Edit = (LinkButton)e.Item.FindControl("Edit");
                LinkButton Delete = (LinkButton)e.Item.FindControl("Delete");

                FunctionCode.Text = func.FunctionID.ToString();
                FunctionTitle.Text = func.Title;
                Department.Text = func.Department.Name;
                Edit.CommandArgument = amb.EmployeeAmbitionID.ToString();
                Delete.CommandArgument = amb.EmployeeAmbitionID.ToString();
                
            }
        }

        void Save_Click(object sender, EventArgs e)
        {
            if (IsNew)
            {
                EmployeeAmbition amb = new EmployeeAmbition();
                amb.AmbitionChoiceType = AmbitionChoiceType.Function;
                amb.EmployeeID = context.Employee.EmployeeId;
                amb.AmbitionID = NewFunction.SelectedID;

                EmployeesDataService.CreateEmployeeAmbition(amb);
            }
            else
            {
                EmployeeAmbition amb1 = EmployeesDataService.GetEmployeeAmbition(AmbitionID);
                amb1.AmbitionID = NewFunction.SelectedID;

                EmployeesDataService.UpdateEmployeeAmbition(amb1);
            }

            ClearAmbitionEdit();
            AmbitionEdit.Visible = false;

            DataBind();
        }

        void NewFunction_SelectedIndexChanged(object sender, EventArgs e)
        {
            int functionId = NewFunction.SelectedID;
            Function func = StemDataService.GetFunction(functionId);

            NewFunctionCode.Text = func.FunctionID.ToString();
            NewDepartment.Text = func.Department.Name;
        }

        public override void DataBind()
        {
            List<EmployeeAmbition> ambs = EmployeesDataService.GetEmployeeFunctionAmbitions(context.EmployeeNumber);
            Functions.DataSource = ambs;
            Functions.DataBind();
        }

        private void ClearAmbitionEdit()
        {
            NewFunctionCode.Text = string.Empty;
            NewDepartment.Text = string.Empty;
            NewFunction.SelectedIndex = 0;
        }

        private void EditAmbition(int ambitionId)
        {
            IsNew = false;
            AmbitionEdit.Visible = true;

            EmployeeAmbition amb = EmployeesDataService.GetEmployeeAmbition(ambitionId);
            Function func = StemDataService.GetFunction(amb.AmbitionID);

            NewFunctionCode.Text = func.FunctionID.ToString();
            NewFunction.Select(func.FunctionID);
            NewDepartment.Text = func.Department.Name;


        }

    }
}
