using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class ManageDepartments : BaseCrudOverviewControl
    {
        Literal DepartmentID;
        TextBox Name;
        TextBox Description;
        FunctionDropDown Functions;
        Department dept;

        #region TemplatedWebControl members

        protected override void AttachChildControls()
        {
            base.AttachChildControls();

            DepartmentID = (Literal)CrudView.FindControl("DepartmentID");
            Name = (TextBox)CrudView.FindControl("Name");
            Description = (TextBox)CrudView.FindControl("Description");
            Functions = (FunctionDropDown)CrudView.FindControl("Functions");

            InitializeChildControls();
        }

        protected override void InitializeChildControls()
        {
            OverviewHeader.Text = "Afdelingen";
            CrudHeader.Text = "Afdelingen";
            ManageMV.SetActiveView(OverviewView);

            Overview.ItemCommand += new RepeaterCommandEventHandler(Overview_ItemCommand);

            base.InitializeChildControls();
        }

        #endregion

        #region event handlers
        void Overview_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "select":
                    int id = Convert.ToInt32(e.CommandArgument);
                    Edit(id);
                    break;
            }
        }

        #endregion

        #region BaseCrudOverviewControl members

        protected override IList GetData()
        {
            List<Department> depts = StemDataService.GetDepartments();
            return depts;
        }

        protected override void LoadCrud()
        {
            if (!IsNew)
            {
                DepartmentID.Text = dept.DepartmentID.ToString();
                Name.Text = dept.Name;
                Description.Text = dept.Description;
                
                Functions.SelectedIndex = Functions.Items.IndexOf(Functions.Items.FindByValue(dept.ManagedByFunction.ToString()));
            }
            else
            {
                dept = new Department();
                DepartmentID.Text = "n.v.t.";
                Name.Text = string.Empty;
                Description.Text = string.Empty;

            }
        }

        protected override void LoadObject(int id)
        {
            dept = StemDataService.GetDepartment(id);
        }

        #endregion


        #region user interactions

        public void Save()
        {
            if (IsNew)
            {
                if (Name.Text.Trim() == string.Empty)
                {
                    Reset();
                    return;
                }

                dept = new Department();
                dept.Name = Name.Text;
                dept.Description = Description.Text;
                dept.ManagedByFunction = Convert.ToInt32(Functions.SelectedValue);

                StemDataService.CreateDepartment(dept);
            }
            else
            {
                dept = new Department();
                dept.DepartmentID = Convert.ToInt32(DepartmentID.Text);
                dept.Name = Name.Text;
                dept.Description = Description.Text;
                dept.ManagedByFunction = Convert.ToInt32(Functions.SelectedValue);

                StemDataService.UpdateDepartment(dept);
            }

            Reset();
        }

        public void Delete()
        {
            dept = new Department();
            dept.DepartmentID = Convert.ToInt32(DepartmentID.Text);

            StemDataService.DeleteDepartment(dept);

            Reset();
        }

        #endregion
    }
}
