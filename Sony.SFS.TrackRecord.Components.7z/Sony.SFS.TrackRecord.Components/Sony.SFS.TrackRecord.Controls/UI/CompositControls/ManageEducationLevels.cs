using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class ManageEducationLevels : BaseCrudOverviewControl
    {
        Literal LevelID;
        TextBox Level;
        TextBox Description;
        EducationLevel lev;

        #region TemplatedWebControl members

        protected override void AttachChildControls()
        {
            base.AttachChildControls();

            LevelID = (Literal) CrudView.FindControl("LevelID");
            Level = (TextBox)CrudView.FindControl("Level");
            Description = (TextBox)CrudView.FindControl("Description");

            InitializeChildControls();
        }

        protected override void InitializeChildControls()
        {
            OverviewHeader.Text = "Niveau's";
            CrudHeader.Text = "Niveau's";
            ManageMV.SetActiveView(OverviewView);

            Overview.ItemCommand += new RepeaterCommandEventHandler(Overview_ItemCommand);

            base.InitializeChildControls();
        }

        #endregion

        #region event handlers
        void Overview_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "select":
                    int id = Convert.ToInt32(e.CommandArgument);
                    Edit(id);
                    break;
            }
        }

        #endregion

        #region BaseCrudOverviewControl members

        protected override IList GetData()
        {
            List<IAutoDropDownItem> levels = StemDataService.GetEducationLevels();

            return levels;
        }

        protected override void LoadCrud()
        {
            if (!IsNew)
            {
                LevelID.Text = lev.EducationLevelID.ToString();
                Level.Text = lev.Level;
                Description.Text = lev.Description;
            }
            else
            {
                lev = new EducationLevel();
                LevelID.Text = "n.v.t.";
                Level.Text = string.Empty;
                Description.Text = string.Empty;
            }
        }

        protected override void LoadObject(int id)
        {
            lev = StemDataService.GetEducationLevel(id);
        }

        #endregion


        #region user interactions

        public void Save()
        {
            if (IsNew)
            {
                if (Level.Text.Trim() == string.Empty)
                {
                    Reset();
                    return;
                }

                lev = new EducationLevel();
                lev.Level = Level.Text;
                lev.Description = Description.Text;

                StemDataService.CreateEducationLevel(lev);
            }
            else
            {
                lev = new EducationLevel();
                lev.EducationLevelID = Convert.ToInt32(LevelID.Text);
                lev.Level = Level.Text;
                lev.Description = Description.Text;

                StemDataService.UpdateEducationLevel(lev);
            }

            Reset();
        }

        public void Delete()
        {
            lev = new EducationLevel();
            lev.EducationLevelID = Convert.ToInt32(LevelID.Text);

            StemDataService.DeleteEducationLevel(lev);

            Reset();
        }

        #endregion
    }
}
