using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;
//using RatingsDetailedTableAdapters;
using Sony.SFS.TrackRecord.Controls.TrackRecordDataSetTableAdapters;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using CrystalDecisions.Web;

namespace Sony.SFS.TrackRecord.Controls
{
    public class ReportViewer : TemplatedWebControl
    {
        //private repo
        public string ReportName
        {
            get {
                object rn = ViewState["ReportName"];

                if (rn == null)
                {
                    rn = "none.rpt";

                    ViewState["ReportName"] = "none.rpt";
                }

                return (string)rn;
            }
            set { ViewState["ReportName"] = value; }
        }
        
        CrystalReportViewer CrystalReportViewer;
        TRContext context = TRContext.Current;

        protected override void AttachChildControls()
        {
            CrystalReportViewer = (CrystalReportViewer)FindControl("CrystalReportViewer");
            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            ConfigureCrystalReports(); 
        }

        private void ConfigureCrystalReports()
        {
            TrackRecordDataSet ds1 = new TrackRecordDataSet();
            
        
            string reportPath = context.MapPath("~/Reports/" + ReportName);

            ReportDocument RatingsRep = new ReportDocument();

            RatingsRep.Load(reportPath);

            RatingsDetailed rds = new RatingsDetailed();
            vw_RatingsDetailedTableAdapter ta = new vw_RatingsDetailedTableAdapter();
            TrackRecordDataSet.vw_RatingsDetailedDataTable dt = ta.GetData();

            ////DataTable table = Ratings1.vw_RatingOverviewDataTable;
            RatingsRep.SetDataSource((System.Data.DataTable)dt);

            CrystalReportViewer.DisplayGroupTree = false;
            CrystalReportViewer.Drill += new DrillEventHandler(CrystalReportViewer_Drill);
            CrystalReportViewer.Search += new SearchEventHandler(CrystalReportViewer_Search);
            CrystalReportViewer.Width = new Unit(600);

            CrystalReportViewer.ReportSource = RatingsRep;


        }

        public void LoadReport()
        {
            ConfigureCrystalReports();
        }

        void CrystalReportViewer_Search(object source, SearchEventArgs e)
        {
            string s = "P";
            
        }

        void CrystalReportViewer_Drill(object source, DrillEventArgs e)
        {
            string s = "P";
        }

    }
}
