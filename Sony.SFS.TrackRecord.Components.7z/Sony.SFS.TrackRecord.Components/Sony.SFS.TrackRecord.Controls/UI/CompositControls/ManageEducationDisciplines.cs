using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class ManageEducationDisciplines : BaseCrudOverviewControl
    {
        Literal DisciplineID;
        TextBox Discipline;
        TextBox Description;
        EducationDiscipline dis;

        #region TemplatedWebControl members

        protected override void AttachChildControls()
        {
            base.AttachChildControls();

            DisciplineID = (Literal)CrudView.FindControl("DisciplineID");
            Discipline = (TextBox)CrudView.FindControl("Discipline");
            Description = (TextBox)CrudView.FindControl("Description");

            InitializeChildControls();
        }

        protected override void InitializeChildControls()
        {
            OverviewHeader.Text = "Disciplines";
            CrudHeader.Text = "Disciplines";
            ManageMV.SetActiveView(OverviewView);

            Overview.ItemCommand += new RepeaterCommandEventHandler(Overview_ItemCommand);

            base.InitializeChildControls();
        }

        #endregion

        #region event handlers
        void Overview_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "select":
                    int id = Convert.ToInt32(e.CommandArgument);
                    Edit(id);
                    break;
            }
        }

        #endregion

        #region BaseCrudOverviewControl members

        protected override IList GetData()
        {
            List<IAutoDropDownItem> disses = StemDataService.GetEducationDisciplines();

            return disses;
        }

        protected override void LoadCrud()
        {
            if (!IsNew)
            {
                DisciplineID.Text = dis.EducationDisciplineID.ToString();
                Discipline.Text = dis.Discipline;
                Description.Text = dis.Description;
            }
            else
            {
                dis = new EducationDiscipline();
                DisciplineID.Text = "n.v.t.";
                Discipline.Text = string.Empty;
                Description.Text = string.Empty;
            }
        }

        protected override void LoadObject(int id)
        {
            dis = StemDataService.GetEducationDiscipline(id);
        }

        #endregion


        #region user interactions

        public void Save()
        {
            if (IsNew)
            {
                if (Discipline.Text.Trim() == string.Empty)
                {
                    Reset();
                    return;
                }

                dis = new EducationDiscipline();
                dis.Discipline = Discipline.Text;
                dis.Description = Description.Text;

                StemDataService.CreateEducationDiscipline(dis);
            }
            else
            {
                dis = new EducationDiscipline();
                dis.EducationDisciplineID = Convert.ToInt32(DisciplineID.Text);
                dis.Discipline = Discipline.Text;
                dis.Description = Description.Text;

                StemDataService.UpdateEducationDiscipline(dis);
            }

            Reset();
        }

        public void Delete()
        {
            dis = new EducationDiscipline();
            dis.EducationDisciplineID = Convert.ToInt32(DisciplineID.Text);

            StemDataService.DeleteEducationDiscipline(dis);

            Reset();
        }

        #endregion
    }
}
