using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class EmployeeWorkstyleRatings : TemplatedWebControl
    {
        RepeaterPlusNone Ratings;
        Panel RatingEdit;
        WorkstyleRatingDropDown NewRating;
        YearDropDown NewYear;
        FileUpload WorkstyleFile;

        IconButton New;
        IconButton Save;
        IconButton Cancel;

        TRContext context = TRContext.Current;

        private bool IsNew
        {
            get
            {
                object isn = ViewState["IsNew"];

                if (isn == null)
                {
                    isn = true;

                    ViewState["IsNew"] = true;
                }

                return (bool)isn;

            }

            set { ViewState["IsNew"] = value; }
        }

        public int RatingID
        {
            get
            {
                object aid = ViewState["RatingID"];

                if (aid == null)
                {
                    aid = 0;

                    ViewState["RatingID"] = 0;
                }

                return (int)aid;
            }
            set { ViewState["RatingID"] = value; }
        }

        protected override void AttachChildControls()
        {
            Ratings = (RepeaterPlusNone)FindControl("Ratings");
            RatingEdit = (Panel)FindControl("RatingEdit");
            
            NewYear = (YearDropDown)FindControl("NewYear");
            WorkstyleFile = (FileUpload)FindControl("WorkstyleFile");
            NewRating = (WorkstyleRatingDropDown)FindControl("NewRating");


            New = (IconButton)FindControl("New");
            Save = (IconButton)FindControl("Save");
            Cancel = (IconButton)FindControl("Cancel");

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            Ratings.ItemDataBound += new RepeaterItemEventHandler(Ratings_ItemDataBound);
            Ratings.ItemCommand += new RepeaterCommandEventHandler(Ratings_ItemCommand);

            New.Click += new EventHandler(New_Click);
            Save.Click += new EventHandler(Save_Click);
            Cancel.Click += new EventHandler(Cancel_Click);

            DataBind();
        }

        public override void DataBind()
        {
            Ratings.DataSource = EmployeesDataService.GetWorkstyleRatings(context.Employee.EmployeeNumber);
            Ratings.DataBind();
            base.DataBind();
        }

        #region repeater events

        void Ratings_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            RatingID = Convert.ToInt32(e.CommandArgument);

            switch (e.CommandName)
            {
                case "edit":
                    EditRating();
                    break;
                case "delete":
                    WorkstyleRating rating = new WorkstyleRating();
                    rating.WorkstyleId = RatingID;
                    EmployeesDataService.DeleteWorkstyleRating(rating);
                    DataBind();
                    break;
            }
        }

        private void EditRating()
        {
            IsNew = false;
            RatingEdit.Visible = true;

            WorkstyleRating rating = EmployeesDataService.GetWorkstyleRating(RatingID);

            NewYear.Select(rating.Year);
            NewRating.Select((int) rating.Rating);


        }

        void Ratings_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                WorkstyleRating rating = (WorkstyleRating)e.Item.DataItem;

                Literal RateYear = (Literal)e.Item.FindControl("RateYear");
                Literal Rating = (Literal)e.Item.FindControl("Rating");
                HyperLink WorkstyleRating = (HyperLink)e.Item.FindControl("WorkstyleRating");
                LinkButton Edit = (LinkButton)e.Item.FindControl("Edit");
                LinkButton Delete = (LinkButton)e.Item.FindControl("Delete");

                RateYear.Text = rating.Year.ToString();
                Rating.Text = Translator.WorkstyleRating(rating);
                WorkstyleRating.Text = "Workstyle rating";
                WorkstyleRating.NavigateUrl = Globals.PathCombine(Globals.WorkStylesPath, rating.Attachment);

                Edit.CommandName = "edit";
                Edit.CommandArgument = rating.WorkstyleId.ToString();
                Edit.Visible = false;

                Delete.CommandName = "delete";
                Delete.CommandArgument = rating.WorkstyleId.ToString();
                Delete.Visible = false;


                
            }
        }

        #endregion

        #region button events
        void Cancel_Click(object sender, EventArgs e)
        {
            RatingEdit.Visible = false;
            ClearRatingEdit();
        }

        void Save_Click(object sender, EventArgs e)
        {
            if (IsNew)
            {
                WorkstyleRating rating = new WorkstyleRating();

                rating.EmployeeID = context.Employee.EmployeeNumber;
                rating.Rating = (WorkstyleRatingLevel)NewRating.SelectedID;
                rating.Year = NewYear.SelectedValue;

                if (WorkstyleFile.HasFile)
                {
                    string fileName = context.EmployeeNumber.ToString() + WorkstyleFile.FileName;
                    string filePath = Globals.PathCombine(Globals.WorkStylesPath, fileName);
                    WorkstyleFile.PostedFile.SaveAs(context.MapPath(filePath));

                    rating.Attachment = fileName;
                }

                
                EmployeesDataService.CreateWorkstyleRating(rating);
            }
            else
            {
                WorkstyleRating rating1 = EmployeesDataService.GetWorkstyleRating(RatingID);

                rating1.Rating = (WorkstyleRatingLevel)NewRating.SelectedID;
                rating1.Year = NewYear.SelectedValue;

                if (WorkstyleFile.HasFile)
                {
                    string fileName = context.EmployeeNumber.ToString() + WorkstyleFile.FileName;
                    string filePath = Globals.PathCombine(Globals.WorkStylesPath, fileName);
                    WorkstyleFile.PostedFile.SaveAs(context.MapPath(filePath));

                    rating1.Attachment = fileName;
                }

                EmployeesDataService.UpdateWorkstyleRating(rating1);
            }

            RatingEdit.Visible = false;
            DataBind();
        }

        void New_Click(object sender, EventArgs e)
        {
            IsNew = true;
            
            RatingEdit.Visible = true;
        }

        #endregion

        private void ClearRatingEdit()
        {
            NewYear.Text = string.Empty;
        }

    }
}
