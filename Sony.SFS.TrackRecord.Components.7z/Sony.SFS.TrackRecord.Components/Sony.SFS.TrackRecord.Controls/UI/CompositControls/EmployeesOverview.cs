using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;
using Sony.SFS.TrackRecord.Collections;


namespace Sony.SFS.TrackRecord.Controls
{
    public class EmployeesOverview : TemplatedWebControl
    {
        RepeaterPlusNone Employees;
        Pager Pager;
        TRContext context = TRContext.Current;

        public SortEmployeesBy SortBy
        {
            get
            {
                object s = ViewState["SortBy"];

                if (s == null)
                {
                    ViewState["SortBy"] = SortEmployeesBy.EmployeeNumber;
                    return SortEmployeesBy.EmployeeNumber;
                }

                return (SortEmployeesBy)s;
            }
            set
            {
                ViewState["SortBy"] = value;
            }
        }

        public SortOrder SortOrder
        {
            get
            {
                object s = ViewState["SortOrder"];

                if (s == null)
                {
                    ViewState["SortOrder"] = SortOrder.Ascending;
                    return SortOrder.Ascending;
                }

                return (SortOrder)s;
            }
            set
            {
                ViewState["SortOrder"] = value;
            }
        }

        protected override void AttachChildControls()
        {
            Employees = (RepeaterPlusNone)FindControl("Employees");
            Pager = (Pager)FindControl("Pager");
           
            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            Employees.ItemDataBound += new RepeaterItemEventHandler(Employees_ItemDataBound);
            Employees.ItemCommand += new RepeaterCommandEventHandler(Employees_ItemCommand);

            this.DataBind();
        }

        void Employees_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "Sort":
                    SortEmployeesBy s1 = (SortEmployeesBy) Enum.Parse(typeof(SortEmployeesBy), Convert.ToString(e.CommandArgument));

                    if (s1 == this.SortBy)
                        this.SortOrder = this.SortOrder == SortOrder.Ascending ? SortOrder.Descending : SortOrder.Ascending;
                    else
                    {
                        this.SortOrder = SortOrder.Ascending;
                        this.SortBy = s1;
                    }
                    DataBind();
                    break;

                case "Select":
                    int employeeNumber = Convert.ToInt32(e.CommandArgument);
                    string editPath = "/TrackRecord/Employees/Details/Default.aspx?empid={0}";

                    context.Redirect(string.Format(editPath, employeeNumber));
                    break;
            }
        }

        void Employees_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Header)
            {
                ThemedImageButton Sort3 = (ThemedImageButton)e.Item.FindControl("Sort3");
                ThemedImageButton Sort4 = (ThemedImageButton)e.Item.FindControl("Sort4");
                ThemedImageButton Sort5 = (ThemedImageButton)e.Item.FindControl("Sort5");
                ThemedImageButton Sort6 = (ThemedImageButton)e.Item.FindControl("Sort6");
                ThemedImageButton Sort7 = (ThemedImageButton)e.Item.FindControl("Sort7");

                Sort3.Visible = false;
                Sort4.Visible = false;
                Sort5.Visible = false;
                Sort6.Visible = false;
                Sort7.Visible = false;

                Sort3.Height = new Unit(8);
                Sort3.Width = new Unit(8);
                Sort4.Height = new Unit(8);
                Sort4.Width = new Unit(8);
                Sort5.Height = new Unit(8);
                Sort5.Width = new Unit(8);
                Sort6.Height = new Unit(8);
                Sort6.Width = new Unit(8);
                Sort7.Height = new Unit(8);
                Sort7.Width = new Unit(8);


                string imageUrl = this.SortOrder == SortOrder.Ascending ? "/images/up.gif" : "/images/down.gif";

                switch (this.SortBy)
                {
                    case SortEmployeesBy.RoepNaam:
                        Sort3.ImageUrl = imageUrl;
                        Sort3.Visible = true;
                        break;
                    case SortEmployeesBy.Naam:
                        Sort4.ImageUrl = imageUrl;
                        Sort4.Visible = true;
                        break;
                    case SortEmployeesBy.Woonplaats:
                        Sort5.ImageUrl = imageUrl;
                        Sort5.Visible = true;
                        break;
                    case SortEmployeesBy.Beroep:
                        Sort6.ImageUrl = imageUrl;
                        Sort6.Visible = true;
                        break;
                    case SortEmployeesBy.AfdelingsNummer:
                        Sort7.ImageUrl = imageUrl;
                        Sort7.Visible = true;
                        break;
                    default:
                        Sort4.ImageUrl = imageUrl;
                        Sort4.Visible = true;
                        break;


                }
            }


            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                PrimusEmployee prim = (PrimusEmployee)e.Item.DataItem;

                //Literal SAPID = (Literal)e.Item.FindControl("SAPID");
                Literal Aanhef = (Literal)e.Item.FindControl("Aanhef");
                Literal RoepNaam = (Literal)e.Item.FindControl("RoepNaam");
                LinkButton Naam = (LinkButton)e.Item.FindControl("Naam");
                Literal Woonplaats = (Literal)e.Item.FindControl("Woonplaats");
                Literal Functie = (Literal)e.Item.FindControl("Functie");
                Literal Afdeling = (Literal)e.Item.FindControl("Afdeling");
                ThemedImageButton Img1 = (ThemedImageButton)e.Item.FindControl("Img1");


               // SAPID.Text = string.Empty;
                Aanhef.Text = prim.Aanhef == 1 ? "Dhr." : "Mevr.";
                RoepNaam.Text = prim.RoepNaam;
                Naam.Text = prim.Naam;
                Woonplaats.Text = prim.Woonplaats;
                Functie.Text = prim.FunctieOmschrijving;
                Afdeling.Text = prim.AfdelingsNummer.ToString();
                Img1.Visible = prim.Image.Filename == "noimage.gif" ? false : true;

                Naam.CommandArgument = prim.EmployeeNumber.ToString();
                Naam.CommandName = "Select";
            }
        }

        public override void DataBind()
        {
            EmployeeSet eset = EmployeesDataService.GetEmployees(Pager.PageIndex, Pager.PageSize, this.SortBy, this.SortOrder);

            Pager.TotalRecords = eset.TotalRecords;

            Employees.DataSource = eset.Items;
            Employees.DataBind();
        }
       

    }
}
