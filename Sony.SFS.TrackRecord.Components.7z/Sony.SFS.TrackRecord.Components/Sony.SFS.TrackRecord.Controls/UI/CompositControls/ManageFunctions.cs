using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class ManageFunctions : BaseCrudOverviewControl
    {
        Literal FunctionID;
        TextBox FunctionTitle;
        TextBox Description;
        DropDownList DesiredDuration;
        TextBox Division;
        DepartmentDropDown Department;
        TextBox Location;
        TextBox Manages;
        TextBox Requirements;
        TextBox FunctionGoals;
        TextBox Responsibilities;
        TextBox KeyPerformanceIndicators;
        CheckBox Managing;

        Function func;

        #region TemplatedWebControl members

        protected override void AttachChildControls()
        {
            base.AttachChildControls();

            FunctionID = (Literal)CrudView.FindControl("FunctionID");
            FunctionTitle = (TextBox)CrudView.FindControl("FunctionTitle");
            Description = (TextBox)CrudView.FindControl("Description");
            DesiredDuration = (DropDownList)CrudView.FindControl("DesiredDuration");
            Division = (TextBox)CrudView.FindControl("Division");
            Department = (DepartmentDropDown)CrudView.FindControl("Department");
            Location = (TextBox)CrudView.FindControl("Location");
            Manages = (TextBox)CrudView.FindControl("Manages");
            Requirements = (TextBox)CrudView.FindControl("Requirements");
            FunctionGoals = (TextBox)CrudView.FindControl("FunctionGoals");
            Responsibilities = (TextBox)CrudView.FindControl("Responsibilities");
            KeyPerformanceIndicators = (TextBox)CrudView.FindControl("KeyPerformanceIndicators");
            Managing = (CheckBox) FindControl("Managing");


            InitializeChildControls();
        }

        protected override void InitializeChildControls()
        {
            OverviewHeader.Text = "Functies";
            CrudHeader.Text = "Functies";
            ManageMV.SetActiveView(OverviewView);

            Overview.ItemCommand += new RepeaterCommandEventHandler(Overview_ItemCommand);

            base.InitializeChildControls();
        }

        #endregion

        #region event handlers
        void Overview_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "select":
                    int id = Convert.ToInt32(e.CommandArgument);
                    Edit(id);
                    break;
            }
        }

        #endregion

        #region BaseCrudOverviewControl members

        protected override IList GetData()
        {
            Sony.SFS.TrackRecord.Collections.FunctionSet funcs = StemDataService.GetFunctions();

            return funcs.Items;
        }

        protected override void LoadCrud()
        {
            if (IsNew)
            {
                func = new Function();
                FunctionID.Text = "n.v.t.";
            }
            else
            {
                FunctionID.Text = func.FunctionID.ToString();
            }

            FunctionTitle.Text = func.Title;
            Description.Text = func.Description;
            DesiredDuration.SelectedIndex = DesiredDuration.Items.IndexOf(DesiredDuration.Items.FindByValue(func.DesiredDuration.ToString()));
            Division.Text = func.Division;
            Department.SelectedIndex = Department.Items.IndexOf(Department.Items.FindByValue(func.DepartmentID.ToString()));
            Location.Text = func.Location;
            Manages.Text = func.Manages;
            FunctionGoals.Text = func.FunctionGoals;
            Responsibilities.Text = func.Responsibilities;
            KeyPerformanceIndicators.Text = func.KeyPerformanceIndicators;
            Requirements.Text = func.Requirements;
            Managing.Checked = func.Managing;
        }

        protected override void LoadObject(int id)
        {
            func = StemDataService.GetFunction(id);
        }

        #endregion


        #region user interactions
       

        public void Save()
        {
            func = new Function();

            func.Title = FunctionTitle.Text;
            func.Description = Description.Text;
            func.Requirements = Requirements.Text;
            func.DesiredDuration = Convert.ToInt32(DesiredDuration.SelectedValue);
            func.DepartmentID = Convert.ToInt32(Department.SelectedValue);
            func.Division = Division.Text;
            func.Location = Location.Text;
            func.Manages = Manages.Text;
            func.FunctionGoals = FunctionGoals.Text;
            func.Responsibilities = Responsibilities.Text;
            func.KeyPerformanceIndicators = KeyPerformanceIndicators.Text;
            func.Managing = Managing.Checked;

            if (IsNew)
            {
                StemDataService.CreateFunction(func);
            }
            else
            {
                func.FunctionID = Convert.ToInt32(FunctionID.Text);

                StemDataService.UpdateFunction(func);
            }

            Reset();
        }

        public void Delete()
        {
            func = new Function();

            func.FunctionID = Convert.ToInt32(FunctionID.Text);
            
            StemDataService.DeleteFunction(func);

            Reset();
        }

        #endregion
    }
}
