using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class EmployeeOtherAmbitions : TemplatedWebControl
    {
        RepeaterPlusNone Other;
        Panel AmbitionEdit;
        IconButton New;
        IconButton Save;
        IconButton Cancel;
        TextBox NewOtherAmbition;
        TRContext context = TRContext.Current;

        private bool IsNew
        {
            get
            {
                object isn = ViewState["IsNew"];

                if (isn == null)
                {
                    isn = true;

                    ViewState["IsNew"] = true;
                }

                return (bool)isn;

            }

            set { ViewState["IsNew"] = value; }
        }

        public int AmbitionID
        {
            get
            {
                object aid = ViewState["AmbitionID"];

                if (aid == null)
                {
                    aid = 0;

                    ViewState["AmbitionID"] = 0;
                }

                return (int)aid;
            }
            set { ViewState["AmbitionID"] = value; }
        }

        protected override void AttachChildControls()
        {

            Other = (RepeaterPlusNone)FindControl("Other");
            AmbitionEdit = (Panel)FindControl("AmbitionEdit");
            New = (IconButton)FindControl("New");
            Save = (IconButton)FindControl("Save");
            Cancel = (IconButton)FindControl("Cancel");
            NewOtherAmbition = (TextBox)FindControl("NewOtherAmbition");

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            Other.ItemCommand += new RepeaterCommandEventHandler(Other_ItemCommand);
            Other.ItemDataBound += new RepeaterItemEventHandler(Other_ItemDataBound);

            Save.Click += new EventHandler(Save_Click);
            Cancel.Click += new EventHandler(Cancel_Click);
            New.Click += new EventHandler(New_Click);

            DataBind();
        }

        void New_Click(object sender, EventArgs e)
        {
            IsNew = true;
            ClearAmbitionEdit();
            AmbitionEdit.Visible = true;
        }

        void Cancel_Click(object sender, EventArgs e)
        {
            AmbitionEdit.Visible = false;
            ClearAmbitionEdit();
        }

        void Save_Click(object sender, EventArgs e)
        {
            if (IsNew)
            {
                EmployeeAmbition ambition = new EmployeeAmbition();
                
                ambition.AmbitionChoiceType = AmbitionChoiceType.Text;
                ambition.AmbitionID = 0;
                ambition.ChoiceID = 0;
                ambition.AmbitionText = NewOtherAmbition.Text;
                ambition.EmployeeID = context.Employee.EmployeeId;
                EmployeesDataService.CreateEmployeeAmbition(ambition);
            }
            else
            {
                EmployeeAmbition ambition1 = EmployeesDataService.GetEmployeeAmbition(AmbitionID);

                ambition1.AmbitionChoiceType = AmbitionChoiceType.Choice;
                ambition1.AmbitionID = 0;
                ambition1.ChoiceID = 0;
                ambition1.AmbitionText = NewOtherAmbition.Text;

                ambition1.EmployeeID = context.Employee.EmployeeId;
                EmployeesDataService.UpdateEmployeeAmbition(ambition1);
            }

            AmbitionEdit.Visible = false;
            DataBind();
        }

        private void ClearAmbitionEdit()
        {
            NewOtherAmbition.Text = string.Empty;
        }

        void Other_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                EmployeeAmbition ambition = (EmployeeAmbition)e.Item.DataItem;

                Literal Ambition = (Literal)e.Item.FindControl("Ambition");
                LinkButton RowEdit = (LinkButton)e.Item.FindControl("Edit");
                LinkButton RowDelete = (LinkButton)e.Item.FindControl("Delete");

                Ambition.Text = ambition.AmbitionText;

                RowEdit.CommandArgument = ambition.EmployeeAmbitionID.ToString();
                RowEdit.CommandName = "edit";

                RowDelete.CommandArgument = ambition.EmployeeAmbitionID.ToString();
                RowDelete.CommandName = "delete";


            }
        }

        void Other_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            AmbitionID = Convert.ToInt32(e.CommandArgument);

            switch (e.CommandName)
            {
                case "edit":
                    EditAmbition();

                    break;

                case "delete":
                    EmployeesDataService.DeleteEmployeeAmbition(new EmployeeAmbition(AmbitionID));
                    DataBind();
                    break;
            }
        }

        public override void DataBind()
        {
            Other.DataSource = EmployeesDataService.GetEmployeeAmbitionTexts(context.EmployeeNumber);
            Other.DataBind();
            base.DataBind();
        }

        private void EditAmbition()
        {
            IsNew = false;
            AmbitionEdit.Visible = true;

            EmployeeAmbition amb = EmployeesDataService.GetEmployeeAmbition(AmbitionID);

            NewOtherAmbition.Text = amb.AmbitionText;

        }

    }
}
