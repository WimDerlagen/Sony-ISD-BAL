using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class EmployeeGenericInfo : TemplatedWebControl
    {
        Literal Name;
      //  Literal Address;
      //  Literal Zip;
      //  Literal City;
        Literal Sexe;
        Literal BirthDate;
        Literal Function;
        Literal FunctionSince;
        Literal InDienst;
        Literal FTE;
        TRContext context = TRContext.Current;


        protected override void AttachChildControls()
        {
            Name = (Literal)FindControl("Name");
        //    Address = (Literal)FindControl("Address");
        //    Zip = (Literal)FindControl("Zip");
        //    City = (Literal)FindControl("City");
            Sexe = (Literal)FindControl("Sexe");
            BirthDate = (Literal)FindControl("BirthDate");
            Function = (Literal)FindControl("Function");
            FunctionSince = (Literal)FindControl("FunctionSince");
            InDienst = (Literal)FindControl("InDienst");
            FTE = (Literal)FindControl("FTE");

            if (context.Employee.Function != null)
            {
                Function.Text = context.Employee.Function.Function.Title;
                FunctionSince.Text = context.Employee.Function.StartDate.ToShortDateString();
            }
            InDienst.Text = context.Employee.DatumInDienstSony.ToShortDateString();

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {
            int empId = Convert.ToInt32(TRContext.Current.Context.Request.QueryString["empid"]);

            PrimusEmployee prim = EmployeesDataService.GetEmployee(empId);
            Name.Text = Translator.FirstCap(prim.RoepNaam) + " " + Translator.FirstCap(prim.Naam);
          //  Address.Text = prim.Address1;
          //  Zip.Text = prim.ZipCode;
          //  City.Text = Translator.FirstCap(prim.Woonplaats);
            Sexe.Text = prim.Aanhef == 1 ? "M" : "V";
            BirthDate.Text = prim.GeboorteDatum.ToShortDateString();
            FTE.Text = prim.FTE.ToString();


        }

    }
}
