using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using AjaxControlToolkit;
using AjaxControlToolkit.Design;

using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class DateBox : TemplatedWebControl
    {
        TextBox DateTextBox;
      

        public string Text
        {
            get { return DateTextBox.Text; }
            set { DateTextBox.Text = value; }
        }

        public DateTime Date
        {
            get
            {
                DateTime dt;
                try
                {
                    dt = Convert.ToDateTime(DateTextBox.Text);
                }
                catch
                {
                    dt = new DateTime(1900,1,1);
                }

                return dt;
            }
            set
            {
                DateTextBox.Text = value.ToShortDateString();
            }
        }

        protected override void AttachChildControls()
        {
            DateTextBox = (TextBox)FindControl("Date");

            InitializeChildControls();
        }

        private void InitializeChildControls()
        {

        }

    }
}
