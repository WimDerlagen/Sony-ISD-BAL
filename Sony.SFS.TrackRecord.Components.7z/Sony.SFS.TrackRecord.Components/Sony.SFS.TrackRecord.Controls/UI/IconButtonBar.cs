using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace Sony.SFS.TrackRecord.Controls
{
    public delegate void ButtonClickEventHandler(object sender, ButtonClickEventArgs e);
   
    public class IconButtonBar : Control
    {
        //private IconBarModes barMode;
        private ArrayList controls;

        private IconButton butNew;
        private IconButton butCancel;
        private IconButton butDelete;
        private IconButton butSave;
        private IconButton butBack;
        private IconButton butEdit;
        private IconButton butRefresh;
        private IconButton butImport;
        private IconButton butOverview;
        private LiteralControl butEmpty;

        public IconBarModes IconBarMode
        {
            get 
            { 
                object mode = ViewState["BarMode"];
                if (mode == null)
                {
                    mode = IconBarModes.Overview;

                    ViewState["BarMode"] = mode;

                    
                }

                return (IconBarModes) mode;
            }
            set { //this.SetIconBarMode(value); 
                ViewState["BarMode"] = value;
                }
        }

        public IconButtonBar()
        {
            InitializeButtons();

            InitializeBar();
        }

       

        public void SetIconBarMode()
        {
            InitializeBar();
        }

        public void SetIconBarMode(IconBarModes mode)
        {
            //IconBarMode = mode;
            IconBarMode = IconBarModes.Edit;

            InitializeBar();
        }

        public void Add(IconButtonType type)
        {
            IconButton but = new IconButton(type);
            this.controls.Add(but);
        }

        private void InitializeButtons()
        {
            butNew = new IconButton(IconButtonType.New);
            butCancel = new IconButton(IconButtonType.Cancel);
            butDelete = new IconButton(IconButtonType.Delete);
            butSave = new IconButton(IconButtonType.Save);
            butBack = new IconButton(IconButtonType.Back);
            butEdit = new IconButton(IconButtonType.Edit);
            butRefresh = new IconButton(IconButtonType.Refresh);
            butImport = new IconButton(IconButtonType.Import);
            butOverview = new IconButton(IconButtonType.Overview);

            butEmpty = new LiteralControl("<div >&nbsp;&nbsp;&nbsp;&nbsp;</div>");


            //use event bubbling instead

            //butNew.Click += new EventHandler(butNew_Click);
            //butCancel.Click += new EventHandler(butCancel_Click);
            //butDelete.Click += new EventHandler(butDelete_Click);
            //butSave.Click += new EventHandler(butSave_Click);
            //butBack.Click += new EventHandler(butBack_Click);
            //butEdit.Click += new EventHandler(butEdit_Click);
            //butRefresh.Click += new EventHandler(butRefresh_Click);
            //butImport.Click += new EventHandler(butImport_Click);
            //butOverview.Click += new EventHandler(butOverview_Click);
        }

        #region events

        //disabled, use event bubbling instead
        /*

        public event ButtonClickEventHandler New;
        public event ButtonClickEventHandler Cancel;
        public event ButtonClickEventHandler Delete;
        public event ButtonClickEventHandler Save;
        public event ButtonClickEventHandler Back;
        public event ButtonClickEventHandler Edit;
        public event ButtonClickEventHandler Refresh;
        public event ButtonClickEventHandler Import;
        public event ButtonClickEventHandler Overview;

        public void OnNew()
        {
            if (New != null)
                New(this, new ButtonClickEventArgs());
        }

        public void OnCancel()
        {
            if (Cancel != null)
                Cancel(this, new ButtonClickEventArgs());
        }

        public void OnDelete()
        {
            if (Delete != null)
                Delete(this, new ButtonClickEventArgs());
        }

        public void OnSave()
        {
            if (Save != null)
                Save(this, new ButtonClickEventArgs());
        }

        public void OnEdit()
        {
            if (Edit != null)
                Edit(this, new ButtonClickEventArgs());
        }

        public void OnRefresh()
        {
            if (Refresh != null)
                Refresh(this, new ButtonClickEventArgs());
        }

        public void OnImport()
        {
            if (Import != null)
                Import(this, new ButtonClickEventArgs());
        }

        public void OnOverview()
        {
            if (Overview != null)
                Overview(this, new ButtonClickEventArgs());
        }

        public void OnBack()
        {
            if (Back != null)
                Back(this, new ButtonClickEventArgs());
        }

        

        void butOverview_Click(object sender, EventArgs e)
        {
            OnOverview();
        }

        void butImport_Click(object sender, EventArgs e)
        {
            OnImport();
        }

        void butRefresh_Click(object sender, EventArgs e)
        {
            OnRefresh();
        }

        void butEdit_Click(object sender, EventArgs e)
        {
            OnEdit();
        }

        void butBack_Click(object sender, EventArgs e)
        {
            OnBack();
        }

        void butSave_Click(object sender, EventArgs e)
        {
            OnSave();
        }

        void butDelete_Click(object sender, EventArgs e)
        {
            OnDelete();
        }

        void butCancel_Click(object sender, EventArgs e)
        {
            OnCancel();
        }

        void butNew_Click(object sender, EventArgs e)
        {
            OnNew();
        }

         */


        #endregion
        

        private void InitializeBar()
        {
            controls = new ArrayList();
            this.Controls.Clear();
            IconBarModes mode = IconBarModes.Edit;

            switch (mode)
            {
                case IconBarModes.Create:
                    Control[] cs = new Control[4] {
                    butBack,
                    butOverview,
                    butEmpty,
                    butSave};

                    this.controls.AddRange(cs);
                    break;

                case IconBarModes.Edit:
                    Control[] cs1 = new Control[6] {
                    butBack,
                    butOverview,
                    butEmpty,
                    butNew,
                    butSave,
                    butDelete};

                    this.controls.AddRange(cs1);


                    break;

                case IconBarModes.Overview:
                    this.controls.Add(butNew);
                    break;
            }

            foreach (Control c in controls)
            {
                Controls.Add(c);
            }
        }

        
    }
}
