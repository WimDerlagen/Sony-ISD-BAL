using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using AjaxControlToolkit;
using AjaxControlToolkit.Design;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class ValidatingDateBox : Control, INamingContainer
    {
        TextBox DateTextBox;
        RegularExpressionValidator regexVal;
        MaskedEditExtender editExtender;
        ValidatorCalloutExtender callOut;

        public string Text
        {
            get { return DateTextBox.Text; }
        }

        public DateTime Date
        {
            get
            {
                try
                {
                    return Convert.ToDateTime(DateTextBox.Text);
                }
                catch {
                    return new DateTime(1900,1,1);
                }
            }
            set
            {
                DateTextBox.Text = value.ToShortDateString();
            }
        }



        public ValidatingDateBox() {
            DateTextBox = new TextBox();
            DateTextBox.ID = "ValidatedDate";

            regexVal = new RegularExpressionValidator();
            regexVal.ID = "DateRegexVal";
            regexVal.ErrorMessage = "Datum formaat is niet correct.Gebruik het formaat dd/mm/yyyy";
            regexVal.ValidationExpression = @"(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d";
            regexVal.ControlToValidate = "ValidatedDate";
            regexVal.Display = ValidatorDisplay.None;

            editExtender = new MaskedEditExtender();
            editExtender.TargetControlID = "ValidatedDate";
            editExtender.Mask = "99/99/9999";

            //callOut = new ValidatorCalloutExtender();
            //callOut.ID = "CallOutExt";
            //callOut.TargetControlID = "DateRegexVal";
            //callOut.Width = new Unit(250);

        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            this.Controls.Add(DateTextBox);
            this.Controls.Add(regexVal);
            this.Controls.Add(editExtender);
            //this.Controls.Add(callOut);
        }
    }
}
