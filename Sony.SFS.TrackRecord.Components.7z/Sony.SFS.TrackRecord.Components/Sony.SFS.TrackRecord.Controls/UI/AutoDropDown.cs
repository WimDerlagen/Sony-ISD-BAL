using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class AutoDropDown : TemplatedWebControl
    {
        TextBox TextControl;
        Repeater rItems;

        public string Text
        {
            get { return TextControl.Text; }
            set { TextControl.Text = value; }
        }

        public int Value
        {
            get
            {
                object vl = ViewState["DropValue"];

                if (vl == null)
                {
                    vl = 0;
                    ViewState["DropValue"] = 0;
                }

                return (int)vl;
            }
            set { ViewState["DropValue"] = value; }
        }

        private AutoDropDownType dropDownType;
        public AutoDropDownType DropDownType
        {
            get { return dropDownType; }
            set { dropDownType = value; }
        }

        protected override void AttachChildControls()
        {
            TextControl = (TextBox)FindControl("TextControl");
            rItems = (Repeater)FindControl("Items");
            
            InitializeChildControls();
            InitializeDropDownItems();
        }

        void rItems_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if(e.Item.ItemType == ListItemType.Item ||e.Item.ItemType == ListItemType.AlternatingItem)
            {
                LinkButton ItemLink = (LinkButton) e.Item.FindControl("ItemLink");
                IAutoDropDownItem drItem = (IAutoDropDownItem)e.Item.DataItem;

                string argu = "{0}|{1}";

                ItemLink.Text = drItem.Text;
                ItemLink.CommandName = "select";
                ItemLink.CommandArgument = string.Format(argu,drItem.Value.ToString(),drItem.Text);

            }
        }

        void rItems_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "select":
                    string[] args = e.CommandArgument.ToString().Split('|');
                    TextControl.Text = args[1];
                    Value = Convert.ToInt32(args[0]);
                    break;
            }
        }


        private void InitializeChildControls()
        {
            rItems.ItemCommand += new RepeaterCommandEventHandler(rItems_ItemCommand);
            rItems.ItemDataBound += new RepeaterItemEventHandler(rItems_ItemDataBound);
        }

        private void InitializeDropDownItems()
        {
            switch (DropDownType)
            {
                case AutoDropDownType.EducationDiscipline:
                    List<IAutoDropDownItem> dis = StemDataService.GetEducationDisciplines();
                    rItems.DataSource = dis;
                    rItems.DataBind();
                    break;
                case AutoDropDownType.EducationLevel:
                    List<IAutoDropDownItem> lev = StemDataService.GetEducationLevels();
                    rItems.DataSource = lev;
                    rItems.DataBind();
                    break;
            }
        }

    }
}
