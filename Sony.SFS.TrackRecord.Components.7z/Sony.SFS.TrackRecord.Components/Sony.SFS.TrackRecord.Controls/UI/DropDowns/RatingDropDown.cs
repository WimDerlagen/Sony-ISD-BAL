using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Sony.SFS.TrackRecord.Components;
using Sony.SFS.TrackRecord.Collections;

namespace Sony.SFS.TrackRecord.Controls
{
    public class RatingDropDown : CustomDropDown
    {
        private RatingType ratingType;

        public RatingType RatingType
        {
            get { return ratingType; }
            set { ratingType = value;
            DataBind();
            }
        }

        public override void DataBind()
        {
            ArrayList items = new ArrayList();
            Items.Clear();

            switch (RatingType)
            {
                case RatingType.EGrading:
                    items.Add(new ListItem("Selecteer rating", "0"));
                    items.Add(new ListItem("E03", "1" ));
                    items.Add(new ListItem("E04", "2"));
                    items.Add(new ListItem("E05", "3"));
                    items.Add(new ListItem("E10", "4"));
                    items.Add(new ListItem("E20", "5"));
                    items.Add(new ListItem("E30", "6"));
                    items.Add(new ListItem("E40", "7"));
                    items.Add(new ListItem("E50", "8"));
                    items.Add(new ListItem("E60", "9"));
                    break;
                case RatingType.WorkforcePlayer:
                case RatingType.WorkforcePosition:
                    items.Add(new ListItem("Selecteer rating", "0"));
                    items.Add(new ListItem("A", "1"));
                    items.Add(new ListItem("B", "2"));
                    items.Add(new ListItem("C", "3"));
                    break;
                case RatingType.PRatingHr:
                case RatingType.PRatingMgr:
                    items.Add(new ListItem("Selecteer rating", "0"));
                    items.Add(new ListItem("1", "1"));
                    items.Add(new ListItem("2", "2"));
                    items.Add(new ListItem("3", "3"));
                    items.Add(new ListItem("4", "4"));
                    items.Add(new ListItem("5", "5"));
                    items.Add(new ListItem("6", "6"));
                    items.Add(new ListItem("7", "7"));
                    break;

            }

            foreach (ListItem li in items)
            {
                Items.Add(li);
            }

            // this.DataSource = items;
            base.DataBind();
        }


    }
}
