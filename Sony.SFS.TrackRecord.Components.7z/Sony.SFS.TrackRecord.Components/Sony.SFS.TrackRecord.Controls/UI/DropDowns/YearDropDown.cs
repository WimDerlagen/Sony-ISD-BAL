using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Sony.SFS.TrackRecord.Components;
using Sony.SFS.TrackRecord.Collections;

namespace Sony.SFS.TrackRecord.Controls
{
    public class YearDropDown : CustomDropDown
    {
        public YearDropDown()
        {
            Items.Clear();

            ListItem li1 = new ListItem("FY03", "FY03");
            ListItem li2 = new ListItem("FY04", "FY04");
            ListItem li3 = new ListItem("FY05", "FY05");
            ListItem li4 = new ListItem("FY06", "FY06");
            ListItem li5 = new ListItem("FY07", "FY07");
            ListItem li6 = new ListItem("FY08", "FY08");
            ListItem li7 = new ListItem("FY09", "FY09");
            ListItem li8 = new ListItem("FY10", "FY10");
            ListItem li9 = new ListItem("FY11", "FY11");
            ListItem li10 = new ListItem("FY12", "FY12");

            Items.Add(li1);
            Items.Add(li2);
            Items.Add(li3);
            Items.Add(li4);
            Items.Add(li5);
            Items.Add(li6);
            Items.Add(li7);
            Items.Add(li8);
            Items.Add(li9);
            Items.Add(li10);


        }
    }
}
