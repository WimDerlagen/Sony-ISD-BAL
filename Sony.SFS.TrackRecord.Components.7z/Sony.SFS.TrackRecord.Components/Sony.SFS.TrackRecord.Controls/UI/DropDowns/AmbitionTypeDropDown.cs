using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Sony.SFS.TrackRecord.Components;
using Sony.SFS.TrackRecord.Collections;

namespace Sony.SFS.TrackRecord.Controls
{
    public class AmbitionTypeDropDown : CustomDropDown
    {
        public AmbitionTypeDropDown()
        {
            DataBind();
        }

        public override void DataBind()
        {
            this.DataTextField = "AmbitionTypeText";
            this.DataValueField = "AmbitionTypeID";

            List<AmbitionType> ambs = StemDataService.GetAmbitions();
            
            AmbitionType tp = new AmbitionType();
            tp.AmbitionTypeText = "Selecteer een ambitie";
            tp.AmbitionTypeID = 0;
            
            ambs.Insert(0, tp);

            this.DataSource = ambs;

            base.DataBind();
        }
    }
}
