using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class DepartmentDropDown : CustomDropDown
    {
        public override void DataBind()
        {
            this.DataTextField = "Name";
            this.DataValueField = "DepartmentNumber";

            List<Department> set = StemDataService.GetDepartments();

            Department dept = new Department();
            dept.DepartmentID = 0;
            dept.Name = "Selecteer een afdeling";

            set.Insert(0, dept);

            this.DataSource = set;
            base.DataBind();
        }

        
    }
}
