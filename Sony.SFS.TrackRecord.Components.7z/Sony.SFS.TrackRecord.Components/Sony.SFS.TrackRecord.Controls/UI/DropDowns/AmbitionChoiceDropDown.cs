using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Sony.SFS.TrackRecord.Components;
using Sony.SFS.TrackRecord.Collections;

namespace Sony.SFS.TrackRecord.Controls
{
    public class AmbitionChoiceDropDown : CustomDropDown
    {
        public void LoadChoices(int ambitionType)
        {
            this.DataTextField = "Choice";
            this.DataValueField = "AmbitionChoiceID";

            List<AmbitionChoice> choices = StemDataService.GetAmbitionChoices(ambitionType);

            AmbitionChoice choice = new AmbitionChoice();
            choice.Choice = "Selecteer een keuze";

            choices.Insert(0, choice);

            this.DataSource = choices;

            this.DataBind();
        }
    }
}
