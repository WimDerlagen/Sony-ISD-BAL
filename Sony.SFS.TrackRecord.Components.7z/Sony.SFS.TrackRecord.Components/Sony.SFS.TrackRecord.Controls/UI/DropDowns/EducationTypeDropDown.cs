using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Sony.SFS.TrackRecord.Components;
using Sony.SFS.TrackRecord.Collections;

namespace Sony.SFS.TrackRecord.Controls
{
    public class EducationTypeDropDown : CustomDropDown
    {
        public EducationTypeDropDown()
        {
            DataBind();
        }

        public override void DataBind()
        {
            ListItem l1 = new ListItem();
            l1.Text = "Selecteer een type";
            l1.Value = "0";

            ListItem l2 = new ListItem();
            l2.Text = "Opleiding";
            l2.Value = "1";

            ListItem l3 = new ListItem();
            l3.Text = "Training";
            l3.Value = "2";

            ListItem l4 = new ListItem();
            l4.Text = "Cursus";
            l4.Value = "3";

            this.Items.Clear();
            this.Items.Add(l1);
            this.Items.Add(l2);
            this.Items.Add(l3);
            this.Items.Add(l4);

        }
    }
}
