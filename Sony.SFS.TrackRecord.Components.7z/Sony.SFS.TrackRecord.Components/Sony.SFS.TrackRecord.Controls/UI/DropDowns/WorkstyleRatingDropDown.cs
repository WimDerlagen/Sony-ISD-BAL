using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Sony.SFS.TrackRecord.Components;
using Sony.SFS.TrackRecord.Collections;

namespace Sony.SFS.TrackRecord.Controls
{
    public class WorkstyleRatingDropDown : CustomDropDown
    {
        public WorkstyleRatingDropDown()
        {
            DataBind();
        }

        public override void DataBind()
        {
            Items.Clear();

            ListItem li1 = new ListItem("E--", "1");
            ListItem li2 = new ListItem("E-", "2");
            ListItem li3 = new ListItem("E", "3");
            ListItem li4 = new ListItem("E+", "4");
            ListItem li5 = new ListItem("E++", "5");

            this.Items.Add(li1);
            this.Items.Add(li2);
            this.Items.Add(li3);
            this.Items.Add(li4);
            this.Items.Add(li5);

            base.DataBind();
        }
    }
}
