using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Sony.SFS.TrackRecord.Components;
using Sony.SFS.TrackRecord.Collections;


namespace Sony.SFS.TrackRecord.Controls
{
    public class FunctionDropDown : CustomDropDown
    {
        public FunctionDropDown()
        {
            DataBind();
        }

        public override void DataBind()
        {
            this.DataTextField = "Title";
            this.DataValueField = "FunctionID";
            FunctionSet set = StemDataService.GetFunctions();
            Function not = new Function();
            not.FunctionID = 0;
            not.Title = "Selecteer een functie";

            set.Items.Insert(0, not);

            this.DataSource = set.Items;

            base.DataBind();
        }
    }
}
