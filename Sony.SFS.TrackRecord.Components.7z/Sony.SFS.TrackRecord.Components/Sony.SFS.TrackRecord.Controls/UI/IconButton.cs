using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;



namespace Sony.SFS.TrackRecord.Controls
{
    public class IconButton : Button
    {
        private string text = string.Empty;
        private string altText = string.Empty;
        private string imageUrl = string.Empty;
        private IconButtonType buttonType = IconButtonType.New;
        ThemedImage image = new ThemedImage();
        HtmlGenericControl span = new HtmlGenericControl("span");
        private string width = string.Empty;
        private string _float = string.Empty;
        

        public new string Text
        {
            get { return text; }
            set { text = value; }
        }
        public string AltText
        {
            get { return altText; }
            set { altText = value; }
        }
        public string ImageUrl
        {
            get { return imageUrl; }
            set { imageUrl = value; }
        }
        public IconButtonType ButtonType
        {
            get { return buttonType; }
            set { buttonType = value; }
        }

        public new string Width
        {
            get { return width; }
            set { width = value; }
        }

        public string Float
        {
            get{return _float;}
            set{_float = value;}
        }
        public IconButton() { }

        public IconButton(IconButtonType type)
        {
            this.buttonType = type;
            LoadButton();
        }

        private void LoadButton()
        {
            
        }

        protected override void CreateChildControls()
        {
            image.ID = this.ID + "image";

            switch (buttonType)
            {
                case IconButtonType.Back:
                    image.AlternateText = Images.altBack;
                    image.ImageUrl = Images.imgBack;
                    span.InnerText = Images.txtBack;
                    break;

                case IconButtonType.Cancel:
                    image.AlternateText = Images.altCancel;
                    image.ImageUrl = Images.imgCancel;
                    span.InnerText = Images.txtCancel;
                    break;

                case IconButtonType.Delete:
                    image.AlternateText = Images.altDelete;
                    image.ImageUrl = Images.imgDelete;
                    span.InnerText = Images.txtDelete;
                    break;

                case IconButtonType.Edit:
                    image.AlternateText = Images.altEdit;
                    image.ImageUrl = Images.imgEdit;
                    span.InnerText = Images.txtEdit;
                    break;

                case IconButtonType.New:
                    image.AlternateText = Images.altNew;
                    image.ImageUrl = Images.imgNew;
                    span.InnerText = Images.txtNew;
                    break;

                case IconButtonType.Refresh:
                    image.AlternateText = Images.altRefresh;
                    image.ImageUrl = Images.imgRefresh;
                    span.InnerText = Images.txtRefresh;
                    break;

                case IconButtonType.Save:
                    image.AlternateText = Images.altSave;
                    image.ImageUrl = Images.imgSave;
                    span.InnerText = Images.txtSave;
                    break;

                case IconButtonType.Import:
                    image.AlternateText = Images.altImport;
                    image.ImageUrl = Images.imgImport;
                    span.InnerText = Images.txtImport;
                    break;

                case IconButtonType.Overview:
                    image.AlternateText = Images.altOverview;
                    image.ImageUrl = Images.imgOverview;
                    span.InnerText = Images.txtOverview;
                    break;
                
            }
        }

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            //writer.Write("<div class=\"iconButton\" OnClick=\"javascript:" + Page.GetPostBackEventReference(this, "Click") + "\"> >");
            
            //the ClientID is needed by AJAX to perform a partial update. Without it, server event are fired but, from within an UpdatePanel, a full postback is issued
            //
            string output = "<div id=\"" + this.ClientID + "\" class=\"iconButton\" {0} OnClick=\"javascript:" + Page.ClientScript.GetPostBackEventReference(this, "Click") + "\" >";
            bool isFloat = (Float != string.Empty);

            if (Width == string.Empty && !isFloat)
                writer.Write(string.Format(output, string.Empty));
            else if (Width == string.Empty && isFloat)
                writer.Write(string.Format(output, "style=\"float:" + _float + ";\""));
            else if (Width != string.Empty && !isFloat)
                writer.Write(string.Format(output, "style=\"width:" + width + ";\""));
            else if (Width != string.Empty && isFloat)
                writer.Write(string.Format(output, "style=\"float:" + _float + ";width:" + width + ";\""));
        }

        protected override void Render(HtmlTextWriter writer)
        {
            if (buttonType != IconButtonType.Empty)
            {
                RenderBeginTag(writer);

                image.RenderControl(writer);
                span.RenderControl(writer);

                RenderEndTag(writer);
            }
            else
                writer.Write("&nbsp;&nbsp;&nbsp;&nbsp;");
        }

        public override void RenderEndTag(HtmlTextWriter writer)
        {
            writer.Write("</div>");
        }

        protected override void RaisePostBackEvent(string eventArgument)
        {
            if (eventArgument == "Click")
            {
                this.OnClick(new EventArgs());
                this.RaiseBubbleEvent(this, new ButtonClickEventArgs(buttonType));
            }
            else
            {

            }

        }

        


    }
}
