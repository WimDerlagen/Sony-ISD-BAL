using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public delegate void StatusChangedHandler(object sender, CrudOverviewStatusChangedEventArgs e);


    public abstract class BaseCrudOverviewControl : TemplatedWebControl
    {
        public event StatusChangedHandler StatusChanged;

        protected MultiView ManageMV;
        protected View OverviewView;
        protected View CrudView;
        protected TypedNullableRepeater Overview;
        protected Literal OverviewHeader;
        protected Literal CrudHeader;

        public bool IsNew
        {
            get
            {
                object isn = ViewState["IsNew"];

                if (isn == null)
                {
                    isn = true;
                    ViewState["IsNew"] = isn;
                }

                return (bool)isn;
            }
            set
            {
                ViewState["IsNew"] = value;
            }
        }

        public int ObjecID
        {
            get
            {
                object oid = ViewState["ObjectID"];

                if (oid == null)
                {
                    oid = 0;
                    ViewState["ObjectID"] = oid;
                }

                return (int)oid;
            }
            set
            {
                ViewState["ObjectID"] = value;
            }
        }


        protected override void AttachChildControls()
        {
            ManageMV = (MultiView)FindControl("ManageMV");
            OverviewView = (View)ManageMV.FindControl("OverviewView");
            CrudView = (View)ManageMV.FindControl("CrudView");
            Overview = (TypedNullableRepeater)OverviewView.FindControl("Overview");
            OverviewHeader = (Literal)OverviewView.FindControl("OverviewHeader");
            CrudHeader = (Literal)CrudView.FindControl("CrudHeader");

            
        }

        protected virtual void InitializeChildControls()
        {
            DataBind();
        }

        protected abstract IList GetData();
        protected abstract void LoadCrud();
        protected abstract void LoadObject(int id);


        public override void DataBind()
        {
            Overview.DataSource = GetData();
            Overview.DataBind();
            base.DataBind();
        }


        public void SetStatus(CrudOverviewStatus status)
        {
            switch (status)
            {
                case CrudOverviewStatus.Crud:
                    ManageMV.SetActiveView(CrudView);
                    OnStatusChanged(status);
                    break;

                case CrudOverviewStatus.Overview:
                    ManageMV.SetActiveView(OverviewView);
                    OnStatusChanged(status);
                    break;
            }
            
        }

        public void OnStatusChanged(CrudOverviewStatus status)
        {
            if (StatusChanged != null)
                StatusChanged(this, new CrudOverviewStatusChangedEventArgs(status));
        }


        protected void LoadList()
        {
            DataBind();
        }

        protected void Reset()
        {
            ManageMV.SetActiveView(OverviewView);
            LoadList();
        }

        protected void ResetCrud()
        {
            ManageMV.SetActiveView(CrudView);
            LoadCrud();
        }

        public void New()
        {
            SetStatus(CrudOverviewStatus.Crud);
            IsNew = true;
            LoadCrud();
        }

        public void Edit(int id)
        {
            SetStatus(CrudOverviewStatus.Crud);
            IsNew = false;

            LoadObject(id);

            LoadCrud();
        }

        public void SetOverview()
        {
            SetStatus(CrudOverviewStatus.Overview);
        }

    }
}
