using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Sony.SFS.TrackRecord.Controls
{
    public class CustomDropDown : DropDownList
    {
        public int SelectedID
        {
            get
            {
                int sid = Convert.ToInt32(this.SelectedValue);

                return sid;
            }
        }

        public void Select(int objectId)
        {
            ListItem item = Items.FindByValue(objectId.ToString());

            if (item != null)
            {
                int index = Items.IndexOf(item);
                this.SelectedIndex = index;
            }
        }

        public void Select(string objectId)
        {
            ListItem item = Items.FindByValue(objectId);

            if (item != null)
            {
                int index = Items.IndexOf(item);
                this.SelectedIndex = index;
            }
        }
    }
}
