using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Configuration.Provider;


namespace Sony.SFS.TrackRecord.Controls
{
    /// <summary>
    /// 
    /// 
    /// </summary>
    public class MenuControl : Menu
    {
        private string startingNodeUrl = "~/";
        private bool _static = false;
        private string siteMap = "Web.Sitemap";

        public string StartingNodeUrl
        {
            get { return this.startingNodeUrl; }
            set { this.startingNodeUrl = value; }
        }

        public bool Static
        {
            get { return _static; }
            set { _static = value; }
        }

        public string SiteMap
        {
            get { return siteMap; }
            set { siteMap = value; }
        }

        protected override void CreateChildControls()
        {
            
            if (!Page.IsPostBack)
            {
                SiteMapDataSource src = GetSiteMapDataSource();
                
                src.StartingNodeUrl = startingNodeUrl;
                src.ShowStartingNode = false;

                this.DataSource = src;
                this.DataBind();
            }
        }

        private SiteMapDataSource GetSiteMapDataSource()
        {
            XmlSiteMapProvider xmlSiteMap = new XmlSiteMapProvider();
            System.Collections.Specialized.NameValueCollection
                   myCollection = new
                   System.Collections.Specialized.NameValueCollection(1);

            myCollection.Add("siteMapFile", siteMap);
            xmlSiteMap.Initialize("provider", myCollection);
            SiteMapNode node = xmlSiteMap.BuildSiteMap();

            SiteMapDataSource siteMapSource = new SiteMapDataSource();
            
            return siteMapSource;
        }
    }
}
