using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class Style : LiteralControl
    {

        /// <summary>
        /// Property Media (string)
        /// </summary>
        [
        System.ComponentModel.DefaultValue("screen"),
        ]
        public virtual String Media
        {
            get
            {
                Object state = ViewState["Media"];
                if (state != null)
                {
                    return (String)state;
                }
                return "screen";
            }
            set
            {
                ViewState["Media"] = value;
            }
        }

        string appliation = string.Empty;
        public string Application
        {
            get
            {
                return appliation;
            }
            set
            {
                appliation = value;
            }
        }

        /// <summary>
        /// Property Href (string)
        /// </summary>
        [
        System.ComponentModel.DefaultValue("/style/default.aspx"),
        ]
        public virtual String Href
        {
            get
            {
                Object state = ViewState["Href"];
                //  if (state != null)
                // {
                //      return ResolveUrl((String)state);
                //  }

                // switch for font size
                TRContext trContext = TRContext.Current;

                //if (!csContext.User.IsAnonymous)
                //    return ResolveUrl(Globals.GetSkinPath() + "/style/default.aspx?application=" + Application + "&fontsize=" + csContext.User.Profile.FontSize);
                //else
                return ResolveUrl(Globals.GetSkinPath() + (String)state);
            }
            set
            {
                ViewState["Href"] = value;
            }
        }

        const string linkFormat = "<link rel=\"stylesheet\" href=\"{0}\" type=\"text/css\" media=\"{1}\" />";

        protected override void Render(HtmlTextWriter writer)
        {
            writer.Write(linkFormat, Href, Media);
        }


    }
}
