using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class NotifyControl : WebControl
    {
        private List<Notification> notifications = new List<Notification>();

        public List<Notification> Notifications
        {
            get { return notifications; }
            set { notifications = value; }
        }

        public override void RenderBeginTag(HtmlTextWriter writer) { }

        public override void RenderEndTag(HtmlTextWriter writer) { }

        protected override void Render(HtmlTextWriter writer)
        {
            writer.Write("");
            writer.Write("<div id=\"notify\">");


            foreach (Notification n in notifications)
            {
                writer.Write(n.Text);
                writer.Write("<br/>");
            }


            writer.Write("</div>");

        }


    }
}
