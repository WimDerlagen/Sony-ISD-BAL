using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;


using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class AmbitionHeaderTemplate : ITemplate
    {
        public void InstantiateIn(Control container)
        {
            LiteralControl table = new LiteralControl("<table cellpadding=\"0\" class=\"overviewTabel\" cellspacing=\"0\" border=\"0\">");

            string row = "<tr>{0}{1}{2}</tr>";
            string field = "<td>{0}</td>";
            string hr = "<tr><td colspan=\"5\"><hr /></td></tr>";

            string field1 = string.Format(field, "ID");
            string field2 = string.Format(field, "Ambitie");
            string field3 = string.Format(field, "Omschrijving");


            LiteralControl row1 = new LiteralControl(string.Format(row, field1, field2, field3));
            LiteralControl hr1 = new LiteralControl(hr);

            container.Controls.Add(table);
            container.Controls.Add(row1);
            container.Controls.Add(hr1);
        }
    }

    public class AmbitionItemTemplate : ITemplate
    {
        private bool alt;

        public bool Alternate
        {
            get { return alt; }
            set { alt = value; }
        }

        public void InstantiateIn(Control container)
        {
            HtmlTableRow row = new HtmlTableRow();

            HtmlTableCell td1 = new HtmlTableCell();
            HtmlTableCell td2 = new HtmlTableCell();
            HtmlTableCell td3 = new HtmlTableCell();


            //RepeaterItem item = (RepeaterItem)container;
            //AmbitionType amb = (AmbitionType)item.DataItem;

            if (!alt)
            {
                td1.Attributes.Add("class", "sfc");
                td2.Attributes.Add("class", "sft");
                td3.Attributes.Add("class", "sfr");

            }
            else
            {
                td1.Attributes.Add("class", "sfc alt");
                td2.Attributes.Add("class", "sft alt");
                td3.Attributes.Add("class", "sfr alt");

            }

            LinkButton id = new LinkButton();
            LinkButton name = new LinkButton();
            LinkButton desc = new LinkButton();


            id.CommandName = "select";
            name.CommandName = "select";
            desc.CommandName = "select";


            id.DataBinding += new EventHandler(id_DataBinding);
            name.DataBinding += new EventHandler(name_DataBinding);
            desc.DataBinding += new EventHandler(desc_DataBinding);


            td1.Controls.Add(id);
            td2.Controls.Add(name);
            td3.Controls.Add(desc);


            row.Controls.Add(td1);
            row.Controls.Add(td2);
            row.Controls.Add(td3);


            container.Controls.Add(row);
        }

        void desc_DataBinding(object sender, EventArgs e)
        {
            LinkButton link = (LinkButton)sender;

            RepeaterItem container = (RepeaterItem)link.NamingContainer;
            AmbitionType amb = (AmbitionType)container.DataItem;

            link.Text = Globals.LimitString(amb.Description, 80);
            link.CommandArgument = amb.AmbitionTypeID.ToString();
        }

        void  name_DataBinding(object sender, EventArgs e)
        {
            LinkButton link = (LinkButton)sender;

            RepeaterItem container = (RepeaterItem)link.NamingContainer;
            AmbitionType amb = (AmbitionType)container.DataItem;

            link.Text = amb.AmbitionTypeText;
            link.CommandArgument = amb.AmbitionTypeID.ToString();
        }

        void  id_DataBinding(object sender, EventArgs e)
        {
            LinkButton link = (LinkButton)sender;

            RepeaterItem container = (RepeaterItem)link.NamingContainer;
            AmbitionType amb = (AmbitionType)container.DataItem;

            link.Text = amb.AmbitionTypeID.ToString();
            link.CommandArgument = amb.AmbitionTypeID.ToString();
        }

        public AmbitionItemTemplate()
        {
            alt = false;
        }

        public AmbitionItemTemplate(bool alt)
        {
            this.alt = alt;
        }
    }

    public class AmbitionFooterTemplate : ITemplate
    {
        public void InstantiateIn(Control container)
        {
            LiteralControl table = new LiteralControl("</table>");

            container.Controls.Add(table);
        }
    }

    public class AmbitionNoneTemplate : ITemplate
    {
        public AmbitionNoneTemplate() { }

        public void InstantiateIn(Control container)
        {
            HtmlTableRow row = new HtmlTableRow();

            HtmlTableCell td1 = new HtmlTableCell();

            td1.Attributes.Add("colspan", "3");

            td1.Controls.Add(new LiteralControl("geen items"));

            row.Controls.Add(td1);

            container.Controls.Add(row);
        }
    }
}
