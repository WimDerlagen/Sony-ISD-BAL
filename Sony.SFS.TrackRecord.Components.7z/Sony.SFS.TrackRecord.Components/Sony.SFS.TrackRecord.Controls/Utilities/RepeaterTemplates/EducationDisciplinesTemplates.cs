using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class EducationDisciplinesHeaderTemplate : ITemplate
    {
        public void InstantiateIn(Control container)
        {
            LiteralControl table = new LiteralControl("<table cellpadding=\"0\" class=\"overviewTabel\" cellspacing=\"0\" border=\"0\">");

            string row = "<tr>{0}{1}{2}</tr>";
            string field = "<td>{0}</td>";
            string hr = "<tr><td colspan=\"5\"><hr /></td></tr>";

            string field1 = string.Format(field, "Discipline ID");
            string field2 = string.Format(field, "Discipline");
            string field3 = string.Format(field, "Omschrijving");


            LiteralControl row1 = new LiteralControl(string.Format(row, field1, field2, field3));
            LiteralControl hr1 = new LiteralControl(hr);

            container.Controls.Add(table);
            container.Controls.Add(row1);
            container.Controls.Add(hr1);


        }
    }

    public class EducationDisciplinesItemTemplate : ITemplate
    {
        private bool alt;

        public bool Alternate
        {
            get { return alt; }
            set { alt = value; }
        }

        public EducationDisciplinesItemTemplate()
        {
            this.alt = false;
        }

        public EducationDisciplinesItemTemplate(bool alt)
        {
            this.alt = alt;
        }

        public void InstantiateIn(Control container)
        {
            HtmlTableRow row = new HtmlTableRow();

            HtmlTableCell td1 = new HtmlTableCell();
            HtmlTableCell td2 = new HtmlTableCell();
            HtmlTableCell td3 = new HtmlTableCell();


            if (!alt)
            {
                td1.Attributes.Add("class", "id");
                td2.Attributes.Add("class", "name");
                td3.Attributes.Add("class", "description");

            }
            else
            {
                td1.Attributes.Add("class", "id alt");
                td2.Attributes.Add("class", "name alt");
                td3.Attributes.Add("class", "description alt");

            }

            LinkButton id = new LinkButton();
            LinkButton name = new LinkButton();
            LinkButton description = new LinkButton();

            id.CommandName = "select";
            name.CommandName = "select";
            description.CommandName = "select";


            id.DataBinding += new EventHandler(id_DataBinding);
            name.DataBinding += new EventHandler(name_DataBinding);
            description.DataBinding += new EventHandler(description_DataBinding);

            td1.Controls.Add(id);
            td2.Controls.Add(name);
            td3.Controls.Add(description);

            row.Controls.Add(td1);
            row.Controls.Add(td2);
            row.Controls.Add(td3);

            container.Controls.Add(row);
        }

        void description_DataBinding(object sender, EventArgs e)
        {
            LinkButton link = (LinkButton)sender;

            RepeaterItem container = (RepeaterItem)link.NamingContainer;
            EducationDiscipline dis = (EducationDiscipline)container.DataItem;

            link.Text = Globals.LimitString(dis.Description, 50);
            link.CommandArgument = dis.EducationDisciplineID.ToString();
        }

        void name_DataBinding(object sender, EventArgs e)
        {
            LinkButton link = (LinkButton)sender;

            RepeaterItem container = (RepeaterItem)link.NamingContainer;
            EducationDiscipline dis = (EducationDiscipline)container.DataItem;

            link.Text = dis.Discipline;
            link.CommandArgument = dis.EducationDisciplineID.ToString();
        }

        void id_DataBinding(object sender, EventArgs e)
        {
            LinkButton link = (LinkButton)sender;

            RepeaterItem container = (RepeaterItem)link.NamingContainer;
            EducationDiscipline dis = (EducationDiscipline)container.DataItem;

            link.Text = dis.EducationDisciplineID.ToString();
            link.CommandArgument = dis.EducationDisciplineID.ToString();

        }
    }

    public class EducationDisciplinesFooterTemplate : ITemplate
    {
        public void InstantiateIn(Control container)
        {
            LiteralControl table = new LiteralControl("</table>");

            container.Controls.Add(table);
        }
    }

    public class EducationDisciplinesNoneTemplate : ITemplate
    {
        public EducationDisciplinesNoneTemplate() { }

        public void InstantiateIn(Control container)
        {
            HtmlTableRow row = new HtmlTableRow();

            HtmlTableCell td1 = new HtmlTableCell();

            td1.Attributes.Add("colspan", "2");

            td1.Controls.Add(new LiteralControl("geen items"));

            row.Controls.Add(td1);

            container.Controls.Add(row);
        }
    }
}
