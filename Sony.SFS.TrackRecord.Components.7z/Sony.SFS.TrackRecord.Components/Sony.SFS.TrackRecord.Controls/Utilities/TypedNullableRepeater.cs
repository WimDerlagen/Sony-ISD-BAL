using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Controls
{
    public class TypedNullableRepeater : RepeaterPlusNone
    {
        public TypedNullableRepeater(){}
            
        public override void DataBind()
        {
            if (DataSource is List<Language>)
            {
                this.HeaderTemplate = new LanguageHeaderTemplate();
                this.ItemTemplate = new LanguageItemTemplate();
                this.AlternatingItemTemplate = new LanguageItemTemplate(true);
                this.FooterTemplate = new LanguageFooterTemplate();
                this.NoneTemplate = new LanguageNoneTemplate();
            }

            if (DataSource is List<EducationDiscipline>)
            {
                this.HeaderTemplate = new EducationDisciplinesHeaderTemplate();
                this.ItemTemplate = new EducationDisciplinesItemTemplate();
                this.AlternatingItemTemplate = new EducationDisciplinesItemTemplate(true);
                this.FooterTemplate = new EducationDisciplinesFooterTemplate();
                this.NoneTemplate = new EducationDisciplinesNoneTemplate();
            }

            if (DataSource is List<EducationLevel>)
            {
                this.HeaderTemplate = new EducationLevelsHeaderTemplate();
                this.ItemTemplate = new EducationLevelsItemTemplate();
                this.AlternatingItemTemplate = new EducationLevelsItemTemplate(true);
                this.FooterTemplate = new EducationLevelsFooterTemplate();
                this.NoneTemplate = new EducationLevelsNoneTemplate();
            }

            if (DataSource is List<Department>)
            {
                this.HeaderTemplate = new DepartmentHeaderTemplate();
                this.ItemTemplate = new DepartmentItemTemplate();
                this.AlternatingItemTemplate = new DepartmentItemTemplate(true);
                this.FooterTemplate = new DepartmentFooterTemplate();
                this.NoneTemplate = new DepartmentNoneTemplate();
            }

            if (DataSource is List<Function>)
            {
                this.HeaderTemplate = new FunctionHeaderTemplate();
                this.ItemTemplate = new FunctionItemTemplate();
                this.AlternatingItemTemplate = new FunctionItemTemplate(true);
                this.FooterTemplate = new FunctionFooterTemplate();
                this.NoneTemplate = new FunctionNoneTemplate();
            }

            if (DataSource is List<AmbitionType>)
            {
                this.HeaderTemplate = new AmbitionHeaderTemplate();
                this.ItemTemplate = new AmbitionItemTemplate();
                this.AlternatingItemTemplate = new AmbitionItemTemplate(true);
                this.FooterTemplate = new AmbitionFooterTemplate();
                this.NoneTemplate = new AmbitionNoneTemplate();
            }

            base.DataBind();
        }
    }
}
