using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Controls
{
    public enum IconButtonType
    {
        New,
        Cancel,
        Delete,
        Save,
        Back,
        Edit,
        Refresh,
        Import,
        Overview,
        Empty
    }
}
