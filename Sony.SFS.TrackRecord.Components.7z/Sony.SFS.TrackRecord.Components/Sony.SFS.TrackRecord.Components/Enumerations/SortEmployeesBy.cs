using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// Indicates which column to use to sort an employees result set.
    /// </summary>
    public enum SortEmployeesBy
    {
        RoepNaam = 0,
        EmployeeNumber = 1,
        Naam,
        Postcode,
        Woonplaats,
        GeboorteDatum,
        DatumInDienst,
        DatumInDienstSony,
        Beroep,
        AfdelingsNummer,
        BusinessGroup,
        FTE,
        Nationaliteit

    }
}
