using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    [Obsolete]
    public enum SkillLevel
    {
        Beginner = 0,
        Mediocre,
        Advanced
    }
}
