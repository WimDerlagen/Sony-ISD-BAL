using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// Indicates the type of file to import.
    /// </summary>
    public enum ImportType
    {
        CSV,
        Excel
    }
}
