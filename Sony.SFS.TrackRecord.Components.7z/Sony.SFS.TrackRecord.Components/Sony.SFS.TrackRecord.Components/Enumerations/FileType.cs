using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public enum FileType
    {
        EmployeesTable,
        DepartmentTable,
    }
}
