using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// Indicates the type of education used.
    /// </summary>
    public enum EducationType
    {
        NotSet = 0,
        Education = 1,
        Training,
        Course,
        Assessment
    }
}
