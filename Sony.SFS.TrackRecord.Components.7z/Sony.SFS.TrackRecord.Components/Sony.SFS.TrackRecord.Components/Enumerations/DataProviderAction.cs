using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// Indicates which action the dataprovider should take
    /// </summary>
    public enum DataProviderAction
    {
        Create = 1,
        Update,
        Delete
    }
}
