using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// Indicates the type of rating
    /// </summary>
    public enum RatingType
    {
        WorkStyleRating = 1,
        WorkforcePosition,
        WorkforcePlayer,
        EGrading,
        PRatingHr,
        PRatingMgr,
        All = 99
    }
}
