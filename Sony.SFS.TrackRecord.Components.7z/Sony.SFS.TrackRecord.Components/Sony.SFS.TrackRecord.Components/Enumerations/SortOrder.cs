using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// Indicates whether to sort ascending or descending.
    /// </summary>
    public enum SortOrder
    {
        Ascending,
        Descending
    }
}
