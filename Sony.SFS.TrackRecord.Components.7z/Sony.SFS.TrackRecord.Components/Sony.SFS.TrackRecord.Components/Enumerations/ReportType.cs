using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// Indicates the type of report to display.
    /// </summary>
    public enum ReportType
    {
        None = -1,
        WorkforcePositions = 1,
        WorkforcePlayers,
        WorkforceCrossTable,
        EGradings,
        EGradingsCrossTable,
        SexeDivision,
        WorkforceProgression
        
    }
}
