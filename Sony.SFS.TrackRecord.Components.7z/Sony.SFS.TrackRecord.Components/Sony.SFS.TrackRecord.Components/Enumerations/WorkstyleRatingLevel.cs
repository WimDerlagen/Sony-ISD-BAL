using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// Indicates the level of rating
    /// </summary>
    public enum WorkstyleRatingLevel
    {
        Eminmin = 1,
        Emin,
        E,
        Eplus,
        Eplusplus
    }
}
