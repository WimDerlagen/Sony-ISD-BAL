using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// Indicates the different type of ambition is used. 
    /// </summary>
    public enum AmbitionChoiceType
    {
        /// <summary>
        /// Indicates a multiple choise ambition
        /// </summary>
        Choice = 1,
        /// <summary>
        /// Indicates an ambition for a function
        /// </summary>
        Function,
        /// <summary>
        /// Indicates an arbitrairaly entered ambition
        /// </summary>
        Text,
        /// <summary>
        /// Indicates all types of ambition. (for retreival from datastore only)
        /// </summary>
        All
    }
}
