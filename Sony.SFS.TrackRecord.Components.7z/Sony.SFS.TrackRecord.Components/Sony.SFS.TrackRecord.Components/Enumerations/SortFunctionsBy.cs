using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// Indicates which column to sort by
    /// </summary>
    public enum SortFunctionsBy
    {
        Title,
        DesiredDuration
    }
}
