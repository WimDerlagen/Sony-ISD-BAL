using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public enum EmployeeType
    {
        MT = 1,
        Manager,
        NonManager,
        Intern,
        Graduate
    }
}
