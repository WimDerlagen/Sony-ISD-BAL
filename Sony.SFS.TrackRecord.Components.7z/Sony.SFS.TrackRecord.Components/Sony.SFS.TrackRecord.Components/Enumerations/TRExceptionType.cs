using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// Indicates what exception was thrown
    /// </summary>
    public enum TRExceptionType
    {
        SkinNotFound = 1
    }
}
