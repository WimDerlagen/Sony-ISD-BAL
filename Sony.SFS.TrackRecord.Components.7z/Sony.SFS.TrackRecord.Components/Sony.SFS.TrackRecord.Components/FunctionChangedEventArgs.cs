using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class FunctionChangedEventArgs : EventArgs
    {
        private string userName;

        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }

        public FunctionChangedEventArgs() { }

        public FunctionChangedEventArgs(string userName)
        {
            this.userName = userName;
        }
    }
}
