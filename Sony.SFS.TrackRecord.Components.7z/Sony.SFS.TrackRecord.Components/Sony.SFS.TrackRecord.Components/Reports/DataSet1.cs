﻿namespace Sony.SFS.TrackRecord.Components.Reports {


    partial class DataSet1
    {
        partial class vw_RatingOverviewDataTable
        {
        }
    }
}
