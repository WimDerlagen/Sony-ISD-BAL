using System;
using System.Collections.Generic;
using System.Text;
using Sony.SFS.TrackRecord.Components;
using Sony.SFS.TrackRecord.Components.BaseClasses;

namespace Sony.SFS.TrackRecord.Collections
{
    /// <summary>
    /// A typed collection to store a set of employees.
    /// </summary>
    public class EmployeeSet : BaseSetCollection
    {
        List<PrimusEmployee> items = new List<PrimusEmployee>();

        /// <summary>
        /// A List&lt;Employee&gt; holding the records. 
        /// </summary>
        public new List<PrimusEmployee> Items
        {
            get
            {
                return items;
            }
        }
    }
}
