using System;
using System.Collections.Generic;
using System.Text;
using Sony.SFS.TrackRecord.Components;
using Sony.SFS.TrackRecord.Components.BaseClasses;

namespace Sony.SFS.TrackRecord.Collections
{
    /// <summary>
    /// A typed collection to store a set of functions
    /// </summary>
    public class FunctionSet : BaseSetCollection
    {
        List<Function> items = new List<Function>();

        /// <summary>
        /// A List&lt;Function&gt; which holds the records.
        /// </summary>
        public new List<Function> Items
        {
            get
            {
                return items;
            }
        }
    }
}
