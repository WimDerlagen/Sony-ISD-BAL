using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Configuration;
using System.Configuration.Provider;
using Sony.SFS.TrackRecord.Configuration;

namespace Sony.SFS.TrackRecord.Components
{
    public class ExcelServiceBase
    {
        private static CommonExcelDataProvider _provider = null;
        private static CommonExcelDataProviderCollection _providers = null;
        private static object _lock = new object();

        public static CommonExcelDataProvider Provider
        {
            get { return _provider; }
        }

        public CommonExcelDataProviderCollection Providers
        {
            get { return _providers; }
        }

        internal static void LoadProviders()
        {
            // Avoid claiming lock if providers are already loaded
            if (_provider == null)
            {
                lock (_lock)
                {
                    // Do this again to make sure _provider is still null
                    if (_provider == null)
                    {
                        // Get a reference to the <imageService> section
                        DataServiceSection section = (DataServiceSection)WebConfigurationManager.GetSection("system.web/excelService");

                        // Load registered providers and point _provider
                        // to the default provider
                        _providers = new CommonExcelDataProviderCollection();
                        ProvidersHelper.InstantiateProviders(section.Providers, _providers, typeof(CommonExcelDataProvider));
                        _provider = _providers[section.DefaultProvider];

                        if (_provider == null)
                            throw new ProviderException("Unable to load default CommonDataProvider");
                    }
                }
            }
        }
    }
}
