using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components.BaseClasses
{
    /// <summary>
    /// Base collection class used to store a set of business objects.
    /// This type of collection is used to retreive a certain page of data.\
    /// The TotalRecords property can be used by a pager control.
    /// </summary>
    public abstract class BaseSetCollection
    {
        ArrayList items = new ArrayList();
        int totalRecords = 0;

        /// <summary>
        /// The total amount of records in this set.
        /// </summary>
        public int TotalRecords
        {
            get
            {
                return totalRecords;
            }
            set
            {
                totalRecords = value;
            }
        }

        /// <summary>
        /// An ArrayList of business objects
        /// </summary>
        public virtual ArrayList Items
        {
            get
            {
                return items;
            }
        }

        /// <summary>
        /// A boolean indicating whether there are any results in the set.
        /// </summary>
        public virtual bool HasResults
        {
            get
            {
                if (items.Count > 0)
                    return true;
                return false;
            }
        }
    }
}
