using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class ColumnNotFoundException : Exception
    {
    }

    public class UnknownColumnException : Exception { }

    public class UnknownRatingValueException : Exception { }

    public class EmptyRatingValueException : Exception { }

    public class EmployeeHasNoFunctionException : Exception { }
}
