using System;
using System.Collections;
using System.Collections.Specialized;
using System.IO;
using System.Web;
using System.Web.Caching;
using System.Xml;
using System.Xml.Serialization;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// A configuration class holding site specific settings. This is a deprecated technique. Settings should be
    /// transferred to the web.config
    /// </summary>
    [Obsolete]
    public class TRConfiguration
    {
        public static readonly string CacheKey = "TRConfiguration";

        private string applicationOverride = null;
        private string filesPath;
        private XmlDocument XmlDoc = null;
        private int cacheFactor = 5;
        private string defaultLanguage;

        public string ApplicationOverride { get { return applicationOverride; } }
        public int CacheFactor { get { return cacheFactor; } }

        public string FilesPath
        {
            get { return filesPath; }
        }

        public string DefaultLanguage
        {
            get { return defaultLanguage; }
            set { defaultLanguage = value; }
        }

        public static TRConfiguration GetConfig()
        {
            TRConfiguration config = TRCache.Get(CacheKey) as TRConfiguration;
            if (config == null)
            {
                string path = null;
                HttpContext context = HttpContext.Current;
                if (context != null)
                    path = context.Server.MapPath("~/Site.config");
                else
                    path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Site.config");

                XmlDocument doc = new XmlDocument();
                doc.Load(path);
                config = new TRConfiguration(doc);
                TRCache.Max(CacheKey, config, new CacheDependency(path));

                TRCache.ReSetFactor(config.CacheFactor);
            }
            return config;
        }

        public TRConfiguration(XmlDocument doc)
        {
            XmlDoc = doc;
            LoadValuesFromConfigurationXml();
        }


        // *********************************************************************
        //  LoadValuesFromConfigurationXml
        //
        /// <summary>
        /// Loads the forums configuration values.
        /// </summary>
        /// 
        // ***********************************************************************/
        internal void LoadValuesFromConfigurationXml()
        {

            XmlNode node = GetConfigSection("Site/Core");

            XmlAttributeCollection attributeCollection = node.Attributes;


            // Get the default language
            //

            //XmlAttribute att = attributeCollection["defaultLanguage"];
            //if (att != null)
            //    defaultLanguage = att.Value;
            //else
            //    defaultLanguage = "en-US";

        //att = attributeCollection["enableUsersOnline"];
        //if (att != null)
        //    enableUsersOnline = bool.Parse(att.Value);

        //    filesPath = "/";

            //att = attributeCollection["applicationKeyOverride"];
            //if (att != null)
            //    applicationKeyOverride = att.Value;

            

            //att = attributeCollection["cacheFactor"];
            //if (att != null)
            //    cacheFactor = Int32.Parse(att.Value);
            //else
            //    cacheFactor = 5;

            //att = attributeCollection["applicationOverride"];
            //if (att != null)
            //    applicationOverride = att.Value;
            //else
            //    applicationOverride = null;

            //att = attributeCollection["wwwStatus"];
            //if (att != null)
            //    _wwwStatus = (WWWStatus)Enum.Parse(typeof(WWWStatus), attributeCollection["wwwStatus"].Value);


            //att = attributeCollection["ssl"];
            //if (att != null)
            //    _ssl = (SSLSettings)Enum.Parse(typeof(SSLSettings), att.Value, true);

            //if (_ssl == SSLSettings.Ignore && att == null)
            //{
            //    att = attributeCollection["requireSSL"];
            //    if (att != null && att.Value == "true")
            //        _ssl = SSLSettings.Password;
            //}


            //XmlAttribute roles = attributeCollection["defaultRoles"];
            //if (roles != null)
            //{
            //    _defaultRoles = roles.Value.Split(';');
            //}

            // Read child nodes
            //
            foreach (XmlNode child in node.ChildNodes)
            {

                //if (child.Name == "providers")
                //    GetProviders(child, providers);

                //if (child.Name == "appLocation")
                //    GetAppLocation(child);

                //if (child.Name == "extensionModules")
                //    GetProviders(child, extensions);

                //if (child.Name == "roleConfiguration")
                //    GetRoleConfiguration(child);

            }

            ////if we do not have an application, create the default one
            //if (app == null)
            //{
            //    app = AppLocation.Default();
            //}

            //if (roleConfiguration == null)
            //{
            //    roleConfiguration = new RolesConfiguration();
            //}


        //     // *********************************************************************
        ////  GetRoleConfiguration
        ////
        ///// <summary>
        ///// Internal class used to populate default role changes.
        ///// </summary>
        ///// <param name="node">XmlNode of the configurations.</param>
        ///// 
        //// ***********************************************************************/
        //internal void GetRoleConfiguration(XmlNode node)
        //{
        //    try
        //    {
        //        XmlSerializer serializer = new XmlSerializer(typeof (RolesConfiguration));
        //        roleConfiguration = serializer.Deserialize(new XmlNodeReader(node)) as RolesConfiguration;
        //    }
        //    catch
        //    {
        //        //Should we let exception go?
        //        roleConfiguration = new RolesConfiguration();
        //    }
        //}

        //// *********************************************************************
        ////  GetProviders
        ////
        ///// <summary>
        ///// Internal class used to populate the available providers.
        ///// </summary>
        ///// <param name="node">XmlNode of the providers to add/remove/clear.</param>
        ///// 
        //// ***********************************************************************/
        //internal void GetProviders(XmlNode node, Hashtable table) {

        //    foreach (XmlNode provider in node.ChildNodes) {

        //        switch (provider.Name) {
        //            case "add" :
        //                table.Add(provider.Attributes["name"].Value, new Provider(provider.Attributes) );
        //                break;

        //            case "remove" :
        //                table.Remove(provider.Attributes["name"].Value);
        //                break;

        //            case "clear" :
        //                table.Clear();
        //                break;

        //        }

        //    }

        //}

        //internal void GetAppLocation(XmlNode node)
        //{
        //    app = AppLocation.Create(node);
        //}



        }


        #region GetXML

        /// <summary>
        /// Enables reading of the configuration file's XML without reloading the file
        /// </summary>
        /// <param name="nodePath"></param>
        /// <returns></returns>
        public XmlNode GetConfigSection(string nodePath)
        {
            return XmlDoc.SelectSingleNode(nodePath);
        }

        #endregion
    }
}
