using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class PrimusEmployee2
    {
        private int employeeId = 0;
        private int employeeNummer = 0;
        private string aanhef = string.Empty;
        private string employeeNaam = string.Empty;
        private string straat = string.Empty;
        private string huisNummer = string.Empty;
        private string huisNummerToevoeging = string.Empty;
        private string postcode = string.Empty;
        private string woonplaats = string.Empty;
        private string land = string.Empty;
        private DateTime geboorteDatum = new DateTime(1900,1,1);
        private DateTime datumInDienst = new DateTime(1900,1,1);
        private string beroep = string.Empty;
        private int afdelingsNummer = 0;
        private string afdeling = string.Empty;
        private string businessGroup = string.Empty;
        private string businessOwner = string.Empty;
        private decimal fte = 0;
        private string functieOmschrijving = string.Empty;
        private DateTime datumInDienstSony = new DateTime(1900,1,1);
        private int nationaliteit = 0;
        private string roepNaam = string.Empty;
        private int vestigingsNummer = 0;
        private string voorvoegsel = string.Empty;
        private Hashtable wsRatings = new Hashtable();
        private Hashtable wfPlayer = new Hashtable();
        private Hashtable wfPosition = new Hashtable();
        private Hashtable eGrading = new Hashtable();
        private EmployeeType type = EmployeeType.NonManager;

        public int EmployeeID
        {
            get { return employeeId; }
            set { employeeId = value; }
        }

        public int EmployeeNummer
        {
            get { return employeeNummer; }
            set { employeeNummer = value; }
        }
        public string Aanhef
        {
            get { return aanhef; }
            set { aanhef = value; }
        }
        public string EmployeeNaam
        {
            get { return employeeNaam; }
            set { employeeNaam = value; }
        }
        public string Straat
        {
            get { return straat; }
            set { straat = value; }
        }
        public string HuisNummer
        {
            get { return huisNummer; }
            set { huisNummer = value; }
        }
        public string HuisNummerToevoeging
        {
            get { return huisNummerToevoeging; }
            set { huisNummerToevoeging = value; }
        }
        public string Postcode
        {
            get { return postcode; }
            set { postcode = value; }
        }
        public string Woonplaats
        {
            get { return woonplaats; }
            set { woonplaats = value; }
        }
        public string Land
        {
            get { return land; }
            set { land = value; }
        }
        public DateTime GeboorteDatum
        {
            get { return geboorteDatum; }
            set { geboorteDatum = value; }
        }
        public DateTime DatumInDienst
        {
            get { return datumInDienst; }
            set { datumInDienst = value; }
        }
        public string Beroep
        {
            get { return beroep; }
            set { beroep = value; }
        }
        public int AfdelingsNummer
        {
            get { return afdelingsNummer; }
            set { afdelingsNummer = value; }
        }
        public string Afdeling
        {
            get { return afdeling; }
            set { afdeling = value; }
        }
        public string BusinessGroup
        {
            get { return businessGroup; }
            set { businessGroup = value; }
        }
        public string BusinessOwner
        {
            get { return businessOwner; }
            set { businessOwner = value; }
        }
        public decimal FTE
        {
            get { return fte; }
            set { fte = value; }
        }
        public string FunctieOmschrijving
        {
            get { return functieOmschrijving; }
            set { functieOmschrijving = value; }
        }
        public DateTime DatumInDienstSony
        {
            get { return datumInDienstSony; }
            set { datumInDienstSony = value; }
        }
        public int Nationaliteit
        {
            get { return nationaliteit; }
            set { nationaliteit = value; }
        }
        public string RoepNaam
        {
            get { return roepNaam; }
            set { roepNaam = value; }
        }
        public int VestigingsNummer
        {
            get { return vestigingsNummer; }
            set { vestigingsNummer = value; }
        }
        public string Voorvoegsel
        {
            get { return voorvoegsel; }
            set { voorvoegsel = value; }
        }
        public Hashtable WSRatings
        {
            get { return wsRatings; }
            set { wsRatings = value; }
        }
        public Hashtable WFPlayer
        {
            get { return wfPlayer; }
            set { wfPlayer = value; }
        }
        public Hashtable WFPosition
        {
            get { return wfPosition; }
            set { wfPosition = value; }
        }
        public Hashtable EGrading
        {
            get { return eGrading; }
            set { eGrading = value; }
        }

        public EmployeeType EmployeeType
        {
            get { return type; }
            set { type = value; }
        }

        

    }
}
