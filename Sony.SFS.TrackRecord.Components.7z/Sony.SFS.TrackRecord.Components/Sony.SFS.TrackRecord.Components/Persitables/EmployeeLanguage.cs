using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class EmployeeLanguage
    {
        private int employeeId;
        private int languageId;
        private SkillLevel writing;
        private SkillLevel speaking;

        public int EmployeeID
        {
            get { return employeeId; }
            set { employeeId = value; }
        }

        public int LanguageID
        {
            get { return languageId; }
            set { languageId = value; }
        }
        public SkillLevel Writing
        {
            get { return writing; }
            set { writing = value; }
        }
        public SkillLevel Speaking
        {
            get { return speaking; }
            set { speaking = value; }
        }
    }

}
