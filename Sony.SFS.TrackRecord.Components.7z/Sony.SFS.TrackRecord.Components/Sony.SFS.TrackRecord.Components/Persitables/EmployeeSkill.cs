using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class EmployeeSkill
    {
        private int employeeId = 0;
        private int skillId = 0;
        private SkillLevel skillLevel = SkillLevel.Mediocre;


        public int EmployeeID
        {
            get { return employeeId; }
            set { employeeId = value; }
        }
        public int SkillID
        {
            get { return skillId; }
            set { skillId = value; }
        }
        public SkillLevel SkillLevel
        {
            get { return skillLevel; }
            set { skillLevel = value; }
        }

    }
}
