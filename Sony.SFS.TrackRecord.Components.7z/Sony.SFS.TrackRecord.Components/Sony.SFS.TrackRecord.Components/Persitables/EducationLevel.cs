using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// a persistable to hold an education level record
    /// </summary>
    [Serializable]
    public class EducationLevel : IAutoDropDownItem
    {
        private int educationLevelId = 0;
        private string level = string.Empty;
        private string description = string.Empty;

        /// <summary>
        /// The primary key to the education level
        /// </summary>
        public int EducationLevelID
        {
            get { return educationLevelId; }
            set { educationLevelId = value; }
        }

        /// <summary>
        /// The name for the education level
        /// </summary>
        public string Level
        {
            get { return level; }
            set { level = value; }
        }

        /// <summary>
        /// a description for the education level
        /// </summary>
        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        /// <summary>
        /// IAutoDropDownItem member to expose the education levels name
        /// </summary>
        public string Text
        {
            get
            {
                return Level;
            }
        }

        /// <summary>
        /// IAutoDropDownITem memeber to expose the education level primary key.
        /// </summary>
        public int Value
        {
            get { return EducationLevelID; }
        }


        
    }
}
