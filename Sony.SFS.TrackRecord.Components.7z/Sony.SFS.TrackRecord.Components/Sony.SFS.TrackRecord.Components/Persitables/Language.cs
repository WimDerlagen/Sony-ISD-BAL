using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class Language
    {
        private int languageId;
        private string name;


        public int LanguageId
        {
            get { return languageId; }
            set { languageId = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }




        
    }
}
