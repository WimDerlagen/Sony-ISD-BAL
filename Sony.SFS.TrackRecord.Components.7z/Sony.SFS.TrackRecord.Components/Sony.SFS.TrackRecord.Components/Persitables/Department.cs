using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// A persistable class to hold a department record
    /// </summary>
    [Serializable]
    public class Department
    {
        private int departmentId = 0;
        private string name = string.Empty;
        private string description = string.Empty;
        private int managedByFunction = 0;
        private int departmentNumber = 0;
        

        /// <summary>
        /// The primary key to the record
        /// </summary>
        public int DepartmentID
        {
            get { return departmentId; }
            set { departmentId = value; }
        }

        /// <summary>
        /// The name of the department
        /// </summary>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        /// A description for the deparmtent
        /// </summary>
        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        /// <summary>
        /// An ID of the function managing this department
        /// </summary>
        public int ManagedByFunction
        {
            get { return managedByFunction; }
            set { managedByFunction = value; }
        }

        /// <summary>
        /// The department number as defined in Primus
        /// </summary>
        public int DepartmentNumber
        {
            get { return departmentNumber; }
            set { departmentNumber = value; }
        }
        
    }
}
