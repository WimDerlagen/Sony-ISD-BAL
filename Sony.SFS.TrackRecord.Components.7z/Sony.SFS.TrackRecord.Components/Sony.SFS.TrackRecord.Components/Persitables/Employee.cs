using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// A pesistable class to hold an employee record
    /// </summary>
    public class Employee
    {
        private int employeeId;
        private string firstName;
        private string middleName;
        private string lastName;
        private string address1;
        private string address2;
        private string zipCode;
        private string city;
        private string gender;
        private DateTime birthdate;
        private DateTime employeeSince;
        private string ambition;
        private int imageId;

        private Image image = new Image();
        private EmployeeFunction function = new EmployeeFunction();
        private WorkstyleRating rating = new WorkstyleRating();
        private List<EmployeeSkill> skills = new List<EmployeeSkill>();
        private List<License> licenses = new List<License>();
        private List<EmployeeLanguage> languages = new List<EmployeeLanguage>();
        private List<EmployeeAmbition> ambitions = new List<EmployeeAmbition>();
        private List<Training> trainings = new List<Training>();

        /// <summary>
        /// The employees primary key
        /// </summary>
        public int EmployeeId
        {
            get { return employeeId; }
            set { employeeId = value; }
        }

       
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }
        public string MiddleName
        {
            get { return middleName; }
            set { middleName = value; }
        }
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }
        public string Address1
        {
            get { return address1; }
            set { address1 = value; }
        }
        public string Address2
        {
            get { return address2; }
            set { address2 = value; }
        }
        public string ZipCode
        {
            get { return zipCode; }
            set { zipCode = value; }
        }
        public string City
        {
            get { return city; }
            set { city = value; }
        }
        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }
        public DateTime Birthdate
        {
            get { return birthdate; }
            set { birthdate = value; }
        }
        public DateTime EmployeeSince
        {
            get { return employeeSince; }
            set { employeeSince = value; }
        }
        public string Ambition
        {
            get { return ambition; }
            set { ambition = value; }
        }

        public int ImageID
        {
            get { return imageId; }
            set { imageId = value; }
        }

        public Image Image
        {
            get { return image; }
            set { image = value; }
        }

        /// <summary>
        /// The function the employee currently has
        /// </summary>
        public EmployeeFunction Function
        {
            get { return function; }
            set { function = value; }
        }

        /// <summary>
        /// The latest workstyle rating issued to the employee
        /// </summary>
        public WorkstyleRating Rating
        {
            get { return rating; }
            set { rating = value; }
        }

        /// <summary>
        /// The skills the employee has
        /// </summary>
        public List<EmployeeSkill> Skills
        {
            get { return skills; }
            set { skills = value; }
        }

        /// <summary>
        /// The licenses the employee has
        /// </summary>
        public List<License> Licenses
        {
            get { return licenses; }
            set { licenses = value; }
        }

        /// <summary>
        /// The languages the employee has
        /// </summary>
        public List<EmployeeLanguage> Languages
        {
            get { return languages; }
            set { languages = value; }
        }

        /// <summary>
        /// The ambitions the employee has
        /// </summary>
        public List<EmployeeAmbition> Ambitions
        {
            get { return ambitions; }
            set { ambitions = value; }
        }

        /// <summary>
        /// The trainings the employee has taken
        /// </summary>
        public List<Training> Trainings
        {
            get { return trainings; }
            set { trainings = value; }
        }


         
    }
}
