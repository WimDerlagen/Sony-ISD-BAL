using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// A persistable object to hold an possible answer to a multiple choice ambition
    /// </summary>
    public class AmbitionChoice
    {
        private int ambitionChoiceId;
        private int ambitionTypeId;
        private string choice;

        /// <summary>
        /// The ID of the record
        /// </summary>
        public int AmbitionChoiceID
        {
            get { return ambitionChoiceId; }
            set { ambitionChoiceId = value; }
        }

        /// <summary>
        /// The ID of the ambition
        /// </summary>
        public int AmbitionTypeID
        {
            get { return ambitionTypeId; }
            set { ambitionTypeId = value; }
        }

        /// <summary>
        /// The answer to the ambition
        /// </summary>
        public string Choice
        {
            get { return choice; }
            set { choice = value; }
        }



        
    }
}
