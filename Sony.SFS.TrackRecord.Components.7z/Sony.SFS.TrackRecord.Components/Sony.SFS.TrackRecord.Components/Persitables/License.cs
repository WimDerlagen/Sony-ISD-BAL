using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class License
    {
        private int licenseId;
        private string license;


        public int LicenseId
        {
            get { return licenseId; }
            set { licenseId = value; }
        }
        
        public string LicenseName
        {
            get { return license; }
            set { license = value; }
        }

         
    }
}
