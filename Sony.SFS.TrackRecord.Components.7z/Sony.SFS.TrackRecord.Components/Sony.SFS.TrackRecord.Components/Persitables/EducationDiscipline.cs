using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// A persistable to hold a education discipline
    /// </summary>
    [Serializable]
    public class EducationDiscipline : IAutoDropDownItem
    {
        private int educationDisciplineId = 0;
        private string discipline = string.Empty;
        private string description = string.Empty;

        /// <summary>
        /// The primary key to the record
        /// </summary>
        public int EducationDisciplineID
        {
            get { return educationDisciplineId; }
            set { educationDisciplineId = value; }
        }

        /// <summary>
        /// The name of the discipline
        /// </summary>
        public string Discipline
        {
            get { return discipline; }
            set { discipline = value; }
        }

        /// <summary>
        /// a description for the discipline
        /// </summary>
        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        /// <summary>
        /// IAutoDropDownItem member to expose the disciplines name
        /// </summary>
        public string Text
        {
            get { return Discipline; }
        }

        /// <summary>
        /// IAutoDropDownItem memeber to expose the primary key
        /// </summary>
        public int Value
        {
            get { return EducationDisciplineID; }
        }


          
    }
}
