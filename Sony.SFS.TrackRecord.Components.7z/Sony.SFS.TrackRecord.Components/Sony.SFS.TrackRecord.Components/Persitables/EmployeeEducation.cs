using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class EmployeeEducation
    {
        private int employeeEducationId = 0;
        private int levelId = 0;
        private int disciplineId = 0;
        private DateTime startDate = DateTime.Now;
        private DateTime endDate = DateTime.Now;
        private string location = string.Empty;
        private string description = string.Empty;
        private int employeeId = 0;
        private EducationType educationType = EducationType.Education;
        private bool completed = true;
        private string title = string.Empty;

        private EducationLevel level = new EducationLevel();
        private EducationDiscipline discipline = new EducationDiscipline();

        public int EmployeeEducationID
        {
            get { return employeeEducationId; }
            set { employeeEducationId = value; }
        }
        public int LevelID
        {
            get { return levelId; }
            set { levelId = value; }
        }
        public int DisciplineID
        {
            get { return disciplineId; }
            set { disciplineId = value; }
        }
        public DateTime StartDate
        {
            get { return startDate; }
            set { startDate = value; }
        }
        public DateTime EndDate
        {
            get { return endDate; }
            set { endDate = value; }
        }
        public string Location
        {
            get { return location; }
            set { location = value; }
        }
        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public EducationLevel EducationLevel
        {
            get { return level; }
            set { level = value; }
        }
        public EducationDiscipline Discipline
        {
            get { return discipline; }
            set { discipline = value; }
        }


        public int EmployeeID
        {
            get { return employeeId; }
            set { employeeId = value; }
        }
        public EducationType EducationType
        {
            get { return educationType; }
            set { educationType = value; }
        }
        public bool Completed
        {
            get { return completed; }
            set { completed = value; }
        }
        public string Title
        {
            get { return title; }
            set { title = value; }
        }
    }
}
