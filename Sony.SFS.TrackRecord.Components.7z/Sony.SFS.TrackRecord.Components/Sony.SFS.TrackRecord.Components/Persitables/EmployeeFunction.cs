using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class EmployeeFunction : ICloneable  
    {
        private int employeeFunctionId;
        private int employeeId;
        private int functionId;
        private int departmentId;
        private DateTime startDate = new DateTime(1900,1,1);
        private DateTime endDate = new DateTime(1900,1,1);
        private int preferredDuration;
        private bool current;
        private Function function;
        private Department department;

        public int EmployeeFunctionID
        {
            get { return employeeFunctionId; }
            set { employeeFunctionId = value; }
        }
        public int EmployeeID
        {
            get { return employeeId; }
            set { employeeId = value; }
        }
        public int FunctionID
        {
            get { return functionId; }
            set { functionId = value; }
        }
        public int DepartmentID
        {
            get { return departmentId; }
            set { departmentId = value; }
        }
        public DateTime StartDate
        {
            get { return startDate; }
            set { startDate = value; }
        }
        public DateTime EndDate
        {
            get { return endDate; }
            set { endDate = value; }
        }
        public int PreferredDuration
        {
            get { return preferredDuration; }
            set { preferredDuration = value; }
        }
        public bool Current
        {
            get { return current; }
            set { current = value; }
        }

        public Function Function
        {
            get { return function; }
            set { function = value; }
        }

        public Department Department
        {
            get { return department; }
            set { department = value; }
        }

        #region ICloneable Members

        public object Clone()
        {
            EmployeeFunction function = new EmployeeFunction();

            function.employeeFunctionId = (int)this.employeeFunctionId;
            function.employeeId = (int)this.employeeId;
            function.functionId = (int)this.functionId;
            function.departmentId = (int)this.departmentId;
            function.startDate = (DateTime)this.startDate;
            function.endDate = (DateTime)this.endDate;
            function.preferredDuration = (int)this.preferredDuration;
            function.current = (bool)this.current;

            return function;
        }

        #endregion
    }
}
