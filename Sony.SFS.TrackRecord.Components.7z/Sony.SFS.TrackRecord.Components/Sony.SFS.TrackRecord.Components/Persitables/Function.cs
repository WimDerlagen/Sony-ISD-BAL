using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    [Serializable]
    public class Function
    {
        private int functionId = 0;
        private string title = string.Empty;
        private string description = string.Empty;
        private int desiredDuration = 0;
        private string division = string.Empty;
        private int departmentId = 0;
        private Department department = new Department();
        private string location = string.Empty;
        private string manages = string.Empty;
        private string requirements = string.Empty;
        private string functionGoals = string.Empty;
        private string responsibilities = string.Empty;
        private string keyPerformanceIndicators = string.Empty;
        private bool managing = false;

        public int FunctionID
        {
            get { return functionId; }
            set { functionId = value; }
        }
        public string Title
        {
            get { return title; }
            set { title = value; }
        }
        public string Description
        {
            get { return description; }
            set { description = value; }
        }
        public int DesiredDuration
        {
            get { return desiredDuration; }
            set { desiredDuration = value; }
        }

        public string Division
        {
            get { return division; }
            set { division = value; }
        }
        public int DepartmentID
        {
            get { return departmentId; }
            set { departmentId = value; }
        }
        public Department Department
        {
            get { return department; }
            set { department = value; }
        }
        public string Location
        {
            get { return location; }
            set { location = value; }
        }

        public string Requirements
        {
            get { return requirements; }
            set { requirements = value; }
        }
        public string Manages
        {
            get { return manages; }
            set { manages = value; }
        }
        public string FunctionGoals
        {
            get { return functionGoals; }
            set { functionGoals = value; }
        }
        public string Responsibilities
        {
            get { return responsibilities; }
            set { responsibilities = value; }
        }
        public string KeyPerformanceIndicators
        {
            get { return keyPerformanceIndicators; }
            set { keyPerformanceIndicators = value; }
        }

        public bool Managing
        {
            get { return managing; }
            set { managing = value; }
        }


         
    }
}
