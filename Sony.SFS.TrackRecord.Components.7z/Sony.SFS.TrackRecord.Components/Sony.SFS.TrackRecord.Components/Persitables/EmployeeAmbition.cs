using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// A persistable class for an employee ambition record
    /// </summary>
    public class EmployeeAmbition
    {
        private int employeeAmbitionId = 0;
        private AmbitionChoiceType ambitionChoiceType = AmbitionChoiceType.Choice;
        private int ambitionId = 0;
        private int choiceId = 0;
        private int employeeId = 0;
        private string ambitionText = string.Empty;

        private AmbitionType ambitionType = new AmbitionType();
        private AmbitionChoice ambitionChoice = new AmbitionChoice();

        /// <summary>
        /// The employees ambition primary key
        /// </summary>
        public int EmployeeAmbitionID
        {
            get { return employeeAmbitionId; }
            set { employeeAmbitionId = value; }
        }

        /// <summary>
        /// The type of ambition used
        /// </summary>
        public AmbitionChoiceType AmbitionChoiceType
        {
            get { return ambitionChoiceType; }
            set { ambitionChoiceType = value; }
        }

        /// <summary>
        /// The foreign key of the ambition used, or the primary key to a function, if the AmbitionChoiceType is set to Function
        /// </summary>
        public int AmbitionID
        {
            get { return ambitionId; }
            set { ambitionId = value; }
        }

        /// <summary>
        /// The foreign key of the choice for the ambition
        /// </summary>
        public int ChoiceID
        {
            get { return choiceId; }
            set { choiceId = value; }
        }

        /// <summary>
        /// The foreign key for the employee
        /// </summary>
        public int EmployeeID
        {
            get { return employeeId; }
            set { employeeId = value; }
        }

        /// <summary>
        /// The ambition object
        /// </summary>
        public AmbitionType AmbitionType
        {
            get { return ambitionType; }
            set { ambitionType = value; }
        }

        /// <summary>
        /// The ambition choice object
        /// </summary>
        public AmbitionChoice AmbitionChoice
        {
            get { return ambitionChoice; }
            set { ambitionChoice = value; }
        }

        /// <summary>
        /// The arbitrairaly ambition text
        /// </summary>
        public string AmbitionText
        {
            get { return ambitionText; }
            set { ambitionText = value; }
        }

        public EmployeeAmbition() { }

        public EmployeeAmbition(int ambitionId)
        {
            this.employeeAmbitionId = ambitionId;
        }
        
    }
}
