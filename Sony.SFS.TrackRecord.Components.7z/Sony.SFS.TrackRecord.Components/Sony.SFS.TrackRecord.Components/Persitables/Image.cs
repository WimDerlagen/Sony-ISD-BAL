using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    
    public class Image
    {
        private int imageId;
        private string filename;


        public int ImageId
        {
            get { return imageId; }
            set { imageId = value; }
        }

        public string Filename
        {
            get { return filename; }
            set { filename = value; }
        }


          
    }

}
