using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class UploadedFile
    {
        private int fileId = 0;
        private string filePath = string.Empty;
        private string fileName = string.Empty;
        private FileType fileType = FileType.EmployeesTable;
        private char delimiter = ';';
        private bool fileRead = false;
        private bool processed = false;
        private ImportType importType = ImportType.Excel;

        public int FileID
        {
            get{return fileId;}
            set { fileId = value; }
        }
        public string FilePath
        {
            get { return filePath; }
            set { filePath = value; }
        }
        public string FileName
        {
            get { return fileName; }
            set { fileName = value; }
        }
        public FileType FileType
        {
            get { return fileType; }
            set { fileType = value; }
        }
        public char Delimiter
        {
            get { return delimiter; }
            set { delimiter = value; }
        }
        public bool FileRead
        {
            get { return fileRead; }
            set { fileRead = value; }
        }
        public bool Processed
        {
            get { return processed; }
            set { processed = value; }
        }
        public ImportType ImportType
        {
            get { return importType; }
            set { importType = value; }
        }
    }
}
