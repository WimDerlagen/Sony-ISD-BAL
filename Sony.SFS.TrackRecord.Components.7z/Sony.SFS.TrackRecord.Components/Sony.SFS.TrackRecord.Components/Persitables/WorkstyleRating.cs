using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class WorkstyleRating
    {
        private int workstyleId;
        private string year;
        private WorkstyleRatingLevel rating;
        private string attachment;
        private int employeeId;

        public int WorkstyleId
        {
            get { return workstyleId; }
            set { workstyleId = value; }
        }
        public string Year
        {
            get { return year; }
            set { year = value; }
        }
        public WorkstyleRatingLevel Rating
        {
            get { return rating; }
            set { rating = value; }
        }
        public string Attachment
        {
            get { return attachment; }
            set { attachment = value; }
        }
        public int EmployeeID
        {
            get { return employeeId; }
            set { employeeId = value; }
        }

    }

}
