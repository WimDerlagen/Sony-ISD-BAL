using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class Skill
    {
        private int skillId;
        private string name;
        private string desciption;

        public int SkillID
        {
            get { return skillId; }
            set { skillId = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Desciption
        {
            get { return desciption; }
            set { desciption = value; }
        }
    }
}
