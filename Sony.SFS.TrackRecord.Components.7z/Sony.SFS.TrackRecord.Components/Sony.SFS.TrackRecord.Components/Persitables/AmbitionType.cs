using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class AmbitionType
    {
        /// <summary>
        /// A Persistable class to a multiple choice ambition.
        /// </summary>
        private int ambitionTypeId = 0;
        private string ambitionType = string.Empty;
        private string description = string.Empty;
        private ArrayList choices = new ArrayList();

        /// <summary>
        /// The record ID for the ambition
        /// </summary>
        public int AmbitionTypeID
        {
            get { return ambitionTypeId; }
            set { ambitionTypeId = value; }
        }

        /// <summary>
        /// The name of the ambition
        /// </summary>
        public string AmbitionTypeText
        {
            get { return ambitionType; }
            set { ambitionType = value; }
        }

        /// <summary>
        /// A Description of the ambition
        /// </summary>
        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        /// <summary>
        /// The available answers for this ambition
        /// </summary>
        public ArrayList Choices
        {
            get { return choices; }
            set { choices = value; }
        }

         
    }
}
