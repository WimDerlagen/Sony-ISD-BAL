using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class PrimusEmployee : Employee
    {
        private int primusId = 0;
        private int employeeNumber = 0;
        private int aanhef = 0;
        private string roepNaam = string.Empty;
        private string naam = string.Empty;
        private string straatNaam = string.Empty;
        private int huisnummer = 0;
        private string huisnummerToev = string.Empty;
        private string postcode = string.Empty;
        private string woonplaats = string.Empty;
        private string land = string.Empty;
        private DateTime geboorteDatum = new DateTime(1900, 1,1);
        private DateTime datumInDienst = new DateTime(1900, 1, 1);
        private DateTime datumInDienstSony = new DateTime(1900, 1, 1);
        private string beroep = string.Empty;
        private int afdelingsNummer = 0;
        private string afdelingsNaam = string.Empty;
        private string businessGroep = string.Empty;
        private decimal fte = 0;
        private string functieOmschrijving = string.Empty;
        private int nationaliteit = 0;
        private string voorvoegsel;
        private int vestigingsNummer;
        private EmployeeType employeeType;

        private Image image;
        private int imageId;
        private string ambition;

        private string egrading = string.Empty;
        private string workforceplayer = string.Empty;
        private string workforceposition = string.Empty;
        private string workstylerating = string.Empty;
        private string pratingHr = string.Empty;
        private string pratingMgr = string.Empty;

        public int PrimusId
        {
            get { return primusId; }
            set { primusId = value; }
        }
        public int EmployeeNumber
        {
            get { return employeeNumber; }
            set { employeeNumber = value; }
        }
        public int Aanhef
        {
            get { return aanhef; }
            set { aanhef = value; }
        }
        public string RoepNaam
        {
            get { return roepNaam; }
            set { roepNaam = value; }
        }
        public string Naam
        {
            get { return naam; }
            set { naam = value; }
        }
        public string StraatNaam
        {
            get { return straatNaam; }
            set { straatNaam = value; }
        }
        public int Huisnummer
        {
            get { return huisnummer; }
            set { huisnummer = value; }
        }
        public string HuisnummerToev
        {
            get { return huisnummerToev; }
            set { huisnummerToev = value; }
        }
        public string Postcode
        {
            get { return postcode; }
            set { postcode = value; }
        }
        public string Woonplaats
        {
            get { return woonplaats; }
            set { woonplaats = value; }
        }
        public string Land
        {
            get { return land; }
            set { land = value; }
        }
        public DateTime GeboorteDatum
        {
            get { return geboorteDatum; }
            set { geboorteDatum = value; }
        }
        public DateTime DatumInDienst
        {
            get { return datumInDienst; }
            set { datumInDienst = value; }
        }
        public DateTime DatumInDienstSony
        {
            get { return datumInDienstSony; }
            set { datumInDienstSony = value; }
        }
        public string Beroep
        {
            get { return beroep; }
            set { beroep = value; }
        }
        public int AfdelingsNummer
        {
            get { return afdelingsNummer; }
            set { afdelingsNummer = value; }
        }

        public string AfdelingsNaam
        {
            get { return afdelingsNaam; }
            set { afdelingsNaam = value; }
        }
        public string BusinessGroep
        {
            get { return businessGroep; }
            set { businessGroep = value; }
        }
        public decimal FTE
        {
            get { return fte; }
            set { fte = value; }
        }
        public string FunctieOmschrijving
        {
            get { return functieOmschrijving; }
            set { functieOmschrijving = value; }
        }
        public int Nationaliteit
        {
            get { return nationaliteit; }
            set { nationaliteit = value; }
        }

        public string Voorvoegsel
        {
            get { return voorvoegsel; }
            set { voorvoegsel = value; }
        }

        public int VestigingsNummer
        {
            get { return vestigingsNummer; }
            set { vestigingsNummer = value; }
        }

        public string Ambition
        {
            get { return this.ambition; }
            set { ambition = value; }
        }

        public Image Image
        {
            get { return this.image; }
            set { image = value; }
        }

        public int ImageID
        {
            get { return imageId; }
            set { imageId = value; }
        }

        public EmployeeType EmployeeType
        {
            get{ return employeeType;}
            set { employeeType = value; }
        }
        public string FullName
        {
            get { return Translator.FirstCap(this.roepNaam) + " " + Translator.FirstCap(this.naam); }
        }

        public string EGrading
        {
            get { return egrading; }
            set { egrading = value; }
        }

        public string WorkforcePlayer
        {
            get { return workforceplayer; }
            set { workforceplayer = value; }
        }
        public string WorkforcePosition
        {
            get { return workforceposition; }
            set { workforceposition = value; }
        }
        public string WorkstyleRating
        {
            get { return workstylerating; }
            set { workstylerating = value; }
        }
        public string Remarks
        {
            get { return ambition; }
            set { ambition = value; }
        }

        public string PRatingHR
        {
            get { return pratingHr; }
            set { pratingHr = value; }
        }

        public string PRatingMgr
        {
            get { return pratingMgr; }
            set { pratingMgr = value; }
        }



        public PrimusEmployee() { }

        public PrimusEmployee(PrimusEmployee2 prim)
        {
            this.employeeNumber = prim.EmployeeNummer;
            
            int aanh = 0;
            bool aanhSuc = false;
            aanhSuc = Int32.TryParse(prim.Aanhef, out aanh);
            if (aanhSuc)
            {
                this.aanhef = aanh;
                if (aanh == 2)
                    Gender = "M";
                else
                    Gender = "V";

            }

            this.roepNaam = prim.RoepNaam;
            this.naam = prim.EmployeeNaam;
            this.straatNaam = prim.Straat;

            int huisn = 0;
            bool huisnSuc = false;
            huisnSuc = Int32.TryParse(prim.HuisNummer, out huisn);
            if (huisnSuc)
                this.huisnummer = huisn;

            this.huisnummerToev = prim.HuisNummerToevoeging;
            this.postcode = prim.Postcode;
            this.woonplaats = prim.Woonplaats;
            this.land = prim.Land;
            this.geboorteDatum = prim.GeboorteDatum;
            this.datumInDienst = prim.DatumInDienst;
            this.datumInDienstSony = prim.DatumInDienstSony;
            this.beroep = prim.Beroep;
            this.afdelingsNummer = prim.AfdelingsNummer;
            this.afdelingsNaam = prim.Afdeling;
            this.businessGroep = prim.BusinessGroup;
            this.fte = prim.FTE;
            this.functieOmschrijving = prim.FunctieOmschrijving;
            this.nationaliteit = prim.Nationaliteit;
            this.voorvoegsel = prim.Voorvoegsel;
            this.vestigingsNummer = prim.VestigingsNummer;
            this.employeeType = prim.EmployeeType;
        }

        public void UpdateValuesForImport(PrimusEmployee2 prim)
        {
            this.employeeNumber = prim.EmployeeNummer;

            int aanh = 0;
            bool aanhSuc = false;
            aanhSuc = Int32.TryParse(prim.Aanhef, out aanh);
            if (aanhSuc)
            {
                this.aanhef = aanh;
                if (aanh == 2)
                    Gender = "M";
                else
                    Gender = "V";
            }

            this.roepNaam = prim.RoepNaam;
            this.naam = prim.EmployeeNaam;
            this.straatNaam = prim.Straat;

            int huisn = 0;
            bool huisnSuc = false;
            huisnSuc = Int32.TryParse(prim.HuisNummer, out huisn);
            if (huisnSuc)
                this.huisnummer = huisn;

            this.huisnummerToev = prim.HuisNummerToevoeging;
            this.postcode = prim.Postcode;
            this.woonplaats = prim.Woonplaats;
            this.land = prim.Land;
            this.geboorteDatum = prim.GeboorteDatum;
            this.datumInDienst = prim.DatumInDienst;
            this.datumInDienstSony = prim.DatumInDienstSony;
            this.beroep = prim.Beroep;
            this.afdelingsNummer = prim.AfdelingsNummer;
            this.afdelingsNaam = prim.Afdeling;
            this.businessGroep = prim.BusinessGroup;
            this.fte = prim.FTE;
            this.functieOmschrijving = prim.FunctieOmschrijving;
            this.nationaliteit = prim.Nationaliteit;
            this.voorvoegsel = prim.Voorvoegsel;
            this.vestigingsNummer = prim.VestigingsNummer;
            this.employeeType = prim.EmployeeType;

        }
    }
}
