using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class Training
    {
        private int trainigId;
        private string training;

        public int TrainigID
        {
            get { return trainigId; }
            set { trainigId = value; }
        }

        public string TrainingName
        {
            get { return training; }
            set { training = value; }
        }
        
    }
}
