using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class Suggestion
    {
        private int suggestionId;
        private int employeeId;
        private int functionId;
        private int term;
        private int departmentId;
        private string department;
        private DateTime setDate = DateTime.Now;

        private Function function;
        private PrimusEmployee employee;

        public int SuggestionId
        {
            get { return suggestionId; }
            set { suggestionId = value; }
        }
        public int EmployeeId
        {
            get { return employeeId; }
            set { employeeId = value; }
        }
        public int FunctionId
        {
            get { return functionId; }
            set { functionId = value; }
        }
        public int Term
        {
            get { return term; }
            set { term = value; }
        }

        public int DepartmentID
        {
            get { return departmentId; }
            set { departmentId = value; }
        }

        public string Department
        {
            get { return department; }
            set { department = value; }
        }


        public DateTime SetDate
        {
            get { return setDate; }
            set { setDate = value; }
        }

        public Function Function
        {
            get { return function; }
            set { function = value; }
        }

        public PrimusEmployee Employee
        {
            get { return this.employee; }
            set { this.employee = value; }
        }
        
    }
}
