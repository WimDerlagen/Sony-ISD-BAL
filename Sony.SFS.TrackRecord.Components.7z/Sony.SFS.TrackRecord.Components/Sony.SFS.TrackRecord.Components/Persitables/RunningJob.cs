using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    public class RunningJob
    {
        private int jobId = 0;
        private string jobName = string.Empty;
        private int totalRecords = 0;
        private int currentRecord = 0;
        private int fileId = 0;
        private bool complete = false;
        private bool running = false;
        private int errors = 0;

        public int JobID
        {
            get { return jobId; }
            set { jobId = value; }
        }
        public string JobName
        {
            get { return jobName; }
            set { jobName = value; }
        }
        public int TotalRecords
        {
            get { return totalRecords; }
            set { totalRecords = value; }
        }
        public int CurrentRecord
        {
            get { return currentRecord; }
            set { currentRecord = value; }
        }

        public int FileID
        {
            get { return fileId; }
            set { fileId = value; }
        }

        public bool Complete
        {
            get { return complete; }
            set { complete = value; }
        }

        public bool Running
        {
            get { return running; }
            set { running = value; }
        }

        public int Errors
        {
            get { return errors; }
            set { errors = value; }
        }

        public int PercentageComplete
        {
            get
            {
                try
                {
                    return Convert.ToInt16((Convert.ToDecimal(currentRecord) / Convert.ToDecimal(totalRecords)) * 100);
                }
                catch
                {
                    return 0;
                }
            }
        }


    }
}
