using System;
using System.Collections;
using System.Collections.Specialized;
using System.Configuration;
using System.Web;
using System.Globalization;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// This class serves generic information like Application paths.
    /// </summary>
    public class Globals
    {
        #region Encode/Decode
        /// <summary>
        /// Converts a prepared subject line back into a raw text subject line.
        /// </summary>
        /// <param name="textToFormat">The prepared subject line.</param>
        /// <returns>A raw text subject line.</returns>
        /// <remarks>This function is only needed when editing an existing message or when replying to
        /// a message - it turns the HTML escaped characters back into their pre-escaped status.</remarks>
        public static string HtmlDecode(String textToFormat)
        {
            if (IsNullorEmpty(textToFormat))
                return textToFormat;

            //ScottW: Removed Context dependency
            return System.Web.HttpUtility.HtmlDecode(textToFormat);
            // strip the HTML - i.e., turn < into &lt;, > into &gt;
            //return HttpContext.Current.Server.HtmlDecode(FormattedMessageSubject);
        }

        /// <summary>
        /// Converts a prepared subject line back into a raw text subject line.
        /// </summary>
        /// <param name="textToFormat">The prepared subject line.</param>
        /// <returns>A raw text subject line.</returns>
        /// <remarks>This function is only needed when editing an existing message or when replying to
        /// a message - it turns the HTML escaped characters back into their pre-escaped status.</remarks>
        public static string HtmlEncode(String textToFormat)
        {
            // strip the HTML - i.e., turn < into &lt;, > into &gt;

            if (IsNullorEmpty(textToFormat))
                return textToFormat;

            //ScottW: Removed Context dependency
            return System.Web.HttpUtility.HtmlEncode(textToFormat);
            //return HttpContext.Current.Server.HtmlEncode(FormattedMessageSubject);
        }

        /// <summary>
        /// Url encodes a string into a format useable for URLs
        /// </summary>
        /// <param name="urlToEncode">The string to convert</param>
        /// <returns>A URL encoded string</returns>
        public static string UrlEncode(string urlToEncode)
        {
            if (IsNullorEmpty(urlToEncode))
                return urlToEncode;

            return System.Web.HttpUtility.UrlEncode(urlToEncode);
        }

        /// <summary>
        /// Decodes a URL encoded string
        /// </summary>
        /// <param name="urlToDecode">The string to decode</param>
        /// <returns>The original string</returns>
        public static string UrlDecode(string urlToDecode)
        {
            if (IsNullorEmpty(urlToDecode))
                return urlToDecode;

            return System.Web.HttpUtility.UrlEncode(urlToDecode);
        }


        #endregion

        #region Skin/App Paths
        /// <summary>
        /// Returns the path to the skinfiles.
        /// </summary>
        /// <returns>Path to the skin files</returns>
        static public String GetSkinPath()
        {

            // TODO -- Need to get the full path if the application path is not available
            try
            {
                if (TRConfiguration.GetConfig().FilesPath == "/")
                    return ApplicationPath + "/Themes/default";
                else
                    return ApplicationPath + TRConfiguration.GetConfig().FilesPath + "/Themes/default";
            }
            catch
            {
                return "default";
            }
        }

        /// <summary>
        /// Gets the virtual path where the application is hosted
        /// </summary>
        static public string ApplicationPath
        {

            get
            {
                string applicationPath = "/";

                if (HttpContext.Current != null)
                    applicationPath = HttpContext.Current.Request.ApplicationPath;

                // Are we in an application?
                //
                if (applicationPath == "/")
                {
                    return string.Empty;
                }
                else
                {
                    return applicationPath;
                }
            }

        }

        /// <summary>
        /// Gets the path where user images are stored.
        /// </summary>
        public static string ImagePath
        {
            get
            {
                return PathCombine(ApplicationPath, "Images");
            }
        }

        /// <summary>
        /// Gets the path where the workstyle attachments are stored.
        /// </summary>
        public static string WorkStylesPath
        {
            get
            {
                return PathCombine(ApplicationPath, "Workstyles");
            }
        }

        /// <summary>
        /// Convrtd two path strings into a complete and valid virtual path.
        /// </summary>
        /// <param name="path1">The first part of the path</param>
        /// <param name="path2">The second part of the path</param>
        /// <returns>A valid virtual path</returns>
        public static string PathCombine(string path1, string path2)
        {
            string path;

            if (path1.EndsWith("/") && !path2.StartsWith("/"))
                path = path1 + path2;
            else if (!path1.EndsWith("/") && path2.StartsWith("/"))
                path = path1 + path2;
            else if (path1.EndsWith("/") && path2.StartsWith("/"))
                path = path1 + path2.Substring(1);
            else
                path = path1 + "/" + path2;
            
            
            return path;
           
        }

        /// <summary>
        /// A helper method to test whether a string is null or empty
        /// </summary>
        /// <param name="text">The string to test</param>
        /// <returns>A boolean</returns>
        public static bool IsNullorEmpty(string text)
        {
            return text == null || text.Trim() == string.Empty;
        }

        /// <summary>
        /// A helper method to test whether a string is a date.
        /// </summary>
        /// <param name="text">The string to test</param>
        /// <returns>A boolean</returns>
        public static bool IsDate(string text)
        {
            if (IsNullorEmpty(text))
                return false;

            try
            {
                DateTime dt = DateTime.Parse(text);
                return true;
            }
            catch (Exception) { }

            return false;
        }

        /// <summary>
        /// Returns the hostpath to the supplied Uri
        /// </summary>
        /// <param name="uri">A Uri</param>
        /// <returns>A string containing the hostpath</returns>
        public static string HostPath(Uri uri)
        {
            string portInfo = uri.Port == 80 ? string.Empty : ":" + uri.Port.ToString();
            return string.Format("{0}://{1}{2}", uri.Scheme, uri.Host, portInfo);
        }

        /// <summary>
        /// Converts a local path to a complete virtual path
        /// </summary>
        /// <param name="local">a local virtual path</param>
        /// <returns>A complete virtual path</returns>
        public static string FullPath(string local)
        {
            if (IsNullorEmpty(local))
                return local;

            if (local.ToLower().StartsWith("http://"))
                return local;

            if (HttpContext.Current == null)
                return local;

            return FullPath(HostPath(HttpContext.Current.Request.Url), local);
        }

        public static string FullPath(string hostPath, string local)
        {
            return hostPath + local;
        }


        //static public SiteUrls GetSiteUrls()
        //{
        //    return SiteUrls.Instance();
        //}

        #endregion

        /// <summary>
        /// Adds a string to the current url determining the correct seperator character
        /// </summary>
        /// <param name="url"></param>
        /// <param name="querystring"></param>
        /// <returns></returns>
        public static string AppendQuerystring(string url, string querystring)
        {
            return AppendQuerystring(url, querystring, false);
        }
        public static string AppendQuerystring(string url, string querystring, bool urlEncoded)
        {
            string seperator = "?";
            if (url.IndexOf('?') > -1)
            {
                if (!urlEncoded)
                    seperator = "&";
                else
                    seperator = "&amp;";
            }
            return string.Concat(url, seperator, querystring);
        }


        /// <summary>
        /// A helper method to limit the length of a string. If the string is shorter than the supplied length, no trimming is done.
        /// </summary>
        /// <param name="input">A string to be limited.</param>
        /// <param name="length">A length to limit the string to.</param>
        /// <returns></returns>
        public static string LimitString(string input, int length)
        {
            string output;
            if (input.Length > length)
                output = input.Substring(0, length) + "...";
            else
                output = input;

            return output;
        }   
    }
}
