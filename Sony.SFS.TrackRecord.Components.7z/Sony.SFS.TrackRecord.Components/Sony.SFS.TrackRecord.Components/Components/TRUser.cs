using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Security;


namespace Sony.SFS.TrackRecord.Components
{
    [Obsolete]
    public class TRUser : MembershipUser
    {
        private string fullName;
        private int employeeNumber;

        public string FullName
        {
            get { return fullName; }
            set { fullName = value; }
        }

        public int EmployeeNumber
        {
            get { return employeeNumber; }
            set { employeeNumber = value; }
        }


        public TRUser(string providername,
                                  string username,
                                  object providerUserKey,
                                  string email,
                                  string passwordQuestion,
                                  string comment,
                                  bool isApproved,
                                  bool isLockedOut,
                                  DateTime creationDate,
                                  DateTime lastLoginDate,
                                  DateTime lastActivityDate,
                                  DateTime lastPasswordChangedDate,
                                  DateTime lastLockedOutDate,
                                  string fullName,
                                  int employeeNumber) :
                                  base(providername,
                                       username,
                                       providerUserKey,
                                       email,
                                       passwordQuestion,
                                       comment,
                                       isApproved,
                                       isLockedOut,
                                       creationDate,
                                       lastLoginDate,
                                       lastActivityDate,
                                       lastPasswordChangedDate,
                                       lastLockedOutDate)
        {
            this.fullName = fullName;
            this.employeeNumber = employeeNumber;
        }


    }
}
