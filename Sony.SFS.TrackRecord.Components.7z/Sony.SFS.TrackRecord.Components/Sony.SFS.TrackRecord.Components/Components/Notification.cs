using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// Defines a notification for use in a custom Validation Summary
    /// </summary>
    public class Notification
    {
        private string text;

        /// <summary>
        /// The notification text
        /// </summary>
        public string Text
        {
            get { return text; }
            set { text = value; }
        }

        public Notification(string text)
        {
            this.text = text;
        }
    }
}
