using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// Provides properties to store an employees rating information
    /// </summary>
    public class Rating
    {
        private int ratingId;
        private int employeeId;
        private DateTime rateDate = new DateTime(1900, 1,1);
        private string year;
        private RatingType ratingType;
        private int rating;

        /// <summary>
        /// The primary key of the rating record
        /// </summary>
        public int RatingId
        {
            get { return ratingId; }
            set { ratingId = value; }
        }

        /// <summary>
        /// The employee foreign id
        /// </summary>
        public int EmployeeId
        {
            get { return employeeId; }
            set { employeeId = value; }
        }

        /// <summary>
        /// The date when the rating was given
        /// </summary>
        public DateTime RateDate
        {
            get { return rateDate; }
            set { rateDate = value; }
        }

        /// <summary>
        /// The year to which the rating regards
        /// </summary>
        public string Year
        {
            get { return year; }
            set { year = value; }
        }

        /// <summary>
        /// Defines the type of rating
        /// </summary>
        public RatingType RatingType
        {
            get { return ratingType; }
            set { ratingType = value; }
        }

        /// <summary>
        /// The rating level
        /// </summary>
        public int RatingValue
        {
            get { return rating; }
            set { rating = value; }
        }
    }
}
