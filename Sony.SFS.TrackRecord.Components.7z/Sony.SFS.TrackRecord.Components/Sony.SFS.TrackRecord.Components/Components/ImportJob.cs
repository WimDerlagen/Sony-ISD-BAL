using System;
using System.Collections.Generic;
using System.Text;
using System.Web;


namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// Provides properties for storing information regarding importing of data 
    /// </summary>
    public class ImportJob
    {
         
        private ImportType importType = ImportType.CSV;
        private string fileName = string.Empty;
        private char sepChar;
        private HttpPostedFile postedFile;

        /// <summary>
        /// The type of source file to be imported
        /// </summary>
        public ImportType ImportType
        {
            get { return importType; }
            set { importType = value; }
        }

        /// <summary>
        /// The filename of the file to be imported
        /// </summary>
        public string FileName
        {
            get { return fileName; }
            set { fileName = value; }
        }

        /// <summary>
        /// The seperation character used if the import type is set to CSV
        /// </summary>
        public char SeperationCharacter
        {
            get { return sepChar; }
            set { sepChar = value; }
        }

        /// <summary>
        /// The filestream as posted via a FileUpload Control
        /// </summary>
        public HttpPostedFile PostedFile
        {
            get { return postedFile; }
            set { postedFile = value; }
        }

    }
}
