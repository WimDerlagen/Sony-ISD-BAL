using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// Provides helper methods for translating string values.
    /// </summary>
    public class Translator
    {
        /// <summary>
        /// Cases a string with Pascal Casing. If the input string contains multiple words, the method recursively caps the words
        /// </summary>
        /// <param name="input">The string to be converted</param>
        /// <returns>A string with initial caps</returns>
        public static string FirstCap(string input)
        {
            if (input.Trim() == string.Empty)
                return string.Empty;

            string[] words = input.Split(' ');
            string output = string.Empty;

            if (words.Length > 1)
            {
                foreach (string s in words)
                {
                    output += FirstCap(s);
                    output += " ";
                }

                return output.Trim();
            }
            else
            {
                input = input.ToLower();
                string input1 = input[0].ToString().ToUpper();

                return input1 + input.Substring(1);
            }
        }

        /// <summary>
        /// Translates a rating value to the corresponding string value
        /// </summary>
        /// <param name="value">The int value as stored in the database</param>
        /// <param name="type">The type of rating stored</param>
        /// <returns>The string representation of the rating value</returns>
        public static string Rating(int value, RatingType type)
        {
            //A manual way of converting enum values. Enum.Parse might be the better way to go.
            string output = string.Empty;

            switch (type)
            {
                case RatingType.EGrading:
                    switch (value)
                    {
                        case 1:
                            return "E03";
                        case 2:
                            return "E04";
                        case 3:
                            return "E05";
                        case 4:
                            return "E10";
                        case 5:
                            return "E20";
                        case 6:
                            return "E30";
                        case 7:
                            return "E40";
                        case 8:
                            return "E50";
                        case 9:
                            return "E60";

                    }
                    break;

                case RatingType.WorkforcePlayer:
                case RatingType.WorkforcePosition:
                    switch (value)
                    {
                        case 1:
                            return "A";
                        case 2:
                            return "B";
                        case 3:
                            return "C";
                    }
                    break;
                case RatingType.PRatingHr:
                case RatingType.PRatingMgr:
                    return value.ToString();
                default:
                    return string.Empty;
            }

            return string.Empty;
        }

        /// <summary>
        /// Translates a WorkStyleRatingLevel to a corresponding string value
        /// </summary>
        /// <param name="rating">The workstyle rating level</param>
        /// <returns>A string representation of the rating level</returns>
        public static string WorkstyleRating(WorkstyleRating rating)
        {
            int year = 6;

            try
            {
                year = Convert.ToInt16(rating.Year.Remove(0, 2));
            }
            catch { }

            if (year < 6)
            {
                switch ((int)rating.Rating)
                {
                    case 1:
                        return "E";
                    case 2:
                        return "D";
                    case 3:
                        return "C";
                    case 4:
                        return "B";
                    case 5:
                        return "A";
                    default: return "C";
                }
            }
            else
            {
                switch ((int)rating.Rating)
                {
                    case 1:
                        return "E--";
                    case 2:
                        return "E-";
                    case 3:
                        return "E";
                    case 4:
                        return "E+";
                    case 5:
                        return "E++";
                    default: return "E";
                }
            }
            
        }

        /// <summary>
        /// Translates a WorkstyleRatingLevel string back to an integer
        /// </summary>
        /// <param name="rating">The string representation of the rating level</param>
        /// <returns>The rating level</returns>
        public static int WorkstyleRating(string rating)
        {
            switch (rating)
            {
                case "E--":
                    return 1;
                case "E-":
                    return 2;
                case "E":
                    return 3;
                case "E+":
                    return 4;
                case "E++":
                    return 5;
                default: return 3;
            }
        }
    }
}
