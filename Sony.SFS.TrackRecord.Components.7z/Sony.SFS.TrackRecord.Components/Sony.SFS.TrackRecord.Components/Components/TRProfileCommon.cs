using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Profile;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// A Custom profile class for the System.Web.Profile system.
    /// </summary>
    public class TRProfileCommon : ProfileBase
    {
        /// <summary>
        /// The users Full name as its set in the Active Directory
        /// </summary>
        [SettingsAllowAnonymous(false)]
        [ProfileProvider("SqlProvider")]
        public string FullName
        {
            get { return base["FullName"].ToString(); }
            set { base["FullName"] = value; }
        }

        /// <summary>
        /// The LDAP path to the user class in the Active Directory
        /// </summary>
        [SettingsAllowAnonymous(false)]
        [ProfileProvider("SqlProvider")]
        public string CommonName
        {
            get { return base["CommonName"].ToString(); }
            set { base["CommonName"] = value; }
        }

        /// <summary>
        /// The Primus employee number
        /// </summary>
        [SettingsAllowAnonymous(false)]
        [ProfileProvider("SqlProvider")]
        public int EmployeeNumber
        {
            get {
                int num = 0;
                try
                {
                    num = Convert.ToInt32(base["EmployeeNumber"]);
                }
                catch { }

                return num;
            
            }
            set { base["EmployeeNumber"] = value; }
        }

        /// <summary>
        /// Indicates whether this user is a Sony employee
        /// </summary>
        public bool IsEmployee
        {
            get { return (EmployeeNumber > 0); }
        }
     }

}
