using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace Sony.SFS.TrackRecord.Components
{
    public class TRApplication : HttpApplication
    {
        public delegate void FunctionChangedEventHandler(object sender, FunctionChangedEventArgs e);

        public event FunctionChangedEventHandler PostEmployeeFunctionChanged;


        public void OnFunctionChanged(object sender, string userName)
        {
            if (PostEmployeeFunctionChanged != null)
            {
                PostEmployeeFunctionChanged(sender, new FunctionChangedEventArgs(userName));
            }
        }
    }
}
