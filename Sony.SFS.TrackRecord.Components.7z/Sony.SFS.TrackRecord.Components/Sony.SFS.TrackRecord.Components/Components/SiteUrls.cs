using System;
using System.Collections;
using System.Collections.Specialized;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Caching;
using System.Xml;
using Sony.SFS.TrackRecord.Components;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// Provides an interface to the urls used in the site.
    /// </summary>
    [Obsolete]
    public class SiteUrls
    {
        #region Public Properties
        private NameValueCollection _paths = new NameValueCollection();
        private NameValueCollection _reversePaths = new NameValueCollection();
        private ArrayList _reWrittenUrls = new ArrayList();
        private ArrayList _tabUrls = new ArrayList();
        private NameValueCollection _locations = new NameValueCollection();
        private string _locationFilter;
        private string siteUrlsXmlFile = "SiteUrls.config";

        public string LocationFilter
        {
            get
            {
                return _locationFilter;
            }
        }

        /// <summary>
        /// Property Paths (NameValueCollection)
        /// </summary>
        public NameValueCollection Paths
        {
            get { return this._paths; }
        }

        public NameValueCollection Locations
        {
            get { return this._locations; }
        }

        /// <summary>
        /// Property Paths (NameValueCollection)
        /// </summary>
        public NameValueCollection ReversePaths
        {
            get { return this._reversePaths; }
        }

        public ArrayList ReWrittenUrls
        {
            get { return _reWrittenUrls; }
        }


        public ArrayList TabUrls
        {
            get
            {
                return _tabUrls;
            }
        }

        #endregion
        #region Instance

        private SiteUrls() { }

        public static SiteUrls Instance()
        {
            const string cacheKey = "SiteUrls";

            SiteUrls siteUrls = TRCache.Get(cacheKey) as SiteUrls;

            if (siteUrls == null)
            {
                try
                {
                    siteUrls = new SiteUrls();
                    siteUrls.Initialize();

                    TRCache.Max(cacheKey, siteUrls);
                }
                catch (Exception ex)
                {
                }
            }

            return siteUrls;
        }

        #endregion
        #region site url data

        protected XmlDocument CreateDoc(string appPath)
        {
            XmlDocument doc = new XmlDocument();
            try
            {
                string cml = TRContext.Current.MapPath(appPath + "/" + siteUrlsXmlFile);

                doc.Load(cml);
            }
            catch (Exception e)
            {
                string tr = e.ToString();
            }
            return doc;
        }


        protected void Initialize()
        {
            //pattern used to build Urls
            string globalPath = Globals.ApplicationPath;

            if (globalPath != null)
                globalPath = globalPath.Trim();

            // Load SiteUrls from the SiteUrls.xml file
            //
            XmlDocument doc = CreateDoc(globalPath);

            XmlNode basePaths = doc.SelectSingleNode("SiteUrls/locations");
            ArrayList al = new ArrayList();
            foreach (XmlNode n in basePaths.ChildNodes)
            {
                if (n.NodeType != XmlNodeType.Comment)
                {
                    XmlAttribute name = n.Attributes["name"];
                    XmlAttribute path = n.Attributes["path"];
                    XmlAttribute exclude = n.Attributes["exclude"];


                    if (name != null && path != null)
                    {
                        _locations.Add(name.Value, globalPath + path.Value);
                        if (exclude != null)
                        {
                            string filter = globalPath + path.Value;
                            if (filter != null && filter.Length > 1)
                                al.Add(filter);
                        }
                    }
                }
            }

            _locationFilter = string.Join("|", (string[])al.ToArray(typeof(string)));

            #region SiteUrls
            XmlNode urls = doc.SelectSingleNode("SiteUrls/urls");

            foreach (XmlNode n in urls.ChildNodes)
            {

                if (n.NodeType != XmlNodeType.Comment)
                {
                    string name = n.Attributes["name"].Value;
                    string path = n.Attributes["path"].Value.Replace("^", "&");

                    XmlAttribute vanity = n.Attributes["vanity"];
                    XmlAttribute pattern = n.Attributes["pattern"];
                    XmlAttribute exclPattern = n.Attributes["exclPattern"];

                    bool ignoreLocation = false;

                    if (exclPattern != null)
                        ignoreLocation = System.Convert.ToBoolean(exclPattern.InnerText);
                    else
                        ignoreLocation = false;


                    string location = null;
                    XmlAttribute l = n.Attributes["location"];
                    if (l != null)
                        location = l.Value;

                    if (!ignoreLocation)
                    {
                        _paths.Add(name, _locations[location] + path);
                    }
                    else
                    {
                        _paths.Add(name, globalPath + "/" + location + "/" + path);
                    }

                    //TODO: Determine if we need to store the full path
                    _reversePaths.Add(path, name);

                    //Store full paths like regular urls. 
                    if (vanity != null && pattern != null)
                    {
                        if (!ignoreLocation)
                        {
                            string p = _locations[location] + pattern.Value;
                            string v = _locations[location] + vanity.Value.Replace("^", "&");
                            _reWrittenUrls.Add(new ReWrittenUrl(name, p, v));
                        }
                        else
                        {
                            string p = globalPath + "/" + location + "/" + pattern.Value;
                            string v = _locations[location] + vanity.Value.Replace("^", "&");
                            _reWrittenUrls.Add(new ReWrittenUrl(name, p, v));
                        }
                    }

                }

            }
            #endregion

            //implement a subnode "sitename"
            XmlNode nav = doc.SelectSingleNode("SiteUrls/navigation");
            if (nav != null)
            {
                foreach (XmlNode node in nav.ChildNodes)
                {
                    if (node.NodeType != XmlNodeType.Comment)
                    {
                        XmlAttribute name = node.Attributes["name"];

                        XmlAttribute resourceUrl = node.Attributes["resourceUrl"];
                        XmlAttribute resourceName = node.Attributes["resourceName"];

                        XmlAttribute navigateUrl = node.Attributes["navigateUrl"];
                        XmlAttribute text = node.Attributes["text"];

                        XmlAttribute roles = node.Attributes["roles"];

                        // Set roles to "Everyone" if the attribute is null
                        string rolesValue;
                        if (roles == null)
                            rolesValue = "Everyone";
                        else
                            rolesValue = roles.Value;

                        // Set the navigateUrl to a specified one if no resource entries are given
                        string urlValue;
                        if (resourceUrl == null)
                            urlValue = navigateUrl.Value;
                        else
                            urlValue = FormatUrl(resourceUrl.Value);

                        //// Create the CSLink and add it
                        //TRLink link = new TRLink(name.Value, (resourceName == null) ? null : resourceName.Value, (text == null) ? null : text.Value, urlValue, rolesValue);
                        //_tabUrls.Add(link);
                    }
                }
            }
        }

        #endregion
        #region ReWrittenUrl
        public class ReWrittenUrl
        {
            private string _name;
            private string _path;
            private Regex _regex = null;

            public string Name
            {
                get { return this._name; }
            }

            public ReWrittenUrl(string name, string pattern, string path)
            {
                _name = name;
                _path = path;
                _regex = new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.Compiled);
            }

            public bool IsMatch(string url)
            {
                return _regex.IsMatch(url);
            }

            public virtual string Convert(string url, string qs)
            {

                if (qs != null && qs.StartsWith("?"))
                {
                    qs = qs.Replace("?", "&");
                }
                return string.Format("{0}{1}", _regex.Replace(url, _path), qs);
            }
        }
        #endregion
        #region Formatters

        public string FormatUrl(string name)
        {
            return FormatUrl(name, null);
        }

        public virtual string FormatUrl(string name, params object[] parameters)
        {
            TRContext context = TRContext.Current;

            // TODO: Rewrite this code. this is forum stuff.
            if (name == "Anonymous")
            {

                if (parameters == null)
                    return this.Paths[name];

                else
                {
                    string p = string.Format(Paths[name], parameters);
                    return p;
                }
            }
            else
            {
                if (name == "forum")
                {
                    if (parameters == null)
                        return this.Paths[name];

                    else
                    {
                        //object[] param = new object[parameters.Length+1];
                        //param[0] = context.SiteName;
                        //for (int i =1; i < parameters.Length + 1; i++)
                        //{
                        //	param[i] = parameters[i-1];
                        //}
                        string s = string.Format(Paths[name], parameters);
                        return s;
                    }
                }
                else
                {
                    if (parameters == null)
                        return this.Paths[name];

                    else
                        return string.Format(Paths[name], parameters);
                }



            }
        }

        #endregion
    }
}
