using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// A custom exception for use in TrackRecord
    /// </summary>
    public class TRException
    {
    }
}
