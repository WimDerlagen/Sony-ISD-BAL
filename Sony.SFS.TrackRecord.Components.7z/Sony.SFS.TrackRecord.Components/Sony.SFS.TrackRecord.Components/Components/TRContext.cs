using System;
using System.Collections.Specialized;
using System.IO;
using System.Threading;
using System.Web;
using System.Collections;
using System.Web.Security;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// A singleton to provide an easy access to the current HTTP context. 
    /// </summary>
    public class TRContext
    {
        private HybridDictionary _items = new HybridDictionary();
        private NameValueCollection _queryString = null;
        private string _siteUrl = null;
        private Uri _currentUri;
        private MembershipUser user = Membership.GetUser();
        private Guid _anonUserId = Guid.Empty;

        string rolesCacheKey = null;

        string authenticationType = "forms";

        bool _isEmpty = false;
        bool _isUrlReWritten = false;
        string _rawUrl;

        HttpContext _httpContext = null;
        DateTime requestStartTime = DateTime.Now;

        #region construction


        private TRContext(Uri uri, string siteUrl)
        {
            Initialize(new NameValueCollection(), uri, uri.ToString(), siteUrl);
        }

        private TRContext(HttpContext context)
        {
            this._httpContext = context;
            Initialize(new NameValueCollection(context.Request.QueryString), context.Request.Url, context.Request.RawUrl, GetSiteUrl());
        }

        private TRContext(HttpContext context, bool includeQS)
		{
			this._httpContext = context;

            if(includeQS)
            {
			    Initialize(new NameValueCollection(context.Request.QueryString), context.Request.Url, context.Request.RawUrl, GetSiteUrl());
		    }
            else
            {
                Initialize(null, context.Request.Url, context.Request.RawUrl, GetSiteUrl());
            }
		}

        private void Initialize(NameValueCollection qs, Uri uri, string rawUrl, string siteUrl)
        {
            _queryString = qs;
            _siteUrl = siteUrl;
            _currentUri = uri;
            _rawUrl = rawUrl;

        }

        /// <summary>
        /// Creates an empty TRContext if the HTTPContext is unavailable
        /// </summary>
        /// <returns></returns>
        public static TRContext CreateEmptyContext()
        {
            TRContext trContext = new TRContext(new Uri("http://CreateEmptyContext"), "http://CreateEmptyContext");
            trContext._isEmpty = true;
            SaveContextToStore(trContext);
            return trContext;
        }

        /// <summary>
        /// Creates an empty TRContext using a sitesettings ID
        /// </summary>
        /// <param name="settingsID"></param>
        /// <returns></returns>
        public static TRContext Create(int settingsID)
        {
            TRContext trContext = new TRContext(new Uri("http://CreateContextBySettingsID"), "http://CreateContextBySettingsID");
            //trContext.SiteSettings = SiteSettingsManager.GetSiteSettings(settingsID);
            SaveContextToStore(trContext);
            return trContext;
        }

        /// <summary>
        /// Creates a TRContext using the HTTPContext
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static TRContext Create(HttpContext context)
        {
            TRContext trContext = new TRContext(context, true);
            SaveContextToStore(trContext);

            return trContext;
        }

        /// <summary>
        /// Creates a TRContext using a Uri
        /// </summary>
        /// <param name="uri"></param>
        /// <param name="appName"></param>
        /// <returns></returns>
        public static TRContext Create(Uri uri, string appName)
        {
            TRContext trContext = new TRContext(uri, appName);
            SaveContextToStore(trContext);
            return trContext;
        }

        /// <summary>
        /// Creates a TRContext with a HTTPContext
        /// </summary>
        /// <param name="context">The current HTTPContext</param>
        /// <param name="isRewritten">Indicates whether SearchFriendlyUrls are rewritten</param>
        /// <returns></returns>
        public static TRContext Create(HttpContext context, bool isRewritten)
        {
            TRContext trContext = new TRContext(context);
            trContext.IsUrlReWritten = isRewritten;
            SaveContextToStore(trContext);
            return trContext;
        }

        #endregion


        #region Core Properties
        /// <summary>
        /// Simulates Context.Items and provides a per request/instance storage bag
        /// </summary>
        public IDictionary Items
        {
            get { return _items; }
        }

        /// <summary>
        /// Provides direct access to the .Items property
        /// </summary>
        public object this[string key]
        {
            get
            {
                return this.Items[key];
            }
            set
            {
                this.Items[key] = value;
            }
        }

        /// <summary>
        /// Allows access to QueryString values
        /// </summary>
        public NameValueCollection QueryString
        {
            get { return Context.Request.QueryString; }
        }

        /// <summary>
        /// Quick check to see if we have a valid web reqeust. Returns false if HttpContext == null
        /// </summary>
        public bool IsWebRequest
        {
            get { return this.Context != null; }
        }

        /// <summary>
        /// Indicates whether the user is authenticated
        /// </summary>
        public bool IsAuthenticated
        {
            get { //return !User.IsAnonymous; 
                return false;
            }
        }

        /// <summary>
        /// Indicates the type of authentication used
        /// </summary>
        public string AuthenticationType
        {
            get { return authenticationType; }
            set { authenticationType = value.ToLower(); }
        }

        /// <summary>
        /// Gets the current HTTPContext
        /// </summary>
        public HttpContext Context
        {
            get
            {
                return _httpContext;
            }
        }

        /// <summary>
        /// Gets the current siteUrl
        /// </summary>
        public string SiteUrl
        {
            get { return _siteUrl; }
        }

        /// <summary>
        /// Gets the anonymous userID
        /// </summary>
        public Guid AnonymousUserID
        {
            get
            {
                return _anonUserId;
            }
        }

        #endregion


        #region TRData

        //private TRSiteSettings _currentSettings = null;
        private TRConfiguration _config = null;

        /// <summary>
        /// Gets the sites configuration
        /// </summary>
        public TRConfiguration Config
        {
            get
            {
                if (_config == null)
                    _config = TRConfiguration.GetConfig();

                return _config;
            }
        }

        //public TRSiteSettings SiteSettings
        //{
        //    get
        //    {
        //        if (_currentSettings == null && !IsEmpty)
        //            _currentSettings = SiteSettingsManager.GetSiteSettings(this.SiteUrl);

        //        return _currentSettings;
        //    }
        //    set { _currentSettings = value; }
        //}

        #endregion

        /// <summary>
        /// Gets the currently logged on user.
        /// </summary>
        public MembershipUser User
        {
            get { return this.user; }
            set { this.user = value; }
        }

        private string userName = string.Empty;

        /// <summary>
        /// Gets or sets the user name. The getter retreives the username from the querystring
        /// </summary>
        public string UserName
        {
            get
            {
                if (userName == string.Empty)
                {
                    userName = QueryString["UserName"];
                }

                return userName;
            }
            set { userName = value; }
        }

        private Guid? userId = null;
        /// <summary>
        /// Gets or sets the user id. The getter retreives the userid from the querystring
        /// </summary>
        public Guid? UserID
        {
            get
            {
                if (userId == null)
                {
                    userId = new Guid(QueryString["UserID"]);
                }

                return userId;
            }
            set { userId = value; }
        }

        private int employeeNumber = -2;
        /// <summary>
        /// Gets or sets the employeenumber.
        /// </summary>
        public int EmployeeNumber
        {
            get
            {
                if (employeeNumber == -2)
                {
                    employeeNumber = GetIntFromQueryString("empid", -1);
                }

                return employeeNumber;
            }
            set { employeeNumber = value; }
        }


        private string role = string.Empty;

        public string Role
        {
            get
            {
                if (role == string.Empty)
                {
                    role = QueryString["Role"];

                    if (role == null)
                        role = string.Empty;

                    return role;
                }

                return role;
            }
            set { role = value; }
        }

        private ReportType reportType = ReportType.None;
        /// <summary>
        /// Gets or sets the ReportType
        /// </summary>
        public ReportType ReportType
        {
            get
            {
                int rep = -1;
                if (reportType == ReportType.None)
                {
                    rep = GetIntFromQueryString("Report", -1);
                }

                return (ReportType) rep;

            }
            set
            {
                reportType = value;
            }
        }

        private PrimusEmployee employee;
        /// <summary>
        /// Gets a PrimusEmployee using the employeenumber from the querystring
        /// </summary>
        public PrimusEmployee Employee
        {
            get
            {
                if (employee == null)
                {
                    employee = EmployeesDataService.GetEmployee(EmployeeNumber);
                }

                return employee;
            }
            set { employee = value; }
        }


        private string themeName = "default";
        /// <summary>
        /// Gets or sets the ThemeName
        /// </summary>
        public string ThemeName
        {
            get { return themeName; }
            set { themeName = value; }
        }

        /// <summary>
        /// Gets the ThemeFolder path
        /// </summary>
        public string ThemeFolder
        {
            get { return "~/Themes/" + ThemeName + "/"; }
        }


        #region Status properties
        /// <summary>
        /// Gets or sets the current Uri
        /// </summary>
        public Uri CurrentUri { get { return _currentUri; } set { _currentUri = value; } }

        /// <summary>
        /// Indicates whether the urls are rewritten
        /// </summary>
        public bool IsUrlReWritten { get { return _isUrlReWritten; } set { _isUrlReWritten = value; } }

        #endregion

        #region Helpers
        /// <summary>
        /// Indicates whether the context is empty
        /// </summary>
        public bool IsEmpty
        {
            get { return _isEmpty; }
        }

        // *********************************************************************
        //  GetGuidFromQueryString
        //
        /// <summary>
        /// Retrieves a value from the query string and returns it as an int.
        /// </summary>
        // ***********************************************************************/
        public Guid GetGuidFromQueryString(string key)
        {
            Guid returnValue = Guid.Empty;
            string queryStringValue;

            // Attempt to get the value from the query string
            //
            queryStringValue = QueryString[key];

            // If we didn't find anything, just return
            //
            if (queryStringValue == null)
                return returnValue;

            // Found a value, attempt to conver to integer
            //
            try
            {

                // Special case if we find a # in the value
                //
                if (queryStringValue.IndexOf("#") > 0)
                    queryStringValue = queryStringValue.Substring(0, queryStringValue.IndexOf("#"));

                returnValue = new Guid(queryStringValue);
            }
            catch { }

            return returnValue;

        }

        // *********************************************************************
        //  GetIntFromQueryString
        //
        /// <summary>
        /// Retrieves a value from the query string and returns it as an int.
        /// </summary>
        // ***********************************************************************/
        public int GetIntFromQueryString(string key, int defaultValue)
        {
            string queryStringValue;


            // Attempt to get the value from the query string
            //
            queryStringValue = this.QueryString[key];

            // If we didn't find anything, just return
            //
            if (queryStringValue == null)
                return defaultValue;

            // Found a value, attempt to conver to integer
            //
            try
            {

                // Special case if we find a # in the value
                //
                if (queryStringValue.IndexOf("#") > 0)
                    queryStringValue = queryStringValue.Substring(0, queryStringValue.IndexOf("#"));

                defaultValue = Convert.ToInt32(queryStringValue);
            }
            catch { }

            return defaultValue;

        }

        /// <summary>
        /// Converts a virtual path to an actual path
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public string MapPath(string path)
        {
            if (_httpContext != null)
                return _httpContext.Server.MapPath(path);
            else
                // Returns System\WOW for non web // return Directory.GetCurrentDirectory() + path.Replace("/", @"\").Replace("~", "");
                return PhysicalPath(path.Replace("/", Path.DirectorySeparatorChar.ToString()).Replace("~", ""));
        }

        
        public string PhysicalPath(string path)
        {
            return string.Concat(RootPath().TrimEnd(Path.DirectorySeparatorChar), Path.DirectorySeparatorChar.ToString(), path.TrimStart(Path.DirectorySeparatorChar));
        }

        private string _rootPath = null;

        private string RootPath()
        {
            if (_rootPath == null)
            {
                _rootPath = AppDomain.CurrentDomain.BaseDirectory;
                string dirSep = Path.DirectorySeparatorChar.ToString();

                _rootPath = _rootPath.Replace("/", dirSep);

                string filePath = Config.FilesPath;

                if (filePath != null)
                {
                    filePath = filePath.Replace("/", dirSep);

                    if (filePath.Length > 0 && filePath.StartsWith(dirSep) && _rootPath.EndsWith(dirSep))
                    {
                        _rootPath = _rootPath + filePath.Substring(1);
                    }
                    else
                    {
                        _rootPath = _rootPath + filePath;
                    }
                }
            }
            return _rootPath;
        }

        private string GetSiteUrl()
        {
            string appOverride = this.Config.ApplicationOverride;
            if (appOverride != null)
                return appOverride;

            //NOTE: Watch this change. Should be safe, but not tested.
            //Virtualization means urls must be very precise.
            string hostName = _httpContext.Request.Url.Host.Replace("www.", string.Empty);
            string applicationPath = _httpContext.Request.ApplicationPath;

            if (applicationPath.EndsWith("/"))
                applicationPath = applicationPath.Remove(applicationPath.Length - 1, 1);

            return hostName + applicationPath;

        }
        #endregion




        #region State
        private static readonly string dataKey = "trContextStore";

        /// <summary>
        /// Returns the current instance of the trContext from the ThreadData Slot. If one is not found and a valid HttpContext can be found,
        /// it will be used. Otherwise, an exception will be thrown. 
        /// </summary>
        public static TRContext Current
        {
            get
            {
                HttpContext httpContext = HttpContext.Current;
                TRContext context = null;
                if (httpContext != null)
                {
                    context = httpContext.Items[dataKey] as TRContext;
                }
                else
                {
                    context = Thread.GetData(GetSlot()) as TRContext;
                }

                if (context == null)
                {

                    if (httpContext == null)
                        throw new Exception("No trContext exists in the Current Application. AutoCreate fails since HttpContext.Current is not accessible.");

                    context = new TRContext(httpContext, true);
                    SaveContextToStore(context);
                }
                return context;
            }
        }

        private static LocalDataStoreSlot GetSlot()
        {
            return Thread.GetNamedDataSlot(dataKey);
        }

        private static void SaveContextToStore(TRContext context)
        {
            if (context.IsWebRequest)
            {
                context.Context.Items[dataKey] = context;
            }
            else
            {
                Thread.SetData(GetSlot(), context);
            }

        }

        public static void Unload()
        {
            Thread.FreeNamedDataSlot(dataKey);
        }


        public void Redirect(string url)
        {
            Context.Response.Redirect(url);
        }

        #endregion

    }
}
