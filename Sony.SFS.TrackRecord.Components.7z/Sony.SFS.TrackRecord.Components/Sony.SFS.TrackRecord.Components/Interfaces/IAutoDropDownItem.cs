using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// provides an interface to the value properties for use in DropDownLists
    /// </summary>
    public interface IAutoDropDownItem
    {
        string Text { get;}
        int Value { get;}
    }
}
