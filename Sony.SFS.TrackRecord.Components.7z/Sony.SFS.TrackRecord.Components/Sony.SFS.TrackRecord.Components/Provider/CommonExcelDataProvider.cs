using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Configuration.Provider;
using System.Data.Odbc;
using System.Data;
using System.Data.Common;
using Sony.SFS.TrackRecord.Collections;

namespace Sony.SFS.TrackRecord.Components
{
    public abstract class CommonExcelDataProvider : ProviderBase
    {
        public abstract string ApplicationName { get; set; }
        
        public abstract int GetDepartmentCount(string filePath);
        public abstract int GetFunctionCount(string filePath);
        public abstract int GetEmployeeCount(string filePath);

        public abstract ArrayList GetDepartments(string filePath);
        public abstract ArrayList GetFunctions(string filePath);
        public abstract ArrayList GetEmployees(string filePath, RunningJob job);



        #region population methods

        internal PrimusEmployee PopulatePrimusEmployeeFromDbReader(DbDataReader reader, out bool done)
        {
            PrimusEmployee emp = new PrimusEmployee();
            done = false;

            if (Convert.ToString(reader[0]).Trim() == string.Empty)
            {
                done = true;
                return null;
            }

            emp.EmployeeNumber = Convert.ToInt32(reader[0]);
            emp.Aanhef = Convert.ToInt32(reader[1]);
            emp.Naam = Translator.FirstCap((string)reader[2]);
            emp.StraatNaam = Translator.FirstCap((string)reader[3]);
            emp.Huisnummer = Convert.ToInt32(reader[4]);
            emp.HuisnummerToev = (string)reader[5];
            emp.Postcode = (string)reader[6];
            emp.Woonplaats = Translator.FirstCap((string)reader[7]);
            emp.Land = (string)reader[8];
            emp.GeboorteDatum = Convert.ToDateTime(reader[9]);
            emp.DatumInDienst = Convert.ToDateTime(reader[10]);
            emp.Beroep = Translator.FirstCap((string)reader[11]);
            try
            {
                emp.AfdelingsNummer = Convert.ToInt32(reader[12]);
            }
            catch
            {
                emp.AfdelingsNummer = 0;
            }
            emp.BusinessGroep = (string)reader[14];

            decimal tr = 0;

            if (!Decimal.TryParse(Convert.ToString(reader[16]), out tr))
                emp.FTE = 0;
            else
                emp.FTE = tr;

            emp.FunctieOmschrijving = (string)reader[17];
            try
            {
                //veld is niet altijd gevuld
                emp.DatumInDienstSony = (DateTime)reader[18];
            }
            catch { }


            emp.Nationaliteit = Convert.ToInt32(reader[19]);
            emp.RoepNaam = (string)reader[20];
            try
            {
                emp.VestigingsNummer = Convert.ToInt32(reader[21]);
            }
            catch
            {
                emp.VestigingsNummer = 0;
            }

            emp.Voorvoegsel = (string)reader[22];



            return emp;

        }

        protected PrimusEmployee2 PopulatePrimusEmployee2FromDbReader(DbDataReader reader)
        {
            PrimusEmployee2 prim = new PrimusEmployee2();

            string workstyle = "WS rating FY{0}";
            string player = "Player FY{0}";
            string position = "Position FY{0}";
            string egrade = "E-grade FY{0}";
            string fiscalYear = "FY{0}";

            prim.EmployeeNummer = Convert.ToInt32(reader["Employeenr#"]);
            prim.Aanhef = Convert.ToString(reader["Aanhef"]);
            prim.EmployeeNaam = Translator.FirstCap((string)reader["Naam Employee"]);
            prim.Straat = Translator.FirstCap((string)reader["Straatnaam"]);
            prim.HuisNummer = Convert.ToString(reader["Huisnummer"]);
            prim.HuisNummerToevoeging = Convert.ToString(reader["Toevoeging huisnr#"]);
            prim.Postcode = (string)reader["Postcode"];
            prim.Woonplaats = Translator.FirstCap((string)reader["Woonplaats"]);
            prim.Land = (string)reader["Woonland Woonadres"];
            prim.GeboorteDatum = (DateTime)reader["Geboortedatum"];
            prim.DatumInDienst = (DateTime)reader["Datum in dienst"];
            prim.Beroep = Translator.FirstCap((string)reader["Beroep"]);

            int afdelingnr = 0;
            bool hasAfdelingnr = Int32.TryParse(Convert.ToString(reader["Afdelingsnummer"]), out afdelingnr);

            prim.AfdelingsNummer = afdelingnr;

            prim.Afdeling = (string)reader["Afdeling"];
            prim.BusinessGroup = (string)reader["Business groep"];
            prim.BusinessOwner = (string)reader["Business Owner"];

            prim.FTE = Convert.ToDecimal(reader["FTE"]);
            prim.FunctieOmschrijving = (string)reader["Functie Omschrijving"];
            prim.DatumInDienstSony = (DateTime)reader["In dienst Sony Corp"];
            prim.Nationaliteit = Convert.ToInt32(reader["Lang Nationaliteit"]);
            prim.RoepNaam = Translator.FirstCap((string)reader["Roepnaam"]);
            prim.VestigingsNummer = Convert.ToInt32(reader["Vestigingsnummer"]);
            prim.Voorvoegsel = (string)reader["Voorv# naam employee"];

            #region workstyleRating
            //Get workstyle rating from source
            //each year is set in a seperate column
            for (int i = 4; i < 12; i++)
            {
                //build the year string
                string year;
                if (i < 10)
                    year = "0" + i.ToString();
                else
                    year = i.ToString();

                //try to fetch data, it might not exist
                try
                {
                    //build column name
                    string workstyleRating = string.Format(workstyle, year);
                    string wsValue = (string)reader[workstyleRating];
                    object value = null;

                    //retreive enum value from string indication
                    if (wsValue != null && wsValue != string.Empty)
                    {
                        if (i < 6)
                        {
                            switch (wsValue)
                            {
                                case "A":
                                    value = WorkstyleRatingLevel.Eplusplus;
                                    break;
                                case "B":
                                    value = WorkstyleRatingLevel.Eplus;
                                    break;
                                case "C":
                                    value = WorkstyleRatingLevel.E;
                                    break;
                                case "D":
                                    value = WorkstyleRatingLevel.Emin;
                                    break;
                                case "E":
                                    value = WorkstyleRatingLevel.Eminmin;
                                    break;

                                case "":
                                    throw new EmptyRatingValueException();

                                default:
                                    throw new UnknownRatingValueException();
                            }
                        }
                        else
                        {
                            switch (wsValue)
                            {
                                case "E++":
                                    value = WorkstyleRatingLevel.Eplusplus;
                                    break;
                                case "E+":
                                    value = WorkstyleRatingLevel.Eplus;
                                    break;
                                case "E":
                                    value = WorkstyleRatingLevel.E;
                                    break;
                                case "E-":
                                    value = WorkstyleRatingLevel.Emin;
                                    break;
                                case "E--":
                                    value = WorkstyleRatingLevel.Eminmin;
                                    break;

                                case "":
                                    throw new EmptyRatingValueException();

                                default:
                                    throw new UnknownRatingValueException();
                            }
                        }//if i < 6

                        prim.WSRatings.Add(string.Format(fiscalYear, year), value);

                    }//if wsValue

                }
                catch (UnknownRatingValueException unex)
                {
                    string ex1 = unex.ToString();
                }
                catch (EmptyRatingValueException emex)
                {
                    string ex2 = emex.ToString();
                }
                catch (IndexOutOfRangeException index)
                {
                    //the column does not exist yet (e.g. FY08)
                }
                catch (Exception e)
                {
                    string exp = e.ToString();
                }

            } //workstyle

            #endregion

            #region workforce player

            for (int i = 4; i < 12; i++)
            {
                //build the year string
                string year;
                if (i < 10)
                    year = "0" + i.ToString();
                else
                    year = i.ToString();

                try
                {
                    //build column name
                    string workforcePlayer = string.Format(player, year);
                    string plValue = (string)reader[workforcePlayer];
                    object value;

                    switch (plValue)
                    {
                        case "A":
                        case "A+":
                            value = 1;
                            break;

                        case "B":
                        case "B+":
                            value = 2;
                            break;

                        case "C":
                        case "C+":
                            value = 3;
                            break;

                        case "":
                            throw new EmptyRatingValueException();

                        default:
                            throw new UnknownRatingValueException();
                    }

                    prim.WFPlayer.Add(string.Format(fiscalYear, year), value);
                }
                catch (UnknownRatingValueException unex)
                {
                    string ex1 = unex.ToString();
                }
                catch (EmptyRatingValueException emex)
                {
                    string ex2 = emex.ToString();
                }
                catch (IndexOutOfRangeException index)
                {
                    //column doesn't exist yet (e.g. FY08)
                }
                catch (Exception e)
                {
                    string exp = e.ToString();
                }
            }//player

            #endregion

            #region workforce position
            for (int i = 4; i < 12; i++)
            {
                //build the year string
                string year;
                if (i < 10)
                    year = "0" + i.ToString();
                else
                    year = i.ToString();

                try
                {
                    //build column name
                    string workforcePosition = string.Format(position, year);
                    string plValue = (string)reader[workforcePosition];
                    object value;

                    switch (plValue)
                    {
                        case "A":
                        case "A+":
                            value = 1;
                            break;

                        case "B":
                        case "B+":
                            value = 2;
                            break;

                        case "C":
                        case "C+":
                            value = 3;
                            break;

                        case "":
                            throw new EmptyRatingValueException();

                        default:
                            throw new UnknownRatingValueException();

                    }

                    prim.WFPosition.Add(string.Format(fiscalYear, year), value);
                }
                catch (UnknownRatingValueException unex)
                {
                    string ex1 = unex.ToString();
                }
                catch (EmptyRatingValueException emex)
                {
                    string ex2 = emex.ToString();
                }
                catch (IndexOutOfRangeException index)
                {
                    //column doesn't exist yet (e.g. FY08)
                }
                catch (Exception e)
                {
                    string exp = e.ToString();
                }
            }//position

            #endregion

            #region egrading

            for (int i = 4; i < 12; i++)
            {
                //build the year string
                string year;
                if (i < 10)
                    year = "0" + i.ToString();
                else
                    year = i.ToString();

                try
                {
                    //build column name
                    string eGrading = string.Format(egrade, year);
                    string plValue = (string)reader[eGrading];
                    object value;

                    switch (plValue)
                    {
                        case "E03":
                            value = 1;
                            break;
                        case "E04":
                            value = 2;
                            break;
                        case "E05":
                            value = 3;
                            break;
                        case "E10":
                            value = 4;
                            break;
                        case "E20":
                            value = 5;
                            break;
                        case "E30":
                            value = 6;
                            break;
                        case "E40":
                            value = 7;
                            break;
                        case "E50":
                            value = 8;
                            break;
                        case "E60":
                            value = 9;
                            break;

                        case "":
                            throw new EmptyRatingValueException();

                        default:
                            throw new UnknownRatingValueException();
                    }

                    prim.EGrading.Add(string.Format(fiscalYear, year), value);
                }
                catch (UnknownRatingValueException unex)
                {
                    string ex1 = unex.ToString();
                }
                catch (EmptyRatingValueException emex)
                {
                    string ex2 = emex.ToString();
                }
                catch (IndexOutOfRangeException index)
                {
                    //column doesn't exist yet
                }
                catch (Exception e)
                {
                    string exp = e.ToString();
                }

            }//egrading

            #endregion


            return prim;
        }


        #endregion

    }
}
