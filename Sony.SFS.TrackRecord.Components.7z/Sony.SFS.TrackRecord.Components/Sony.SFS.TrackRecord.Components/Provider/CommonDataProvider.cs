using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Configuration.Provider;
using System.Data;
using Sony.SFS.TrackRecord.Collections;

namespace Sony.SFS.TrackRecord.Components
{
    public abstract class CommonDataProvider : ProviderBase
    {
        public abstract string ApplicationName { get; set; }

        #region CRUD methods
        public abstract void CreateUpdateDeleteAmbitionChoice(AmbitionChoice choice, DataProviderAction dpa);

        public abstract void CreateUpdateDeleteAmbitionType(AmbitionType ambition, DataProviderAction dpa);

        public abstract void CreateUpdateDeleteDepartment(Department department, DataProviderAction dpa);

        public abstract void CreateUpdateDeleteEducationDiscipline(EducationDiscipline dis, DataProviderAction dpa);

        public abstract void CreateUpdateDeleteEducationLevel(EducationLevel level, DataProviderAction dpa);

        public abstract void CreateUpdateDeleteEmployee(Employee employee, DataProviderAction dpa);

        public abstract void CreateUpdateDeletePrimusEmployee(PrimusEmployee employee, DataProviderAction dpa);

        public abstract void FlushPrimusEmployees();

        public abstract void CreateUpdateDeleteEmployeeAmbition(EmployeeAmbition ambition, DataProviderAction dpa);

        public abstract void CreateUpdateDeleteEmployeeEducation(EmployeeEducation edu, DataProviderAction dpa);

        public abstract void CreateUpdateDeleteEmployeeFunction(EmployeeFunction function, DataProviderAction dpa);

        public abstract void CreateUpdateDeleteEmployeeLanguage(EmployeeLanguage language, DataProviderAction dpa);

        public abstract void CreateUpdateDeleteEmployeeSkills(int employeeId, int skillId, SkillLevel level, bool remove);

        public abstract void CreateUpdateDeleteFunction(Function function, DataProviderAction dpa);

        public abstract void CreateUpdateDeleteImage(Image image, DataProviderAction dpa);

        public abstract void CreateUpdateDeleteLanguage(Language lang, DataProviderAction dpa);

        public abstract void CreateUpdateDeleteLicense(License license, DataProviderAction dpa);

        public abstract void CreateUpdateDeleteSkill(Skill skill, DataProviderAction dpa);

        public abstract void CreateUpdateDeleteTraining(Training training, DataProviderAction dpa);

        public abstract void CreateUpdateDeleteWorkStyleRating(WorkstyleRating work, DataProviderAction dpa);

        public abstract void CreateUpdateDeleteSuggestion(Suggestion sugg, DataProviderAction dpa);
        #endregion


        #region Getter methods

        public abstract List<Suggestion> GetSuggestions(int employeeId);
        public abstract List<Suggestion> GetSuggestionsByFunction(int functionId);
        public abstract Suggestion GetSuggestion(int suggestionId);

        public abstract List<AmbitionType> GetAmbitions();
        public abstract AmbitionType GetAmbition(int ambitionId);

        public abstract List<AmbitionChoice> GetAmbitionChoices(int ambitionTypeId);
        public abstract AmbitionChoice GetAmbitionChoice(int Id);

        public abstract List<Department> GetDepartments();
        public abstract Department GetDepartment(int departmentNumber);
        public abstract bool DepartmentExists(int departmentNumber);
        public abstract void FlushDepartments();

        public abstract List<IAutoDropDownItem> GetEducationDisciplines();
        public abstract EducationDiscipline GetEducationDiscipline(int disciplineId);

        public abstract List<IAutoDropDownItem> GetEducationLevels();
        public abstract EducationLevel GetEducationLevel(int levelId);

        public abstract List<EmployeeAmbition> GetEmployeeAmbitions(int employeeId, AmbitionChoiceType type);
        public abstract EmployeeAmbition GetEmployeeAmbition(int ambitionId);

        public abstract ArrayList GetEmployeeEducations(int employeeId);
        public abstract EmployeeEducation GetEmployeeEducation(int eduId);
        public abstract EmployeeEducation GetEmployeeAssessment(int employeeId);

        public abstract EmployeeFunction GetEmployeeFunction(int employeeFunctionId);
        public abstract EmployeeFunction GetCurrentEmployeeFunction(int employeeId);
        public abstract ArrayList GetEmployeeFunctions(int employeeId, bool withCurrent);


        public abstract EmployeeSet GetEmployees(int pageIndex, int pageSize, SortEmployeesBy sortBy, SortOrder sortOrder, bool returnRecordCount);
        public abstract PrimusEmployee GetEmployee(int employeeId);
        public abstract bool EmployeeExists(int employeeNumber);
        public abstract bool EmployeeFunctionChanged(string employeeFunction, int employeeNumber);
        public abstract void GetEmployeesRatings(PrimusEmployee employee);
        public abstract ArrayList GetEmployeesByLastName(string lastName);

        public abstract List<EmployeeSkill> GetEmployeeSkills(int employeeId);
        public abstract EmployeeSkill GetEmployeeSkill(int employeeskillId, int skillId);

        public abstract List<EmployeeLanguage> GetEmployeeLanguages(int employeeId);
        public abstract ArrayList GetLanguagesEmployees(int languageId);
        public abstract EmployeeLanguage GetEmployeeLanguage(int employeeId, int languageId);

        public abstract FunctionSet GetFunctions(int pageIndex, int pageSize, SortFunctionsBy sortBy, SortOrder sortOrder, bool returnRecordCount);
        public abstract Function GetFunction(int functionId);
        public abstract Function GetFunctionByName(string functionName);
        public abstract bool FunctionExists(string function);


        public abstract Image GetImage(int imageId);

        public abstract List<Language> GetLanguages();
        public abstract Language GetLanguage(int languageId);

        public abstract List<License> GetLicenses(int employeeId);
        public abstract List<License> GetLicenses();
        public abstract License GetLicense(int licenseId);

        public abstract List<Skill> GetSkills();
        
        public abstract Skill GetSkill(int skillId);

        public abstract List<Training> GetTrainings();
        public abstract List<Training> GetEmployeeTrainings(int employeeId);

        public abstract Training GetTraining(int trainingId);

        public abstract ArrayList GetWorkstyleRatings(int employeeId);
        public abstract WorkstyleRating GetLatestWorkstyleRating(int employeeId);
        public abstract WorkstyleRating GetWorkStyleRating(int workstyleId);
        public abstract WorkstyleRating GetWorkStyleRating(string fiscalYear,int employeeId);


        public abstract void CreateUpdateDeleteRating(Rating rating, DataProviderAction dpa);
        public abstract List<Rating> GetEmployeesRatings(int employeeId, RatingType type);
        public abstract Rating GetEmployeeRating(int ratingId);
        public abstract Rating GetEmployeeRating(int employeeID, RatingType type, string fiscalYear);




        public abstract void CreateUpdateDeleteRunningJob(RunningJob job, DataProviderAction dpa);
        public abstract RunningJob GetRunningJob(int jobId);
        public abstract ArrayList GetPendingJobs();

        public abstract void CreateUpdateDeleteUploadedFile(UploadedFile file, DataProviderAction dpa);
        public abstract UploadedFile GetUploadedFile(int fileId);
        public abstract ArrayList GetUploadedFiles();


        public abstract void ReportError(int jobId, string error);

        #endregion



        #region population methods

        public Rating PopulateRatingFromIDataReader(IDataReader reader)
        {
            Rating rating = new Rating();

            rating.RatingId = (int)reader["idEmployeeRating"];
            rating.EmployeeId = (int)reader["idEmployee"];
            rating.RateDate = (DateTime)reader["dtRateDate"];
            rating.Year = (string)reader["txtYear"];
            rating.RatingValue = (int)reader["intRating"];
            rating.RatingType = (RatingType)reader["intRatingType"];

            return rating;
        }


        public AmbitionChoice PopulateAmbitionChoiceFromIDataReader(IDataReader reader)
        {
            AmbitionChoice choice = new AmbitionChoice();

            choice.AmbitionChoiceID = (int) reader["idAmbitionChoice"];
            choice.AmbitionTypeID = (int)reader["idAmbitionType"];
            choice.Choice = (string)reader["txtChoice"];

            return choice;
        }

        public AmbitionType PopulateAmbitionTypeFromIDataReader(IDataReader reader)
        {
            AmbitionType type = new AmbitionType();

            type.AmbitionTypeID = (int)reader["idAmbitionType"];
            type.AmbitionTypeText = (string)reader["txtAmbitionType"];
            type.Description = (string)reader["txtDescription"];

            return type;

        }

        public Department PopulateDepartmentTypeFromIDataReader(IDataReader reader)
        {
            Department dep = new Department();

            dep.DepartmentID = (int)reader["idDepartment"];
            dep.Name = (string)reader["txtName"];
            dep.Description = (string)reader["txtDescription"];
            dep.DepartmentNumber = (int) reader["intDepartmentNumber"];

            return dep;
        }

        public EducationDiscipline PopulateEducationDisciplineTypeFromIDataReader(IDataReader reader)
        {
            EducationDiscipline dis = new EducationDiscipline();

            dis.EducationDisciplineID = (int)reader[0];
            dis.Discipline = (string)reader[1];
            dis.Description = (string)reader[2];

            return dis;
        }

        public EducationLevel PopulateEducationLevelFromIDataReader(IDataReader reader)
        {
            EducationLevel level = new EducationLevel();

            level.EducationLevelID = (int) reader[0];
            level.Level = (string) reader[1];
            level.Description = (string) reader[2];

            return level;
        }


        public Suggestion PopulateSuggestionFromIDataReader(IDataReader reader)
        {
            Suggestion sug = new Suggestion();
            sug.SuggestionId = (int)reader["idSuggestion"];
            sug.EmployeeId = (int)reader["idEmployee"];
            sug.FunctionId = (int)reader["idFunction"];
            sug.Term = (int)reader["intTerm"];
            sug.SetDate = (DateTime)reader["dtSetDate"];
            sug.Department = (string)reader["txtName"];

            return sug;
        }



        public EmployeeAmbition PopulateEmployeeAmbitionFromIDataReader(IDataReader reader){
            
            EmployeeAmbition amb = new EmployeeAmbition();

            amb.EmployeeAmbitionID = (int) reader["idEmployeeAmbition"];
            amb.AmbitionChoiceType = (AmbitionChoiceType) reader["intAmbitionType"];
            amb.AmbitionID = (int) reader["idAmbition"];
            amb.ChoiceID = (int) reader["idChoice"];
            amb.EmployeeID = (int) reader["idEmployee"];
            amb.AmbitionText = (string)reader["txtAmbitionText"];

            return amb;
        }

        public EmployeeFunction PopulateEmployeeFunctionFromIDataReader(IDataReader reader)
        {
            EmployeeFunction function = new EmployeeFunction();

            function.EmployeeFunctionID = (int)reader["idEmployeeFunction"];
            function.EmployeeID = (int)reader["idEmployee"];
            function.FunctionID = (int)reader["idFunction"];
            function.DepartmentID = (int)reader["idDepartment"];
            function.StartDate = (DateTime)reader["dtStartDate"];
            function.EndDate = (DateTime)reader["dtEndDate"];
            function.PreferredDuration = (int)reader["intPreferredDuration"];
            function.Current = (bool)reader["bitCurrent"];

            return function;
        }

        public Employee PopulateEmployeeFromIDataReader(IDataReader reader)
        {
            Employee empl = new Employee();

            empl.EmployeeId = (int)reader[0];
            empl.FirstName = (string)reader[1];
            empl.MiddleName = (string)reader[2];
            empl.LastName = (string)reader[3];
            empl.Address1 = (string)reader[4];
            empl.Address2 = (string)reader[5];
            empl.ZipCode = (string)reader[6];
            empl.City = (string)reader[7];
            empl.Gender = (string)reader[8];
            empl.Birthdate = (DateTime)reader[9];
            empl.EmployeeSince = (DateTime)reader[10];
            empl.Ambition = (string)reader[11];
            empl.ImageID = (int)reader[12];

            return empl;
        }

        public PrimusEmployee PopulatePrimusEmployeeFromIReader(IDataReader reader)
        {
            PrimusEmployee emp = new PrimusEmployee();

            emp.PrimusId = (int)reader["idPrimus"];
            emp.EmployeeNumber = (int) reader["intEmployeeNumber"];
            emp.Aanhef = (int) reader["intAanhef"];
            emp.RoepNaam = (string)reader["txtRoepNaam"];
            emp.Naam = (string)reader["txtNaam"];
            emp.StraatNaam = (string)reader["txtStraatnaam"];
            emp.Huisnummer = (int) reader["intHuisnummer"];
            emp.HuisnummerToev = (string)reader["txtHuisnummerToev"];
            emp.Postcode = (string)reader["txtPostcode"];
            emp.Woonplaats = (string)reader["txtWoonplaats"];
            emp.Land = (string)reader["txtLand"];
            emp.GeboorteDatum = (DateTime) reader["dtGeboorteDatum"];
            emp.DatumInDienst = (DateTime) reader["dtDatumInDienst"];
            emp.DatumInDienstSony = (DateTime)reader["dtDatumInDienstSony"];
            emp.Beroep = (string)reader["txtBeroep"];
            emp.AfdelingsNummer = (int) reader["intAfdelingsNummer"];
            emp.BusinessGroep = (string)reader["txtBusinessGroep"];
            emp.FTE = (decimal)reader["decFTE"];
            emp.FunctieOmschrijving = (string)reader["txtFunctieOmschrijving"];
            emp.Nationaliteit = (int)reader["intNationaliteit"];
            emp.VestigingsNummer = (int)reader["intVestiging"];
            emp.Voorvoegsel = (string)reader["txtVoorvoegsel"];
            

            Image img = new Image();
            img.ImageId = (int)reader["idImage"];
            img.Filename = (string)reader["txtFileName"];
            emp.Image = img;

            emp.ImageID = (int)reader["idImage"];
            emp.Remarks = (string)reader["txtRemarks"];

            emp.EmployeeId = (int)reader["idEmployee"];

            return emp;

        }

        public EmployeeLanguage PopulateEmployeeLanguageFromIDataReader(IDataReader reader)
        {
            EmployeeLanguage lang = new EmployeeLanguage();

            lang.EmployeeID = (int)reader[0];
            lang.LanguageID = (int)reader[1];
            lang.Writing = (SkillLevel)reader[2];
            lang.Speaking = (SkillLevel)reader[3];

            return lang;
        }

        public Function PopulateFunctionFromIDataReader(IDataReader reader)
        {
            Function func = new Function();

            func.FunctionID = (int)reader[0];
            func.Title = (string)reader[1];
            func.Description = (string)reader[2];
            func.DesiredDuration = (int)reader[3];
            func.Division = (string)reader[4];
            func.DepartmentID = (int)reader[5];
            func.Location = (string)reader[6];
            func.Manages = (string)reader[7];
            func.Requirements = (string)reader[8];
            func.FunctionGoals = (string)reader[9];
            func.Responsibilities = (string)reader[10];
            func.KeyPerformanceIndicators = (string)reader[11];
            func.Managing = (bool)reader[12];

            return func;
        }

        public Image PopulateImageFromIDataReader(IDataReader reader)
        {
            Image image = new Image();

            image.ImageId = (int)reader[0];
            image.Filename = (string)reader[1];

            return image;
        }

        public Language PopulateLanguageFromIDataReader(IDataReader reader)
        {
            Language lang = new Language();

            
            lang.LanguageId = (int) reader[0];
            lang.Name = (string)reader[1];

            return lang;
        }

        public License PopulateLicenseFromIDataReader(IDataReader reader)
        {
            License lic = new License();

            lic.LicenseId = (int)reader[0];
            lic.LicenseName = (string)reader[1];

            return lic;
        }

        public Skill PopulateSkillFromIDataReader(IDataReader reader)
        {
            Skill skill = new Skill();

            skill.SkillID = (int)reader[0];
            skill.Name = (string)reader[1];
            skill.Desciption = (string)reader[2];

            return skill;
        }

        public Training PopulateTrainingFromIDataReader(IDataReader reader)
        {
            Training train = new Training();

            train.TrainigID = (int)reader["TrainingID"];
            train.TrainingName = (string)reader["Training"];

            return train;
        }

        public WorkstyleRating PopulateWorkstyleRatingFromIDataReader(IDataReader reader)
        {
            WorkstyleRating rate = new WorkstyleRating();

            rate.WorkstyleId = (int)reader[0];
            rate.Year = (string)reader[1];
            rate.Rating = (WorkstyleRatingLevel)reader[2];
            rate.Attachment = (string)reader[3];
            rate.EmployeeID = (int)reader[4];

            return rate;
        }

        public EmployeeEducation PopulateEmployeeEducationFromIDataReader(IDataReader reader)
        {
            EmployeeEducation edu = new EmployeeEducation();

            edu.EmployeeEducationID = (int)reader["idEmployeeEducation"];
            edu.LevelID = (int)reader["idLevel"];
            edu.DisciplineID = (int)reader["idDiscipline"];
            edu.StartDate = (DateTime)reader["dtStartDate"];
            edu.EndDate = (DateTime)reader["dtEndDate"];
            edu.Location = (string)reader["txtLocation"];
            edu.Description = (string)reader["txtDescription"];

            edu.EmployeeID = (int)reader["idEmployee"];
            edu.EducationType = (EducationType)reader["intEducationType"];
            edu.Completed = (bool)reader["bitCompleted"];
            edu.Title = (string)reader["txtTitle"];

            return edu;
        }

        public EmployeeSkill PopulateEmployeeSkillFromIDataReader(IDataReader reader)
        {
            EmployeeSkill skill = new EmployeeSkill();

            skill.EmployeeID = (int)reader[0];
            skill.SkillID = (int)reader[1];
            skill.SkillLevel = (SkillLevel) reader[2];

            return skill;
        }

        public void PopulateEmployeeRatingsFromIDataReader(IDataReader reader, PrimusEmployee employee)
        {
            employee.WorkforcePlayer = (string) reader["WorkforcePlayer"];
            employee.WorkforcePosition = (string)reader["WorkforcePosition"];
            employee.EGrading = (string)reader["EGrading"];
            employee.WorkstyleRating = (string)reader["WorkstyleRating"];

            int phrating = (int)reader["PRatingHR"];
            int pmrating = (int)reader["PRatingMgr"];
            employee.PRatingHR = phrating == 0 ? "-" : phrating.ToString();
            employee.PRatingMgr = pmrating == 0 ? "-" : pmrating.ToString();

        }


        public RunningJob PopulateRunningJobFromIDataReader(IDataReader reader)
        {
            RunningJob job = new RunningJob();

            job.JobID = (int)reader["JobID"];
            job.JobName = (string)reader["JobName"];
            job.TotalRecords = (int)reader["TotalRecords"];
            job.CurrentRecord = (int)reader["CurrentRecord"];
            job.FileID = (int)reader["FileID"];
            job.Complete = (bool)reader["Complete"];
            job.Running = (bool)reader["Running"];
            job.Errors = (int)reader["Errors"];

            return job;
        }

        public UploadedFile PopulateUploadedFileFromIDataReader(IDataReader reader)
        {
            UploadedFile file = new UploadedFile();

            file.FileID = (int)reader["FileID"];
            file.FilePath = (string)reader["FilePath"];
            file.FileName = (string)reader["FileName"];
            file.FileType = (FileType) reader["FileType"];
            file.Delimiter = Convert.ToChar(reader["Delimiter"]);
            file.FileRead = (bool)reader["FileRead"];
            file.Processed = (bool)reader["Processed"];
            file.ImportType = (ImportType)reader["ImportType"];


            return file;
        }



        #endregion 



    }
}
