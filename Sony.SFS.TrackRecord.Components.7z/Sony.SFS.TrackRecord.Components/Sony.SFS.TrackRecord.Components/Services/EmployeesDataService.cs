using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Sony.SFS.TrackRecord.Collections;

namespace Sony.SFS.TrackRecord.Components
{
    public class EmployeesDataService : DataServiceBase
    {
        /*
         * 
         Cache workings.
         * Each control that needs a business object retreives it from the data service. This could seriously affect performance so
         * the objects are stored in the Web.Cache using TRCache. This way an object is fetched once, cache for a couple of minutes.
         * This results in a single retreival of an object from the datastore. Consecutive calls get the object from the cache untill it
         * expires.
         * Once a create, update or delete command is used, all cache keys where this object is in needs to be cleared or non existant or faulty data
         * is presented.
         * 

         * 
         */



        static string EmployeesCacheKey = "Emp::I-{0}";
        static string PrimusEmployeesCacheKey = "PrEmp::pI-{0}";
        static string FullPrimusEmployeesCacheKey = "PrFEmp::pIF-{0}";
        static string EmployeeSetCacheKey = "EmpSet::pi-{0}:ps-{1}:sb-{2}:so{3}";
        static string SuggestionEmployeeCacheKey = "Sugg::ei-{0}";
        static string SuggestionFunctionCacheKey = "SuggF::fi-{0}";
        static string EmployeeFunctionsCacheKey = "EmpFuncs::emp-{0}";
        static string EmployeeFunctionFunctionCacheKey = "EmpFunc::func-{0}";
        static string EmployeeEarlierPos = "EarlierPos::emp-{0}";
        static string AmbitionChoiceCacheKey = "Choice::emp-{0}";

        static string EmployeeFunctionAmbitions = "EmpFuncAmb::emp-{0}";
        static string EmployeeAmbitionTexts = "EmpAmbTex::emp-{0}";
        static string EmployeeAmbition = "EmplAmb::emp-{0}";

        static string EmployeeRating = "EmpRat::emp-{0}";
        static string EmployeeWorkforcePlayer = "EmpWFPl::emp-{0}";
        static string EmployeeWorkforcePosition = "EmpWFPos::emp-{0}";
        static string EmployeeEGrading = "EmpEGr::emp-{0}";
        static string Employeeworkstyle = "EmpwrkSt::emp-{0}";
        static string EmployeeEducations = "EmpEdus::emp-{0}";
        static string EmployeeEducation = "EmpEdu::emp-{0}";
        static string EmployeePHRRating = "EmpPHr::emp-{0}";
        static string EmployeePMgrRating = "EmpPMgr::emp-{0}";



        static int _1min = 60;
        static int _2min = 120;
        static int _3min = 180;
        static int _4min = 240;
        static int _5min = 300;


        #region helpers

        private object RetreiveFromCache(string cacheKey)
        {
            object s = TRCache.Get(cacheKey);
            return s;
        }

        private object RetreiveFromContext(string cacheKey)
        {
            return null;

        }

        private void StoreInCache(int minutes)
        {

        }

        private void StoreInContext()
        {

        }
        #endregion


        public static void AddEmployee(Employee employee)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteEmployee(employee, DataProviderAction.Create);

            TRCache.RemoveByPattern("EmpSet::");
        }

        public static void AddPrimusEmployee(PrimusEmployee employee)
        {
            LoadProviders();

            Provider.CreateUpdateDeletePrimusEmployee(employee, DataProviderAction.Create);

            TRCache.RemoveByPattern("EmpSet::");

        }

        public static void UpdatePrimusEmployee(PrimusEmployee employee)
        {
            LoadProviders();

            Provider.CreateUpdateDeletePrimusEmployee(employee, DataProviderAction.Update);

            TRCache.RemoveByPattern("EmpSet::");

        }

        public static void DeletePrimusEmployee(PrimusEmployee employee)
        {
            LoadProviders();

            Provider.CreateUpdateDeletePrimusEmployee(employee, DataProviderAction.Delete);

            TRCache.RemoveByPattern("EmpSet::");

        }

        public static void FlushPrimusEmployees()
        {
            LoadProviders();

            Provider.FlushPrimusEmployees();

            TRCache.RemoveByPattern("EmpSet::");

        }

        public static void UpdateEmployee(Employee employee)
        {
            LoadProviders();
            Provider.CreateUpdateDeleteEmployee(employee, DataProviderAction.Update);

            TRCache.RemoveByPattern("EmpSet::");

        }

        public static void DeleteEmployee(Employee employee)
        {
            LoadProviders();
            Provider.CreateUpdateDeleteEmployee(employee, DataProviderAction.Delete);

            TRCache.RemoveByPattern("EmpSet::");

        }

        public static EmployeeSet GetEmployees(int pageIndex, int pageSize, SortEmployeesBy sortBy, SortOrder sortOrder)
        {
            LoadProviders();

            string cacheKey = string.Format(EmployeeSetCacheKey, pageIndex, pageSize, sortBy, sortOrder);

            EmployeeSet es = TRCache.Get(cacheKey) as EmployeeSet;

            if (es == null)
            {
                es = Provider.GetEmployees(pageIndex, pageSize, sortBy, sortOrder, true);

                TRCache.Insert(cacheKey, es, 180);
            }

            return es;
           
        }
        public static ArrayList GetEmployeesByLastName(string lastName)
        {
            LoadProviders();

            return Provider.GetEmployeesByLastName(lastName);
        }
        public static bool EmployeeExists(int employeeNumber)
        {
            LoadProviders();

            return Provider.EmployeeExists(employeeNumber);

        }

        public static bool EmployeesFunctionAltered(string functieOmschrijving, int employeeNumber)
        {
            LoadProviders();

            return Provider.EmployeeFunctionChanged(functieOmschrijving, employeeNumber);
        }


        /// <summary>
        /// Gets a Primus employee object
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns></returns>
        public static PrimusEmployee GetEmployee(int employeeId)
        {
            LoadProviders();
			
            //string cacheKey = string.Format(PrimusEmployeesCacheKey, employeeId);

            ////retreives the employee from cache
            PrimusEmployee prim;// = TRCache.Get(cacheKey) as PrimusEmployee;

            ////if not in cache, retreive from database
            //if (prim == null)
            //{
                //get the employee
                prim = Provider.GetEmployee(employeeId);

                //get the image, if any
                if (prim.ImageID > 0)
                    prim.Image = Provider.GetImage(prim.ImageID);

                //gets the employee function
                prim.Function = EmployeesDataService.GetCurrentEmployeeFunction(prim.EmployeeNumber);

                //gets the employee ratings. Works only if the employee has an EmployeeFunction, else the rating properties remain string.Empty
                EmployeesDataService.GetEmployeesRatings(prim);

                //puts the object in cache
               // TRCache.Insert(cacheKey, prim, 180);

           // }

            return prim;
        }

        public static void GetEmployeesRatings(PrimusEmployee employee)
        {
            LoadProviders();

            Provider.GetEmployeesRatings(employee);

        }

        /// <summary>
        /// Gets a full Primus employee from the data store. This PrimusEmployee containts all function, ambittion, etc information
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns></returns>
        public static PrimusEmployee GetFullEmployee(int employeeId)
        {
            LoadProviders();

            //Build the cacheKey
            string cacheKey = string.Format(FullPrimusEmployeesCacheKey, employeeId);

            //Retreive Employee from HttpContext.Items
            PrimusEmployee emp = TRContext.Current.Context.Items[cacheKey] as PrimusEmployee;

            if (emp == null)
            {
                //Retrieve Employee from TRCache.
                emp = TRCache.Get(cacheKey) as PrimusEmployee;


                //Object is not in HttpContext or TRCache, retreive from data store
                if (emp == null)
                {
                    
                    emp = Provider.GetEmployee(employeeId);

                    emp.Image = Provider.GetImage(emp.ImageID);

                    emp.Ambitions = Provider.GetEmployeeAmbitions(employeeId, AmbitionChoiceType.All);
                    emp.Function = Provider.GetCurrentEmployeeFunction(employeeId);
                    emp.Languages = Provider.GetEmployeeLanguages(employeeId);
                    emp.Licenses = Provider.GetLicenses(employeeId);
                    emp.Rating = Provider.GetLatestWorkstyleRating(employeeId);
                    emp.Skills = Provider.GetEmployeeSkills(employeeId);
                    emp.Trainings = Provider.GetEmployeeTrainings(employeeId);

                    //Add object to cache for 5 minutes
                    TRCache.Insert(cacheKey, emp, _5min);
                }

                //Add object to HttpContext.Items
                TRContext.Current.Context.Items[cacheKey] = emp;

            }


            
            return emp;
        }

        public static void UpdateImage(Sony.SFS.TrackRecord.Components.Image image)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteImage(image, DataProviderAction.Update);
        }

        public static void AddSuggestion(Suggestion sugg)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteSuggestion(sugg, DataProviderAction.Create);

            TRCache.RemoveByPattern("Sugg::");
            TRCache.RemoveByPattern("SuggF::");


        }

        public static void UpdateSuggestion(Suggestion sugg)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteSuggestion(sugg, DataProviderAction.Update);

            TRCache.RemoveByPattern("Sugg::");
            TRCache.RemoveByPattern("SuggF::");
        }

        public static void DeleteSuggestion(Suggestion sugg)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteSuggestion(sugg, DataProviderAction.Delete);

            TRCache.RemoveByPattern("Sugg::");
            TRCache.RemoveByPattern("SuggF::");
        }

        public static Suggestion GetSuggestion(int suggestionId)
        {
            LoadProviders();

            Suggestion sugg = Provider.GetSuggestion(suggestionId);

            sugg.Function = Provider.GetFunction(sugg.FunctionId);

            return sugg;
        }

        public static List<Suggestion> GetSuggestions(int employeeId)
        {
            LoadProviders();

            string cacheKey = string.Format(SuggestionEmployeeCacheKey, employeeId);

            List<Suggestion> suggs = TRCache.Get(cacheKey) as List<Suggestion>;

            if (suggs == null)
            {
                suggs = Provider.GetSuggestions(employeeId);

                foreach (Suggestion sug in suggs)
                {
                    //sug.Function = Provider.GetFunction(sug.FunctionId);
                    sug.Function = StemDataService.GetFunction(sug.FunctionId);
                }

                TRCache.Insert(cacheKey, suggs, _3min);
            }
            

            return suggs;
        }

        public static List<Suggestion> GetSuggestionsByFunction(int functionId)
        {
            LoadProviders();

           // string cacheKey = string.Format(SuggestionFunctionCacheKey, functionId);

            List<Suggestion> suggs;// = TRCache.Get(cacheKey) as List<Suggestion>;

            //if (suggs == null)
            //{
                suggs = Provider.GetSuggestionsByFunction(functionId);

                foreach (Suggestion sug in suggs)
                {
                    sug.Function = Provider.GetFunction(sug.FunctionId);
                    sug.Employee = Provider.GetEmployee(sug.EmployeeId);
                }

               // TRCache.Insert(cacheKey, suggs, _3min);
            //}
                
                

            return suggs;
        }


        public static EmployeeFunction GetCurrentEmployeeFunction(int employeeNumber)
        {
            LoadProviders();

            EmployeeFunction efunction = Provider.GetCurrentEmployeeFunction(employeeNumber);

            if (efunction != null)
            {
                efunction.Department = StemDataService.GetDepartment(efunction.DepartmentID);

                efunction.Function = StemDataService.GetFunction(efunction.FunctionID);

            }

            return efunction;

        }

        public static EmployeeFunction GetEmployeeFunction(int employeeFunctionId)
        {
            LoadProviders();

            string cacheKey = string.Format(EmployeeFunctionFunctionCacheKey, employeeFunctionId);

            EmployeeFunction ef = TRCache.Get(cacheKey) as EmployeeFunction;

            if (ef == null)
            {
                ef = Provider.GetEmployeeFunction(employeeFunctionId);

                TRCache.Insert(cacheKey, ef, _3min);
            }

            return ef;
        }

        public static ArrayList GetEmployeeFunctions(int employeeId)
        {
            LoadProviders();

            string cacheKey = string.Format(EmployeeFunctionsCacheKey, employeeId);

            ArrayList al = TRCache.Get(cacheKey) as ArrayList;

            if (al == null)
            {
                al = Provider.GetEmployeeFunctions(employeeId, true);

                TRCache.Insert(cacheKey, al, _3min);
            }

            return al;
        }

        public static ArrayList GetEarlierPositions(int employeeId)
        {
            LoadProviders();

            string cacheKey = string.Format(EmployeeEarlierPos, employeeId);

            ArrayList al = TRCache.Get(cacheKey) as ArrayList;

            if (al == null)
            {
                al = Provider.GetEmployeeFunctions(employeeId, false);

                TRCache.Insert(cacheKey, al, _3min);
            }

            return al;
        }

        public static void CreateEmployeeFunction(EmployeeFunction function)
        {
            
            LoadProviders();

            Provider.CreateUpdateDeleteEmployeeFunction(function, DataProviderAction.Create);
            
            TRCache.RemoveByPattern("EarlierPos::");
            TRCache.RemoveByPattern("EmpFuncs::");
            TRCache.RemoveByPattern("EmpFunc::");
        }

        public static void UpdateEmployeeFunction(EmployeeFunction function)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteEmployeeFunction(function, DataProviderAction.Update);

            TRCache.RemoveByPattern("EarlierPos::");
            TRCache.RemoveByPattern("EmpFuncs::");
            TRCache.RemoveByPattern("EmpFunc::");
        }

        public static void DeleteEmployeeFunction(EmployeeFunction function)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteEmployeeFunction(function, DataProviderAction.Delete);

            TRCache.RemoveByPattern("EarlierPos::");
            TRCache.RemoveByPattern("EmpFuncs::");
            TRCache.RemoveByPattern("EmpFunc::");
        }


        #region employee ambitions

        public static List<EmployeeAmbition> GetEmployeeFunctionAmbitions(int employeeNumber)
        {
            LoadProviders();

            string cacheKey = string.Format(EmployeeFunctionAmbitions, employeeNumber);
            
            List<EmployeeAmbition> ea = TRCache.Get(cacheKey) as List<EmployeeAmbition>;

            if (ea == null)
            {
                ea = Provider.GetEmployeeAmbitions(employeeNumber, AmbitionChoiceType.Function);

                TRCache.Insert(cacheKey, ea, _3min);
            }

            return ea;
        }

        public static List<EmployeeAmbition> GetEmployeeAmbitionChoices(int employeeNumber)
        {
            LoadProviders();

            string cacheKey = string.Format(AmbitionChoiceCacheKey, employeeNumber);

            List<EmployeeAmbition> ambitions = TRCache.Get(cacheKey) as List<EmployeeAmbition>;

            if (ambitions == null)
            {
                ambitions = Provider.GetEmployeeAmbitions(employeeNumber, AmbitionChoiceType.Choice);

                foreach (EmployeeAmbition e in ambitions)
                {
                    e.AmbitionType = StemDataService.GetAmbition(e.AmbitionID);
                    e.AmbitionChoice = StemDataService.GetAmbitionChoice(e.ChoiceID);
                }

                TRCache.Insert(cacheKey, ambitions, _3min);
            }

             

            return ambitions;
        }

        public static List<EmployeeAmbition> GetEmployeeAmbitionTexts(int employeeNumber)
        {
            LoadProviders();

            string cacheKey = string.Format(EmployeeAmbitionTexts, employeeNumber);

            List<EmployeeAmbition> la = TRCache.Get(cacheKey) as List<EmployeeAmbition>;

            if (la == null)
            {
                la = Provider.GetEmployeeAmbitions(employeeNumber, AmbitionChoiceType.Text);

                TRCache.Insert(cacheKey, la, _3min);
            }

            return la;
        }

        public static void CreateEmployeeAmbition(EmployeeAmbition ambition)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteEmployeeAmbition(ambition, DataProviderAction.Create);

            TRCache.RemoveByPattern("Choice::");
            TRCache.RemoveByPattern("EmpFuncAmb::");
            TRCache.RemoveByPattern("EmpAmbTex::");

        }

        public static void UpdateEmployeeAmbition(EmployeeAmbition ambition)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteEmployeeAmbition(ambition, DataProviderAction.Update);

            TRCache.RemoveByPattern("Choice::");
            TRCache.RemoveByPattern("EmpFuncAmb::");
            TRCache.RemoveByPattern("EmpAmbTex::");
            TRCache.RemoveByPattern(string.Format(EmployeeAmbition, ambition.EmployeeID));

        }

        public static void DeleteEmployeeAmbition(EmployeeAmbition ambition)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteEmployeeAmbition(ambition, DataProviderAction.Delete);

            TRCache.RemoveByPattern("Choice::");
            TRCache.RemoveByPattern("EmpFuncAmb::");
            TRCache.RemoveByPattern("EmpAmbTex::");
            TRCache.RemoveByPattern(string.Format(EmployeeAmbition, ambition.EmployeeID));
        }

        public static EmployeeAmbition GetEmployeeAmbition(int ambitionId)
        {
            LoadProviders();

            return Provider.GetEmployeeAmbition(ambitionId);
        }

        #endregion

        #region ratings

        public static void CreateRating(Rating rating)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteRating(rating, DataProviderAction.Create);

            TRCache.RemoveByPattern("EmpRat::");
            TRCache.RemoveByPattern("EmpWFPl::");
            TRCache.RemoveByPattern("EmpWFPos::");
            TRCache.RemoveByPattern("EmpEGr::");
            TRCache.RemoveByPattern("EmpwrkSt::");
            TRCache.RemoveByPattern("EmpPMgr::");
            TRCache.RemoveByPattern("EmpPHr::");


        }

        public static void UpdateRating(Rating rating)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteRating(rating, DataProviderAction.Update);

            TRCache.RemoveByPattern("EmpRat::");
            TRCache.RemoveByPattern("EmpWFPl::");
            TRCache.RemoveByPattern("EmpWFPos::");
            TRCache.RemoveByPattern("EmpEGr::");
            TRCache.RemoveByPattern("EmpwrkSt::");
            TRCache.RemoveByPattern("EmpPMgr::");
            TRCache.RemoveByPattern("EmpPHr::");
        }

        public static void DeletRating(Rating rating)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteRating(rating, DataProviderAction.Delete);

            TRCache.RemoveByPattern("EmpRat::");
            TRCache.RemoveByPattern("EmpWFPl::");
            TRCache.RemoveByPattern("EmpWFPos::");
            TRCache.RemoveByPattern("EmpEGr::");
            TRCache.RemoveByPattern("EmpPMgr::");
            TRCache.RemoveByPattern("EmpPHr::");
        }

        public static Rating GetEmployeeRating(int ratingId)
        {
            LoadProviders();

            string cacheKey = string.Format(EmployeeRating, ratingId);

            Rating r = TRCache.Get(cacheKey) as Rating;

            if (r == null)
            {
                r = Provider.GetEmployeeRating(ratingId);
 
                TRCache.Insert(cacheKey, r, _3min);
            }

            return r;
        }

        public static Rating GetEmployeeRating(int employeeID, RatingType type, string fiscalYear)
        {
            LoadProviders();

            return Provider.GetEmployeeRating(employeeID, type, fiscalYear);

        }

        public static List<Rating> GetWorkforceplayerRatings(int employeeId)
        {
            LoadProviders();

            string cacheKey = string.Format(EmployeeWorkforcePlayer, employeeId);

            List<Rating> lr = TRCache.Get(cacheKey) as List<Rating>;

            if (lr == null)
            {
                lr = Provider.GetEmployeesRatings(employeeId, RatingType.WorkforcePlayer);

                TRCache.Insert(cacheKey,lr,_3min);
            }

            return lr;
        }

        public static List<Rating> GetWorkforcePositionRatings(int employeeId)
        {
            LoadProviders();

            string cacheKey = string.Format(EmployeeWorkforcePosition, employeeId);

            List<Rating> lr = TRCache.Get(cacheKey) as List<Rating>;

            if (lr == null)
            {
                lr = Provider.GetEmployeesRatings(employeeId, RatingType.WorkforcePosition);

                TRCache.Insert(cacheKey, lr, _3min);
            }

            return lr;
            
        }

        public static List<Rating> GetPHrRatings(int employeeId)
        {
            LoadProviders();

            string cacheKey = string.Format(EmployeePHRRating, employeeId);

            List<Rating> lr = TRCache.Get(cacheKey) as List<Rating>;

            if (lr == null)
            {
                lr = Provider.GetEmployeesRatings(employeeId, RatingType.PRatingHr);

                TRCache.Insert(cacheKey, lr, _3min);
            }

            return lr;

        }

        public static List<Rating> GetPMgrRatings(int employeeId)
        {
            LoadProviders();

            string cacheKey = string.Format(EmployeePMgrRating, employeeId);

            List<Rating> lr = TRCache.Get(cacheKey) as List<Rating>;

            if (lr == null)
            {
                lr = Provider.GetEmployeesRatings(employeeId, RatingType.PRatingMgr);

                TRCache.Insert(cacheKey, lr, _3min);
            }

            return lr;

        }

        public static List<Rating> GetEGradings(int employeeId)
        {
            LoadProviders();

            string cacheKey = string.Format(EmployeeEGrading, employeeId);

            List<Rating> lr = TRCache.Get(cacheKey) as List<Rating>;

            if (lr == null)
            {
                lr = Provider.GetEmployeesRatings(employeeId, RatingType.EGrading);

                TRCache.Insert(cacheKey, lr, _3min);
            }

            return lr;
            
        }

        public static void CreateWorkstyleRating(WorkstyleRating rating)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteWorkStyleRating(rating, DataProviderAction.Create);

            TRCache.RemoveByPattern("EmpwrkSt::");
        }

        public static void UpdateWorkstyleRating(WorkstyleRating rating)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteWorkStyleRating(rating, DataProviderAction.Update);
            TRCache.RemoveByPattern("EmpwrkSt::");

        }

        public static void DeleteWorkstyleRating(WorkstyleRating rating)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteWorkStyleRating(rating, DataProviderAction.Delete);

            TRCache.RemoveByPattern("EmpwrkSt::");

        }

        public static ArrayList GetWorkstyleRatings(int employeeNumber)
        {
            LoadProviders();

            string cacheKey = string.Format(Employeeworkstyle, employeeNumber);

            ArrayList al = TRCache.Get(cacheKey) as ArrayList;

            if (al == null)
            {
                al = Provider.GetWorkstyleRatings(employeeNumber);

                TRCache.Insert(cacheKey, al, _3min);
            }

            return al;
        }

        public static WorkstyleRating GetWorkstyleRating(int ratingId)
        {
            LoadProviders();

            return Provider.GetWorkStyleRating(ratingId);
        }

        public static WorkstyleRating GetWorkstyleRating(string fiscalYear, int employeeId)
        {
            LoadProviders();

            return Provider.GetWorkStyleRating(fiscalYear, employeeId);
        }

        #endregion

        #region Education

        public static ArrayList GetEducations(int employeeId)
        {
            LoadProviders();

            string cacheKey = string.Format(EmployeeEducations, employeeId);

            ArrayList edus = TRCache.Get(cacheKey) as ArrayList;

            if (edus == null)
            {
                edus = Provider.GetEmployeeEducations(employeeId);

                foreach (EmployeeEducation e in edus)
                {
                    e.Discipline = StemDataService.GetEducationDiscipline(e.DisciplineID);
                    e.EducationLevel = StemDataService.GetEducationLevel(e.LevelID);

                }

                TRCache.Insert(cacheKey, edus, _3min);
            }

            return edus;
        }

        public static EmployeeEducation GetAssessment(int employeeId)
        {
            LoadProviders();

            EmployeeEducation edus = Provider.GetEmployeeAssessment(employeeId);

            return edus;
        }

        public static EmployeeEducation GetEducation(int educationId)
        {
            LoadProviders();

            string cacheKey = string.Format(EmployeeEducation, educationId);

            EmployeeEducation edu = TRCache.Get(cacheKey) as EmployeeEducation;

            if (edu == null)
            {
                edu = Provider.GetEmployeeEducation(educationId);
                edu.Discipline = StemDataService.GetEducationDiscipline(edu.DisciplineID);
                edu.EducationLevel = StemDataService.GetEducationLevel(edu.LevelID);

                TRCache.Insert(cacheKey, edu, _3min);
            }


            return edu;
        }

        public static void CreateEmployeeEducation(EmployeeEducation edu)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteEmployeeEducation(edu, DataProviderAction.Create);

            TRCache.RemoveByPattern("EmpEdu::");
            TRCache.RemoveByPattern("EmpEdus::");

        }

        public static void UpdateEmployeeEducation(EmployeeEducation edu)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteEmployeeEducation(edu, DataProviderAction.Update);
            TRCache.RemoveByPattern("EmpEdu::");
            TRCache.RemoveByPattern("EmpEdus::");
        }

        public static void DeleteEmployeeEducation(EmployeeEducation edu)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteEmployeeEducation(edu, DataProviderAction.Delete);
            TRCache.RemoveByPattern("EmpEdu::");
            TRCache.RemoveByPattern("EmpEdus::");
        }


        #endregion
    }
}
