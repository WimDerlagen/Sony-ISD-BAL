using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Configuration;
using System.Configuration.Provider;
using Sony.SFS.TrackRecord.Configuration;

namespace Sony.SFS.TrackRecord.Components
{
    public class DataService : DataServiceBase
    {
        public static List<Language> GetLanguages() 
        {
             //Make sure a provider is loaded
             LoadProviders();

             return Provider.GetLanguages();
        }

        public static Language GetLanguage(int languageId)
        {
            //Make sure a provider is loaded
            LoadProviders();

            return Provider.GetLanguage(languageId);
        }

        public static void CreateLanguage(Language lang)
        {
            //Make sure a provider is loaded
            LoadProviders();

            Provider.CreateUpdateDeleteLanguage(lang, DataProviderAction.Create);
        }

        public static void UpdateLanguage(Language lang) {
            //Make sure a provider is loaded
            LoadProviders();

            Provider.CreateUpdateDeleteLanguage(lang, DataProviderAction.Update);

        }
        
        public static void DeleteLanguage(Language lang) {
            //Make sure a provider is loaded
            LoadProviders();

            Provider.CreateUpdateDeleteLanguage(lang, DataProviderAction.Delete);

        }
    }
}
