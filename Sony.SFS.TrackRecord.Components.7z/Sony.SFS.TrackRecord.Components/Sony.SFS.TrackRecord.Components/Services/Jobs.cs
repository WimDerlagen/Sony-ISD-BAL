using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Data.Odbc;
using System.Data;
using System.Data.Common;
using System.Security;
using System.Security.Principal;
using System.Threading;
using System.Web.Security;

namespace Sony.SFS.TrackRecord.Components
{
    public class Jobs : DataServiceBase
    {
        private static RunningJob _job;

        #region running jobs
        public static void CreateJob(RunningJob job)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteRunningJob(job, DataProviderAction.Create);
        }

        public static void UpdateJob(RunningJob job)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteRunningJob(job, DataProviderAction.Update);
        }

        public static void DeleteJob()
        {
            LoadProviders();

            Provider.CreateUpdateDeleteRunningJob(new RunningJob(), DataProviderAction.Delete);
        }

        public static RunningJob GetJob(int jobId)
        {
            LoadProviders();
            
            RunningJob job = Provider.GetRunningJob(jobId);

            return job;
            
        }

        public static ArrayList GetPendingJobs()
        {
            LoadProviders();

            return Provider.GetPendingJobs();

        }
        #endregion

        #region fileUpload

        public static void CreateUploadedFile(UploadedFile file)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteUploadedFile(file, DataProviderAction.Create);
        }

        public static void UpdateUploadedFile(UploadedFile file)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteUploadedFile(file, DataProviderAction.Update);
        }

        public static void DeleteUploadedFile(UploadedFile file)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteUploadedFile(file, DataProviderAction.Delete);
        }

        public static UploadedFile GetUploadedFile(int fileId)
        {
            LoadProviders();

            return Provider.GetUploadedFile(fileId);
        }

        public static ArrayList GetUploadedFiles()
        {
            LoadProviders();

            return Provider.GetUploadedFiles();
        }

        public static void ReportError(int jobId, string error)
        {
            LoadProviders();

            Provider.ReportError(jobId, error);
        }

        #endregion

        #region jobs execution

        public static void ExecuteJob(RunningJob job)
        {
            _job = job;

            ThreadStart entry = new ThreadStart(ExecuteJob);
            Thread thread = new Thread(entry);
            thread.Priority = ThreadPriority.Lowest;
            thread.Start();
            
        }

        public static void ExecuteJob()
        {
            //runs in a seperate threads
            StartJob(_job);

            switch (_job.JobName)
            {
                case "ImportDepartments":
                    ImportService.ImportDepartments(_job);
                    break;
                case "ImportFunctions":
                    ImportService.ImportFunctions(_job);
                    break;
                case "ImportEmployees":
                    ImportService.ImportEmployees(_job);
                    break;
            }

            EndJob(_job);

            //thread ends when method exits
        }


        public static void StartJob(RunningJob job)
        {
            job.Running = true;

            UpdateJob(job);
        }

        public static void EndJob(RunningJob job)
        {
            job.Complete = true;
            job.Running = false;
            Jobs.UpdateJob(job);
        }
        #endregion



    }
}
