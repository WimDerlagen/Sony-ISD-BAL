using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Data.Odbc;
using System.Data;
using System.Data.Common;
using System.Collections;
using System.Security;
using System.Security.Principal;
using System.Threading;
using System.Web.Security;


namespace Sony.SFS.TrackRecord.Components
{
    public class ImportService : ExcelServiceBase
    {
        string employeesPath = "~/Import/Employees";
        string departmentPath = "~/Import/Department";
        string importFilePath = string.Empty;
        
        int runningJobId = 0;
        ImportJob ijob;

        #region later
        public void ImportEmployeeTable(ImportJob job)
        {
            //importFilePath = TRContext.Current.MapPath(Path.Combine(employeesPath, job.FileName));
            //ijob = job;


            //ThreadStart entry = new ThreadStart(ImportEmployeeTableInSeperateThread);
            //Thread thread = new Thread(entry);
            //thread.Priority = ThreadPriority.Lowest;
            //thread.Start();

            //ImportEmployeeTableInSeperateThread(job, importFilePath);
        }

        public void ImportEmployeeTableInSeperateThread()
        {
            //RolePrincipal wp = (RolePrincipal)Thread.CurrentPrincipal;
            //WindowsIdentity wi = (WindowsIdentity)wp.Identity;
            //WindowsImpersonationContext wc = wi.Impersonate();
            

            //System.IO.DirectoryInfo di = new DirectoryInfo(TRContext.Current.MapPath(employeesPath));
            //System.IO.FileInfo[] files = di.GetFiles();

            //foreach (FileInfo fi in files)
            //{
            //    fi.Delete();
            //}

            //ImportJob job = ijob;

            //job.PostedFile.SaveAs(importFilePath);

            ////wc.Undo();


            //ArrayList items = new ArrayList();

            //if (job.ImportType == ImportType.Excel)
            //    items = ImportExcelDocument();

            //RunningJob rjob = new RunningJob();
            //rjob.JobName = "ImportPrimusEmployees";
            //rjob.TotalRecords = items.Count;
            //Jobs.DeleteJob();
            //Jobs.CreateJob(rjob);

            //EmployeesDataService.FlushPrimusEmployees();

            //foreach (PrimusEmployee p in items)
            //{
            //    EmployeesDataService.AddPrimusEmployee(p);
            //    Jobs.UpdateJob(rjob);
            //}

            //public ArrayList GetRunningJobs(UploadedFile file)
            //{
            //    //assume an excel file
            //    ArrayList jobs = new ArrayList();

            //    RunningJob departments = new RunningJob();
            //    departments.JobName = "ImportDepartments";
            //    departments.TotalRecords = GetDepartmentCount(file.FilePath);

            //    jobs.Add(departments);


            //    return jobs;
            //}
        }
        #endregion

       

        public static void ImportDepartments(RunningJob job)
        {
            LoadProviders();

            bool abort = false;

            string doubleNumberError = "Afdelingnummer {0} - {1} komt al voor als {2} - {3}.";
            string noNumber = "De afdeling {0} staat vermeld zonder nummer";

            UploadedFile file = Jobs.GetUploadedFile(job.FileID);

            ArrayList al = Provider.GetDepartments(file.FilePath);
            Hashtable ht = new Hashtable();

            //StemDataService.FlushDepartments();

            foreach (Department de in al)
            {
                if (!abort)
                {
                    Department dept;

                    if (de.DepartmentNumber != 0)
                    {
                        if (StemDataService.DepartmentExists(de.DepartmentNumber))
                        {
                            try
                            {
                                //add the department for error checking
                                ht.Add(de.DepartmentNumber, de.Name);

                                //no errors? update the department
                                dept = StemDataService.GetDepartment(de.DepartmentNumber);
                                dept.Description = string.Empty;
                                dept.ManagedByFunction = 0;
                                dept.Name = de.Name;

                                StemDataService.UpdateDepartment(dept);
                            }
                            catch (ArgumentException argEx)
                            {
                                //dubbele vermelding van afdelings nummer
                                string otherName = (string)ht[de.DepartmentNumber];
                                string error = string.Format(doubleNumberError, de.DepartmentNumber, de.Name, de.DepartmentNumber, otherName);

                                Jobs.ReportError(job.JobID, error);
                                job.Errors++;
                            }
                            catch (Exception e)
                            {
                                string p = "s";
                                job.Errors++;
                            }
                        }
                        else
                        {
                            dept = new Department();
                            dept.DepartmentNumber = de.DepartmentNumber;
                            dept.Description = string.Empty;
                            dept.ManagedByFunction = 0;
                            dept.Name = de.Name;
                            StemDataService.CreateDepartment(dept);
                        }
                    }
                    else
                    {
                        string error = string.Format(noNumber, de.Name);

                        Jobs.ReportError(job.JobID, error);
                        job.Errors++;
                    }

                    job.CurrentRecord++;
                    Jobs.UpdateJob(job);

                }
                else
                {
                    break;
                }

               
            }

            job.Complete = true;
            Jobs.UpdateJob(job);
        }

        public static void ImportFunctions(RunningJob job)
        {
            LoadProviders();

            bool abort = false;

            string functionError = "Er is een fout opgetreden met het importeren van de functie {0}.";

            UploadedFile file = Jobs.GetUploadedFile(job.FileID);

            ArrayList functions = Provider.GetFunctions(file.FilePath);
            Hashtable ht = new Hashtable();

            foreach (string s in functions)
            {

                if (!abort)
                {
                    try
                    {
                        if (s != string.Empty && !StemDataService.FunctionExists(s))
                        {
                            Function func = new Function();
                            func.Title = s;

                            StemDataService.CreateFunction(func);
                        }
                    }
                    catch
                    {
                        string error = string.Format(functionError, s);
                        Jobs.ReportError(job.JobID, error);

                        job.Errors++;
                    }
                }

                job.CurrentRecord++;
                Jobs.UpdateJob(job);
            }

        }

        public static void ImportEmployees(RunningJob job)
        {
            LoadProviders();

            bool abort = false;

            string employeeError = "";
            UploadedFile file = Jobs.GetUploadedFile(job.FileID);

            ArrayList employees = Provider.GetEmployees(file.FilePath, job);

            foreach (PrimusEmployee2 prim in employees)
            {
                try
                {
                    //create/update employee
                    PrimusEmployee employee;

                    if (EmployeesDataService.EmployeeExists(prim.EmployeeNummer))
                        UpdatePrimusEmployee(prim, out employee);
                    else
                        InsertPrimusEmployee(prim, out employee);

                    prim.EmployeeID = employee.EmployeeId;

                    //create/update employee function
                    bool functionChanged = false;
                    functionChanged = EmployeesDataService.EmployeesFunctionAltered(prim.FunctieOmschrijving, prim.EmployeeNummer);

                    if (prim.FunctieOmschrijving == string.Empty)
                        throw new EmployeeHasNoFunctionException();

                    if (functionChanged)
                        CreateNewEmployeeFunction(prim, employee);


                    //create/update ratings
                    CreateUpdateWorkstyleRatings(prim);

                    CreateUpdateWorkforcePlayerRating(prim);

                    CreateUpdateWorkforcePositionRating(prim);

                    CreateUpdateEGrading(prim);
                    //workstyle
                    //player
                    //position
                    //egrading
                }
                catch (EmployeeHasNoFunctionException excc)
                {
                    string p = "P";
                    job.Errors++;
                    Jobs.UpdateJob(job);

                    Jobs.ReportError(job.JobID, string.Format("Employee {0}, {1} has no function", prim.EmployeeNummer, prim.EmployeeNaam));
                }
                catch (Exception e)
                {
                    string ex = e.ToString();
                    job.Errors++;
                }

                job.CurrentRecord++;
                Jobs.UpdateJob(job);



            }
        }

        #region importEmployee helpers

        private static void CreateUpdateWorkstyleRatings(PrimusEmployee2 prim)
        {
            WorkstyleRating rating = null;

            foreach (DictionaryEntry de in prim.WSRatings)
            {
                rating = EmployeesDataService.GetWorkstyleRating((string)de.Key, prim.EmployeeNummer);

                if (rating == null)
                {
                    rating = new WorkstyleRating();
                    rating.EmployeeID = prim.EmployeeNummer;
                    rating.Rating = (WorkstyleRatingLevel)de.Value;
                    rating.Year = (string)de.Key;

                    EmployeesDataService.CreateWorkstyleRating(rating);
                }
                else if (rating.Rating != (WorkstyleRatingLevel)de.Value)
                {
                    rating.Rating = (WorkstyleRatingLevel)de.Value;
                    EmployeesDataService.UpdateWorkstyleRating(rating);
                }

            }
        }

        private static void CreateUpdateWorkforcePlayerRating(PrimusEmployee2 prim)
        {
            Rating rating = null;

            foreach (DictionaryEntry de in prim.WFPlayer)
            {
                rating = EmployeesDataService.GetEmployeeRating(prim.EmployeeNummer, RatingType.WorkforcePlayer, (string)de.Key);

                if (rating == null)
                {
                    rating = new Rating();
                    rating.EmployeeId = prim.EmployeeNummer;
                    rating.RateDate = DateTime.Now;
                    rating.RatingType = RatingType.WorkforcePlayer;
                    rating.RatingValue = (int)de.Value;
                    rating.Year = (string)de.Key;

                    EmployeesDataService.CreateRating(rating);
                }
                else if (rating.RatingValue != (int) de.Value)
                {
                    rating.RatingValue = (int)de.Value;

                    EmployeesDataService.UpdateRating(rating);

                }
            }
        }

        private static void CreateUpdateWorkforcePositionRating(PrimusEmployee2 prim)
        {
            Rating rating = null;

            foreach (DictionaryEntry de in prim.WFPosition)
            {
                rating = EmployeesDataService.GetEmployeeRating(prim.EmployeeNummer, RatingType.WorkforcePosition, (string)de.Key);

                if (rating == null)
                {
                    rating = new Rating();
                    rating.EmployeeId = prim.EmployeeNummer;
                    rating.RateDate = DateTime.Now;
                    rating.RatingType = RatingType.WorkforcePosition;
                    rating.RatingValue = (int)de.Value;
                    rating.Year = (string)de.Key;

                    EmployeesDataService.CreateRating(rating);
                }
                else if (rating.RatingValue != (int)de.Value)
                {
                    rating.RatingValue = (int)de.Value;

                    EmployeesDataService.UpdateRating(rating);

                }
            }
        }

        private static void CreateUpdateEGrading(PrimusEmployee2 prim)
        {
            Rating rating = null;

            foreach (DictionaryEntry de in prim.EGrading)
            {
                rating = EmployeesDataService.GetEmployeeRating(prim.EmployeeNummer, RatingType.EGrading, (string)de.Key);

                if (rating == null)
                {
                    rating = new Rating();
                    rating.EmployeeId = prim.EmployeeNummer;
                    rating.RateDate = DateTime.Now;
                    rating.RatingType = RatingType.EGrading;
                    rating.RatingValue = (int)de.Value;
                    rating.Year = (string)de.Key;

                    EmployeesDataService.CreateRating(rating);
                }
                else if (rating.RatingValue != (int)de.Value)
                {
                    rating.RatingValue = (int)de.Value;

                    EmployeesDataService.UpdateRating(rating);

                }
            }
        }

        private static void CreateNewEmployeeFunction(PrimusEmployee2 prim, PrimusEmployee employee)
        {
            EmployeeFunction function = EmployeesDataService.GetCurrentEmployeeFunction(prim.EmployeeNummer);
            EmployeeFunction newFunction;
            Function func;

            if (function == null)
            {
                //employee gets his first function

                newFunction = new EmployeeFunction();

                newFunction.Current = true;
                newFunction.DepartmentID = prim.AfdelingsNummer;

                func = StemDataService.GetFunction(prim.FunctieOmschrijving);
                newFunction.FunctionID = func.FunctionID;
                newFunction.StartDate = DateTime.Now;
                newFunction.EmployeeID = employee.EmployeeId;

                EmployeesDataService.CreateEmployeeFunction(newFunction);


            }
            else
            {
                newFunction = (EmployeeFunction)function.Clone();

                function.EndDate = DateTime.Now;
                function.Current = false;
                EmployeesDataService.UpdateEmployeeFunction(function);

                newFunction.Current = true;
                newFunction.DepartmentID = prim.AfdelingsNummer;

                func = StemDataService.GetFunction(prim.FunctieOmschrijving);
                newFunction.FunctionID = func.FunctionID;
                newFunction.StartDate = DateTime.Now;

                EmployeesDataService.CreateEmployeeFunction(newFunction);
            }
            
            
        }

        private static void InsertPrimusEmployee(PrimusEmployee2 prim, out PrimusEmployee employee)
        {
            employee = new PrimusEmployee(prim);

            EmployeesDataService.AddPrimusEmployee(employee);

        }

        private static void UpdatePrimusEmployee(PrimusEmployee2 prim, out PrimusEmployee employee)
        {
            employee = EmployeesDataService.GetEmployee(prim.EmployeeNummer);
            
            employee.UpdateValuesForImport(prim);

            EmployeesDataService.UpdatePrimusEmployee(employee);
        }

        #endregion

        private static int GetFunctionCount(string filePath)
        {
            LoadProviders();

            return Provider.GetFunctionCount(filePath);
        }

        private static int GetDepartmentCount(string filePath)
        {
            LoadProviders();

            return Provider.GetDepartmentCount(filePath);
        }

        public static int GetEmployeeCount(string filePath)
        {
            LoadProviders();

            return Provider.GetEmployeeCount(filePath);
        }

       
        

        #region running jobs
        public static void CreateRunningJobs(UploadedFile file)
        {
            //create running job objects
            RunningJob departments = new RunningJob();
            departments.JobName = "ImportDepartments";
            departments.TotalRecords = GetDepartmentCount(file.FilePath);
            departments.FileID = file.FileID;

            RunningJob functions = new RunningJob();
            functions.JobName = "ImportFunctions";
            functions.TotalRecords = GetFunctionCount(file.FilePath);
            functions.FileID = file.FileID;

            RunningJob employees = new RunningJob();
            employees.JobName = "ImportEmployees";
            int employeeCount = GetEmployeeCount(file.FilePath);
            employees.TotalRecords = employeeCount * 2;
            employees.FileID = file.FileID;


            //Add jobs to store
            Jobs.CreateJob(departments);
            Jobs.CreateJob(functions);
            Jobs.CreateJob(employees);
        }


        #endregion

        #region old excel
        //private ArrayList ImportExcelDocument() 
        //{
        //    bool done = false;
        //    string conn = string.Format(connectionString, importFilePath);

        //    DbProviderFactory factory = DbProviderFactories.GetFactory("System.Data.OleDb");
        //    ArrayList items = new ArrayList();

        //    using (DbConnection connection = factory.CreateConnection())
        //    {
        //        connection.ConnectionString = conn;

        //        using (DbCommand command = connection.CreateCommand())
        //        {
        //            // Televisie$ comes from the name of the worksheet
        //           // command.CommandText = "SELECT [Employeenr.],[Aanhef],[Naam Employee],[Straatnaam],[Huisnummer],[Toevoeging huisnr.],[Postcode],[Woonplaats],[Woonland Woonadres],[Geboortedatum],[Datum in dienst],[Beroep],[Afdelingsnummer],[Business groep],[FTE],[Functie Omschrijving],[In dienst Sony Corp],[Lang Nationaliteit],[Roepnaam] FROM [Televisie$]";
        //            command.CommandText = "SELECT * FROM [Primusblad$]";

        //            connection.Open();

        //            using (DbDataReader dr = command.ExecuteReader())
        //            {
                       
        //                while (dr.Read())
        //                {
        //                    PrimusEmployee prim = PopulatePrimusEmployeeFromDbReader(dr, out done);

        //                    if (!done)
        //                        items.Add(prim);
        //                    else
        //                        break;
        //                }
        //            }
        //        }
        //    }

        //    return items;
        //}

        //private ArrayList ImportExcelDocumentTest()
        //{
        //    ArrayList items = new ArrayList();

        //    using (DbConnection connection = GetConnection())
        //    {
        //        using (DbCommand command = connection.CreateCommand())
        //        {
        //            // Televisie$ comes from the name of the worksheet
        //            command.CommandText = "SELECT ID,Street, Value FROM [Sheet1$]";

        //            connection.Open();

        //            using (DbDataReader dr = command.ExecuteReader())
        //            {
                        
        //                while (dr.Read())
        //                {
        //                    items.Add(PopulatetestFromDbReader(dr));
        //                }
        //            }
        //        }
        //    }

        //    return items;
        //}

        //private void ImportCSVDocument() { }

        #endregion
    }
}
