using System;
using System.Collections.Generic;
using System.Text;
using Sony.SFS.TrackRecord.Collections;

namespace Sony.SFS.TrackRecord.Components
{
    public class StemDataService : DataServiceBase
    {

        #region Education level
        public static void CreateEducationLevel(EducationLevel level)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteEducationLevel(level, DataProviderAction.Create);

            TRCache.RemoveByPattern("EduLevel::");
        }

        public static void UpdateEducationLevel(EducationLevel level)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteEducationLevel(level, DataProviderAction.Update);
            TRCache.RemoveByPattern("EduLevel::");

        }

        public static void DeleteEducationLevel(EducationLevel level)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteEducationLevel(level, DataProviderAction.Delete);
            TRCache.RemoveByPattern("EduLevel::");

        }

        public static List<IAutoDropDownItem> GetEducationLevels() 
        {
            LoadProviders();

            return Provider.GetEducationLevels();
        }

        public static EducationLevel GetEducationLevel(int levelId) 
        {
            LoadProviders();

            string key = "EduLevel-I:{0}";
            string cacheKey = string.Format(key, levelId);

            EducationLevel level = TRCache.Get(cacheKey) as EducationLevel;

            if (level == null)
            {
                level = Provider.GetEducationLevel(levelId);

                TRCache.Insert(cacheKey, level);
            }

            return level;
        }

        #endregion

        #region educatio discipline
        public static void CreateEducationDiscipline(EducationDiscipline dis)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteEducationDiscipline(dis, DataProviderAction.Create);

        }

        public static void UpdateEducationDiscipline(EducationDiscipline dis)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteEducationDiscipline(dis, DataProviderAction.Update);

            TRCache.RemoveByPattern(string.Format("StemEduDisc::i-{0}", dis.EducationDisciplineID));

        }

        public static void DeleteEducationDiscipline(EducationDiscipline dis)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteEducationDiscipline(dis, DataProviderAction.Delete);
            TRCache.RemoveByPattern(string.Format("StemEduDisc::i-{0}", dis.EducationDisciplineID));

        }

        public static List<IAutoDropDownItem> GetEducationDisciplines() 
        {
            LoadProviders();

            return Provider.GetEducationDisciplines();        
        }

        public static EducationDiscipline GetEducationDiscipline(int disciplineId) 
        {
            LoadProviders();

            string key = "StemEduDisc::i-{0}";
            string cacheKey = string.Format(key, disciplineId);

            EducationDiscipline edud = TRCache.Get(cacheKey) as EducationDiscipline;

            if (edud == null)
            {
                edud = Provider.GetEducationDiscipline(disciplineId);

                TRCache.Insert(cacheKey, edud, 300);
            }

            return edud;
        }

        #endregion

        #region functions

        public static void CreateFunction(Function function) 
        {
            LoadProviders();

            Provider.CreateUpdateDeleteFunction(function, DataProviderAction.Create);

            TRCache.RemoveByPattern("StemFunctions::");
        }

        public static void UpdateFunction(Function function) 
        {
            LoadProviders();

            Provider.CreateUpdateDeleteFunction(function, DataProviderAction.Update);
            TRCache.RemoveByPattern("StemFunctions::");
            TRCache.RemoveByPattern("StemFunction::");

            

        }

        public static void DeleteFunction(Function function) 
        {
            LoadProviders();

            Provider.CreateUpdateDeleteFunction(function, DataProviderAction.Delete);
            TRCache.RemoveByPattern("StemFunctions::");
            TRCache.RemoveByPattern("StemFunction::");
        }

        public static FunctionSet GetFunctions()
        {
            return GetFunctions(0, 200, SortFunctionsBy.Title, SortOrder.Ascending);
        }

        public static FunctionSet GetFunctions(int pageIndex, int pageSize, SortFunctionsBy sortBy, SortOrder sortOrder) 
        {
            LoadProviders();

            //string key = "StemFunctions::pi-{0}:ps-{1}:sb-{2}:so{3}";
            //string cacheKey = string.Format(key, pageIndex, pageSize, sortBy, sortOrder);

            //FunctionSet sets = TRCache.Get(cacheKey) as FunctionSet;

            //if (sets == null)
            //{

              FunctionSet  sets = Provider.GetFunctions(pageIndex, pageSize, sortBy, sortOrder, true);

                foreach (Function func in sets.Items)
                {
                    if (func.DepartmentID > 0)
                        func.Department = StemDataService.GetDepartment(func.DepartmentID);
                            
                }

              //  TRCache.Insert(cacheKey, sets, 600);

            //}

            return sets;
        }

        public static Function GetFunction(int functionId) 
        {
            if (functionId == 0)
                return null;

            LoadProviders();

            string key = "StemFunction::fid-{0})";
            string cacheKey = string.Format(key, functionId);

            Function func = TRCache.Get(cacheKey) as Function;

            
            if (func == null)
            {
                func = Provider.GetFunction(functionId);
            
                if (func.DepartmentID > 0)
                    func.Department = StemDataService.GetDepartment(func.DepartmentID);


                TRCache.Insert(cacheKey, func, 300);

            }

            

            return func;
        }

        public static Function GetFunction(string name)
        {
            LoadProviders();

            Function func = Provider.GetFunctionByName(name);

            return func;
        }

        public static bool FunctionExists(string function)
        {
            if (function == null || function == string.Empty)
                return true;

            LoadProviders();

            return Provider.FunctionExists(function);
            
        }

        #endregion

        #region departments

        public static void CreateDepartment(Department dep) 
        {
            LoadProviders();

            Provider.CreateUpdateDeleteDepartment(dep, DataProviderAction.Create);

            TRCache.RemoveByPattern("StemDepartment::");
        }

        public static void UpdateDepartment(Department dep) {
            LoadProviders();

            Provider.CreateUpdateDeleteDepartment(dep, DataProviderAction.Update);
            TRCache.RemoveByPattern("StemDepartment::");

        }

        public static void DeleteDepartment(Department dep) {
            LoadProviders();

            Provider.CreateUpdateDeleteDepartment(dep, DataProviderAction.Delete);
            TRCache.RemoveByPattern("StemDepartment::");

        }

        public static void FlushDepartments()
        {
            LoadProviders();

            Provider.FlushDepartments();
        }

        public static bool DepartmentExists(int departmentNumber)
        {
            LoadProviders();

            return Provider.DepartmentExists(departmentNumber);
        }

        public static List<Department> GetDepartments() 
        {
            LoadProviders();

            return Provider.GetDepartments();
        }

        public static Department GetDepartment(int departmentNumber) 
        {
            LoadProviders();

            string key = "StemDepartment::i-{0}";
            string cacheKey = string.Format(key, departmentNumber);

            Department dept = TRCache.Get(cacheKey) as Department;

            if (dept == null)
            {
                dept = Provider.GetDepartment(departmentNumber);

                TRCache.Insert(cacheKey, dept);
            }
            

           // if (dept.ManagedByFunction > 0)
            //    dept.ManagingFunction = Provider.GetFunction(dept.ManagedByFunction);

            return dept;
        }



        #endregion


        #region trainings

        public static void CreateTraining(Training train) 
        {
            LoadProviders();

            Provider.CreateUpdateDeleteTraining(train, DataProviderAction.Create);
        }

        public static void UpdateTraining(Training train)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteTraining(train, DataProviderAction.Update);
        }

        public static void DeleteTraining(Training train)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteTraining(train, DataProviderAction.Delete);
        }

        public static List<Training> GetTrainings() {
            LoadProviders();

            return Provider.GetTrainings();
        }

        public static Training GetTraining(int trainingId) 
        {
            LoadProviders();

            return Provider.GetTraining(trainingId);
        }

        #endregion

        #region licenses

        public static void CreateLicense(License lic) {
            LoadProviders();

            Provider.CreateUpdateDeleteLicense(lic, DataProviderAction.Create);
        }

        public static void UpdateLicense(License lic)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteLicense(lic, DataProviderAction.Update);
        }

        public static void DeleteLicense(License lic)
        {
            LoadProviders();

            Provider.CreateUpdateDeleteLicense(lic, DataProviderAction.Delete);
        }

        public static List<License> GetLicenses() {
            LoadProviders();

            return Provider.GetLicenses();
        }

        public static License GetLicense(int id)
        {
            LoadProviders();

            return Provider.GetLicense(id);
        }

        #endregion

        #region ambitions

        public static void CreateAmbition(AmbitionType ambition) {
            LoadProviders();

            Provider.CreateUpdateDeleteAmbitionType(ambition, DataProviderAction.Create);
        }

        public static void UpdateAmbition(AmbitionType ambition) {
            LoadProviders();

            Provider.CreateUpdateDeleteAmbitionType(ambition, DataProviderAction.Update);
        }

        public static void DeleteAmbition(AmbitionType ambition) {
            LoadProviders();

            Provider.CreateUpdateDeleteAmbitionType(ambition, DataProviderAction.Delete);
        }

        public static List<AmbitionType> GetAmbitions() 
        {
            LoadProviders();

            return Provider.GetAmbitions();    
        }

        public static AmbitionType GetAmbition(int id) {
            LoadProviders();

            return Provider.GetAmbition(id);
        }


        public static void CreateAmbitionChoice(AmbitionChoice choice) {
            LoadProviders();

            Provider.CreateUpdateDeleteAmbitionChoice(choice, DataProviderAction.Create);
        }

        public static void UpdateAmbitionChoice(AmbitionChoice choice) {
            LoadProviders();

            Provider.CreateUpdateDeleteAmbitionChoice(choice, DataProviderAction.Update );
        }

        public static void DeleteAmbitionChoice(AmbitionChoice choice) {
            LoadProviders();

            Provider.CreateUpdateDeleteAmbitionChoice(choice, DataProviderAction.Delete);
        }

        public static List<AmbitionChoice> GetAmbitionChoices(int ambitionTypeId) {
            LoadProviders();

            return Provider.GetAmbitionChoices(ambitionTypeId);
        }

        public static AmbitionChoice GetAmbitionChoice(int id) {
            LoadProviders();

            return Provider.GetAmbitionChoice(id);
        }


        #endregion


        #region languages

        public static void CreateLanguage(Language lang){
            LoadProviders();

            Provider.CreateUpdateDeleteLanguage(lang, DataProviderAction.Create);
        }
        public static void UpdateLanguage(Language lang){
            LoadProviders();

            Provider.CreateUpdateDeleteLanguage(lang, DataProviderAction.Update);
        }
        public static void DeleteLanguage(Language lang) {
            LoadProviders();

            Provider.CreateUpdateDeleteLanguage(lang, DataProviderAction.Delete);
        }

        public static List<Language> GetLanguages() 
        {
            LoadProviders();

            return Provider.GetLanguages();
        }
        public static Language GetLanguage(int id) {
            LoadProviders();

            return Provider.GetLanguage(id);
        }

        #endregion

        #region skills

        public static void CreateSkill(Skill skill) {
            LoadProviders();

            Provider.CreateUpdateDeleteSkill(skill, DataProviderAction.Create);
        }
        public static void UpdateSkill(Skill skill) {
            LoadProviders();

            Provider.CreateUpdateDeleteSkill(skill, DataProviderAction.Update);
        }
        public static void DeleteSkill(Skill skill) {
            LoadProviders();

            Provider.CreateUpdateDeleteSkill(skill, DataProviderAction.Delete);
        }

        public static List<Skill> GetSkills() {
            LoadProviders();

            return Provider.GetSkills();
        }
        public static Skill GetSkill(int id) {
            LoadProviders();

            return Provider.GetSkill(id);
        }

        #endregion

    }
}
