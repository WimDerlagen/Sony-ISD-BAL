using System;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Profile;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Security;
using System.Security.Principal;
using System.DirectoryServices;
using System.Threading;


namespace Sony.SFS.TrackRecord.Components
{
    /// <summary>
    /// The HttpModule binds to the HttpApplication and registers to its AuthenticateRequest and Authorize request.
    /// As the HttpApplication is a TRApplication, the HttpModule also registers to PostEmployeeFunctionChanged.
    /// </summary>
    public class TRHttpModule : IHttpModule 
    {
        public TRHttpModule(){}

        public void Dispose() { }

        public void Init(System.Web.HttpApplication Appl)
        {
            TRApplication application = Appl as TRApplication;

            if (application != null)
            {
                application.PostEmployeeFunctionChanged += new TRApplication.FunctionChangedEventHandler(application_PostEmployeeFunctionChanged);
            }
            
            

            Appl.BeginRequest += new EventHandler(Appl_BeginRequest);
            Appl.AuthorizeRequest += new EventHandler(Appl_AuthorizeRequest);
            Appl.AuthenticateRequest += new EventHandler(Appl_AuthenticateRequest);
            Appl.Error += new EventHandler(Appl_Error);
        }

        /// <summary>
        /// Fired wheneven an employee is assigned another function. When this happen the roles set to this user might void, or other
        /// roles need to be assigned. 
        /// For now, automatic role assignment is turned of.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        [Obsolete]
        void application_PostEmployeeFunctionChanged(object sender, FunctionChangedEventArgs e)
        {
            
            //MembershipUser user = Membership.GetUser(e.UserName);
            //string[] roles = Roles.GetRolesForUser(user.UserName);

            //CheckEmployeeStatus(user, roles);
        }

        void Appl_Error(object sender, EventArgs e){}

        /// <summary>
        /// Fired when a user is authenticated. For each user that is authenticated a MembershipUser is created. To this user the Everyone
        /// role is assigned giving the user the least possible access rights.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Appl_AuthenticateRequest(object sender, EventArgs e)
        {
            HttpContext context = HttpContext.Current;
            IPrincipal user1 = context.User;

            MembershipUser user = Membership.GetUser(user1.Identity.Name);

            if (user == null)
            {
                
                MembershipUser mmuser = Membership.CreateUser(user1.Identity.Name, "1");

            }

            if (!Roles.IsUserInRole("Everyone"))
                Roles.AddUserToRole(user1.Identity.Name, "Everyone");
        }

        /// <summary>
        /// To authorize a user a number of steps must be completed.
        /// First a users NTLM name must be mapped to a primus employee, if applicable.
        /// Then, the users function should be checked to determin the users authorization level.
        /// If any of the steps fail, the user remains in the Everyone role, with the least privileges.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Appl_AuthorizeRequest(object sender, EventArgs e)
        {
            //get reference to user
            HttpContext context = HttpContext.Current;
            IPrincipal user = context.User;
            MembershipUser muser = Membership.GetUser(user.Identity.Name);

            string[] roles = Roles.GetRolesForUser(user.Identity.Name);

            switch (roles.Length)
            {
                case 0:
                    //something went wrong on authentication, everyone is Everyone
                    break;
                case 1:
                    CheckEmployeeStatus(muser, roles);
                    break;
                default:
                    //do nothing
                    break;
            }

            if (user.Identity.Name == "EU\\NLHarinM")
                if (!Roles.IsUserInRole(user.Identity.Name, "Administrators"))
                    Roles.AddUserToRole(user.Identity.Name, "Administrators");

            if (user.Identity.Name == "EU\\NLHarinM")
                if (!Roles.IsUserInRole(user.Identity.Name, "HRManagers"))
                    Roles.AddUserToRole(user.Identity.Name, "HRManagers");

            

            if (user.Identity.Name == "EU\\NLVerhaM")
                if (!Roles.IsUserInRole(user.Identity.Name, "Administrators"))
                    Roles.AddUserToRole(user.Identity.Name, "Administrators");

        }

       


        void Appl_BeginRequest(object sender, EventArgs e){}

        /// <summary>
        /// Checks whether the user has a matching record in the employees database. If so the user is assigned the Employees role.
        /// If the user happens to have a managing function, the DepartmentManagers role is also assigned. If the user happens to be manager
        /// of the HR department, the HRManagers role is assigned to the user.
        /// For now, automatic role assignment is turned of, each user will only have the role Everyone.
        /// </summary>
        /// <param name="user"></param>
        /// <param name="currentRoles"></param>
        private void CheckEmployeeStatus(MembershipUser user, string[] currentRoles)
        {
            TRProfileCommon profile = (TRProfileCommon)ProfileBase.Create(user.UserName, true);

            if (profile.FullName == string.Empty)
                return;
            else
            {
                string commonName = GetCommonNameForUser(user.UserName);
                string[] nameparts = commonName.Split(',');
                string firstName = nameparts[1].Trim();
                string[] lastnameparts = nameparts[0].Split(' ');
                string voorvoegsel = string.Empty;
                string achternaam = string.Empty;
                if (lastnameparts.Length > 1)
                {
                    voorvoegsel = lastnameparts[0].Trim();
                    achternaam = lastnameparts[1].Trim();
                }
                else
                    achternaam = nameparts[0].Trim();

                ArrayList list = EmployeesDataService.GetEmployeesByLastName(achternaam);
                bool userIsEmployee = (list.Count > 0);
                PrimusEmployee theEmployee = null;

               // string[] currentRoles = Roles.GetRolesForUser();

               // RemoveUserFromRoles(user.UserName, new string[3] { "Employees", "DepartmentManagers", "HRManagers" });

                if (userIsEmployee)
                {
                    foreach (PrimusEmployee emp in list)
                    {
                        if (emp.RoepNaam == firstName)
                            theEmployee = emp;
                    }

                    if (theEmployee == null)
                        userIsEmployee = false;
                    else
                    {
                        //Fill profile with EmployeeNumber
                        profile.CommonName = commonName;
                        profile.EmployeeNumber = theEmployee.EmployeeNumber;
                        profile.FullName = firstName + " " + voorvoegsel + " " + achternaam;
                        profile.Save();


 
                        //obsolete for now. Roles are assigned manually.
                        
                        //Employee has managing function?
//                        EmployeeFunction func = EmployeesDataService.GetCurrentEmployeeFunction(theEmployee.EmployeeNumber);
//                        if (func != null)
//                            if (func.Function.Managing)
//                            {
//                                //Employee department is HR?
//                                if (func.Function.Department.Name == "HRD")
//                                    AddUserToRoles(user.UserName, new string[3] { "Employees", "DepartmentManagers", "HRManagers" });
//                                else
//                                    AddUserToRoles(user.UserName, new string[2] { "Employees", "DepartmentManagers" });
//                            }
 //                           else
 //                               AddUserToRoles(user.UserName, "Employees");
//
                    }
                }
            }
        }

        /// <summary>
        /// Adds a user to a role if it doesn't have it already
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="role"></param>
        private void AddUserToRoles(string userName, string role)
        {
            //while !Roles.IsUserInRole(role) returns false, a user might be already in a role.
            //probably a caching bug in the role manager
            if (!Roles.IsUserInRole(role))
                try
                {
                    Roles.AddUserToRole(userName, role);
                }
                catch { }
        }

        /// <summary>
        /// Adds a user to multiple roles
        /// </summary>
        /// <param name="userName">The user to add to the roles</param>
        /// <param name="roles">The roles to add the user to</param>
        private void AddUserToRoles(string userName, string[] roles)
        {
            foreach (string s in roles)
            {
                if (Roles.IsUserInRole(s))
                {

                }
                else
                {
                    try
                    {
                        Roles.AddUserToRole(userName, s);
                    }
                    catch { }
                }
            }
        }

        /// <summary>
        /// Removes the user from the roles, if he is in them
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="roles"></param>
        private void RemoveUserFromRoles(string userName, string[] roles)
        {
            foreach (string s in roles)
            {
                if (Roles.IsUserInRole(s))
                {
                    try
                    {
                        Roles.RemoveUserFromRole(userName, s);
                    }
                    catch { }
                }
            }
        }

        /// <summary>
        /// Does a directory search by domain user name and return the common name in the format:
        /// voorvoegsel achternaam, voornaam
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        private string GetCommonNameForUser(string userName)
        {
            RolePrincipal wp = (RolePrincipal)Thread.CurrentPrincipal;
            WindowsIdentity wi = (WindowsIdentity)wp.Identity;
            WindowsImpersonationContext wc = wi.Impersonate();

            string _fullName = string.Empty;
            try
            {
                string domainUserName = WindowsIdentity.GetCurrent().Name.Replace("\\", "/");

                System.DirectoryServices.DirectoryEntry dirEntry = new System.DirectoryServices.DirectoryEntry("WinNT://" + domainUserName);
                _fullName = dirEntry.Properties["FullName"].Value.ToString();
            }
            catch (System.Runtime.InteropServices.COMException COMex)
            {
                string error = COMex.Message;
            }
            catch (Exception e)
            {
                string error1 = e.Message;
            }


            #region LDAP implemenation
            //  DirectoryEntry dir = new DirectoryEntry("LDAP://EUNLAMSADC02/DC=eu", "NLHarinM", "WeetIkNiet");

            //  object obj = dir.NativeObject;
            //  DirectorySearcher search = new DirectorySearcher(dir);


            //DirectorySearcher search = new DirectorySearcher("LDAP://EUNLAMSADC02/DC=eu");
            //search.Dispose();
            //search = new DirectorySearcher("LDAP://EUNLAMSADC02/DC=eu");


            //string searchFilter = "SAMAccountName={0}";
            //string user = GetUserNameFromLoginName(userName);
            //string commonName = string.Empty;

            //search.Filter = string.Format(searchFilter, user);
            //search.PropertiesToLoad.Add("cn");

            //SearchResult res = search.FindOne();

            //commonName = res.Properties["cn"][0].ToString();
            ////Path.Text = res.Path;

            //search.Dispose();
            //dir.Close();
            //dir.Dispose();
            #endregion

            wc.Undo();
            return _fullName;
        }

        /// <summary>
        /// strips the domain from the user logon name
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        private string GetUserNameFromLoginName(string userName)
        {
            string username = userName.Split('\\')[1];

            return username;
        }
    }
}
