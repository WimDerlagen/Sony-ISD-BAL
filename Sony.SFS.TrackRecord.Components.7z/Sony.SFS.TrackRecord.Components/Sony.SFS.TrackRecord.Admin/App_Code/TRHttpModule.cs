using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Security;
using System.Security.Principal;

/// <summary>
/// Summary description for TRHttpModule
/// </summary>
public class TRHttpModule : IHttpModule 
{
    public TRHttpModule()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public void Dispose() { }

    public void Init(System.Web.HttpApplication Appl)
    {
        Appl.BeginRequest += new EventHandler(Appl_BeginRequest);
        Appl.AuthorizeRequest += new EventHandler(Appl_AuthorizeRequest);
    }

    void Appl_AuthorizeRequest(object sender, EventArgs e)
    {
        HttpContext context = HttpContext.Current;

        IPrincipal user = context.User;

        string[] roles = Roles.GetRolesForUser(user.Identity.Name);

        if (!Roles.IsUserInRole(user.Identity.Name, "Everyone"))
            Roles.AddUserToRole(user.Identity.Name, "Everyone");
    }

    void Appl_BeginRequest(object sender, EventArgs e)
    {
        

    }

}
