using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Sony.SFS.TrackRecord.Components;

public partial class System_Skills_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Skills.ItemDataBound += new RepeaterItemEventHandler(Skills_ItemDataBound);
        Skills.ItemCommand += new RepeaterCommandEventHandler(Skills_ItemCommand);
    }

    void Skills_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        switch (e.CommandName)
        {
            case "select":
                break;
        }
    }

    void Skills_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            Literal skillId = (Literal)e.Item.FindControl("skillId");
            LinkButton skillName = (LinkButton)e.Item.FindControl("skillName");
            Literal skillDescription = (Literal)e.Item.FindControl("skillDescription");

            Skill skill = (Skill)e.Item.DataItem;

            skillName.CommandName = "select";
            skillName.CommandArgument = skill.SkillID.ToString();
            

            skillId.Text = skill.SkillID.ToString();
            skillName.Text = skill.Name;
            skillDescription.Text = skill.Desciption;
        }
    }
}
