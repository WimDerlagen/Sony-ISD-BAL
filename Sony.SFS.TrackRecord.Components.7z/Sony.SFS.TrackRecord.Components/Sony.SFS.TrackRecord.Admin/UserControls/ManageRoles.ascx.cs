using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class UserControls_ManageRoles : System.Web.UI.UserControl
{
    TextBox newRoleName;

    protected void Page_Load(object sender, EventArgs e)
    {
        RoleRepeater.ItemCreated += new RepeaterItemEventHandler(RoleRepeater_ItemCreated);
        RoleRepeater.ItemDataBound += new RepeaterItemEventHandler(RoleRepeater_ItemDataBound);
        RoleRepeater.ItemCommand += new RepeaterCommandEventHandler(RoleRepeater_ItemCommand);

        CreateNewRole.Text = "Create role";
        CreateNewRole.Click += new EventHandler(CreateNewRole_Click);

        DataBind();
    }

    void CreateNewRole_Click(object sender, EventArgs e)
    {
        Roles.CreateRole(NewRoleName.Text);

        this.DataBind();
    }

    public override void DataBind()
    {
        RoleRepeater.DataSource = Roles.GetAllRoles();
        RoleRepeater.DataBind();
        base.DataBind();
    }

    protected override void Render(HtmlTextWriter writer)
    {
        base.Render(writer);
    }

    void RoleRepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }

    void RoleRepeater_ItemCreated(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Footer)
        {

        }
    }

    void RoleRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {

        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            HyperLink roleLink = (HyperLink)e.Item.FindControl("RoleLink");
            Label roleDescription = (Label)e.Item.FindControl("RoleDescription");
            HyperLink membersLink = (HyperLink)e.Item.FindControl("MembersLink");

            roleLink.Text = e.Item.DataItem.ToString();
            membersLink.Text = "Add/Remove members";

        }
    }
}
