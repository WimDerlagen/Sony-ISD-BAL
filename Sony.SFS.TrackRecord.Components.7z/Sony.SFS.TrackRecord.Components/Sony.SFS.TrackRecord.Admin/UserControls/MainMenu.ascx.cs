using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class UserControls_MainMenu : System.Web.UI.UserControl
{
    private string startingNodeUrl = "~/";
    private bool _static = false;

    public string StartingNodeUrl
    {
        get { return this.startingNodeUrl; }
        set { this.startingNodeUrl = value; }
    }

    public bool Static
    {
        get { return _static; }
        set { _static = value; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            SiteMapDataSource src = GetSiteMapDataSource();
            src.StartingNodeUrl = startingNodeUrl;
            src.ShowStartingNode = false;

            mainMenu.DataSource = src;
            mainMenu.DataBind();
        }
    }

    private SiteMapDataSource GetSiteMapDataSource()
    {
        XmlSiteMapProvider xmlSiteMap = new XmlSiteMapProvider();
        System.Collections.Specialized.NameValueCollection
               myCollection = new
               System.Collections.Specialized.NameValueCollection(1);

        myCollection.Add("siteMapFile", "Web.sitemap");
        xmlSiteMap.Initialize("provider", myCollection);
        xmlSiteMap.BuildSiteMap();
        SiteMapDataSource siteMap = new SiteMapDataSource();
        return siteMap;
    }
}
