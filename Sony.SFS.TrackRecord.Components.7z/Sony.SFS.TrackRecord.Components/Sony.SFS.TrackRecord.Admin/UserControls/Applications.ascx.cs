using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class UserControls_Applications : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        CreateApp.Click += new EventHandler(CreateApp_Click);

    }

    void CreateApp_Click(object sender, EventArgs e)
    {
        if (NewAppName.Text != string.Empty)
        {
            System.Configuration.Configuration config = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration("~/");
            System.Configuration.ConnectionStringSettings conconfig = config.ConnectionStrings.ConnectionStrings["Membership"];

            SqlConnection conn = new SqlConnection(conconfig.ConnectionString);
            SqlCommand command = new SqlCommand("aspnet_Applications_CreateApplication", conn);
            command.CommandType = CommandType.StoredProcedure;

            SqlParameter param1 = new SqlParameter("@ApplicationName", SqlDbType.NVarChar, 256);
            param1.Value = NewAppName.Text;

            SqlParameter param2 = new SqlParameter("@ApplicationId", SqlDbType.UniqueIdentifier);
            param2.Direction = ParameterDirection.Output;

            command.Parameters.Add(param1);
            command.Parameters.Add(param2);

            conn.Open();

            command.ExecuteNonQuery();

            conn.Close();

            Guid guid = (Guid)param2.Value;
        }
    }
}
