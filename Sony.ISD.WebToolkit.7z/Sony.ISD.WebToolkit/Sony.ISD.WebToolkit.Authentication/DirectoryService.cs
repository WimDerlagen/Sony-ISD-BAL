using System;
using System.Data;
using System.Collections.Generic;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Profile;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Security;
using System.Security.Principal;
using System.DirectoryServices;
using System.Threading;
using Sony.ISD.WebToolkit.Components;

namespace Sony.ISD.WebToolkit.Authentication
{
    public class DirectoryService
    {

        public static List<string> GetNames()
        {
            List<string> names;
            string cacheKey = "DirectoryUserNames";

            names = WTCache.Get(cacheKey) as List<string>;

            if (names == null)
            {
                names = new List<string>();
                names.Add("Select a user");

                RolePrincipal wp = (RolePrincipal)Thread.CurrentPrincipal;
                WindowsIdentity wi = (WindowsIdentity)wp.Identity;
                WindowsImpersonationContext wc = wi.Impersonate();

                DirectoryEntry de = new DirectoryEntry("LDAP://OU=Users,OU=Amsterdam,OU=SBNL,DC=eu,DC=sony,DC=com");
                DirectorySearcher ds = new DirectorySearcher(de);
                ds.Filter = "objectCategory=person";

                SearchResultCollection src = ds.FindAll();

                foreach (SearchResult sr in src)
                {
                    string name2 = sr.GetDirectoryEntry().Properties["CN"].Value.ToString();
                    names.Add(name2);
                }

                wc.Undo();

                WTCache.Insert(cacheKey, names, 6000);

            }

            return names;
        }

        public static string GetUserNameByCN(string cn)
        {
            RolePrincipal wp = (RolePrincipal)Thread.CurrentPrincipal;
            WindowsIdentity wi = (WindowsIdentity)wp.Identity;
            WindowsImpersonationContext wc = wi.Impersonate();

            string dirEntry = "LDAP://OU=Users,OU=Amsterdam,OU=SBNL,DC=eu,DC=sony,DC=com";
            DirectoryEntry de = new DirectoryEntry(dirEntry);
            DirectorySearcher dse = new DirectorySearcher(de);
            dse.Filter = string.Format("cn={0}", cn);

            SearchResult sr = dse.FindOne();

            string name;

            if (sr != null)
                name = sr.GetDirectoryEntry().Properties["sAMAccountName"].Value.ToString();
            else
                name = string.Empty;

            wc.Undo();

            return name;
        }

        public static string GetUserNameBySAM(string SAM)
        {
            RolePrincipal wp = (RolePrincipal)Thread.CurrentPrincipal;
            WindowsIdentity wi = (WindowsIdentity)wp.Identity;
            WindowsImpersonationContext wc = wi.Impersonate();

            DirectoryEntry de = new DirectoryEntry("WinNT://EU/" + SAM);
            string cn = string.Empty;
            try
            {
                cn = de.Properties["name"].Value.ToString();
            }
            catch
            {

            }

            wc.Undo();

            return cn;
        }
    }
}
