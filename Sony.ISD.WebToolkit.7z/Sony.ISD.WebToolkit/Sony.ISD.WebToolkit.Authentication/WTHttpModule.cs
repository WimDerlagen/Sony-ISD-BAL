using System;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Profile;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Security;
using System.Security.Principal;
using System.DirectoryServices;
using System.Threading;

namespace Sony.ISD.WebToolkit.Authentication
{
    public class WTHttpModule : IHttpModule
    {
        public WTHttpModule() { }

        public void Dispose() { }

        public void Init(System.Web.HttpApplication Appl)
        {
            Appl.AuthenticateRequest += new EventHandler(Appl_AuthenticateRequest);
            Appl.AuthorizeRequest += new EventHandler(Appl_AuthorizeRequest);
        }

        

        void Appl_AuthenticateRequest(object sender, EventArgs e)
        {
            HttpContext context = HttpContext.Current;
            IPrincipal user1 = context.User;

            //Create a membership so roles can be managed. Profiles and roles will work without membership
            //however, a list of users cannot be retreived using the Membership object, therefore, memberships are created
            //for each user.
            MembershipUser user = Membership.GetUser(user1.Identity.Name);

            if (user == null)
                Membership.CreateUser(user1.Identity.Name, "1");

            if (!Roles.IsUserInRole("Everyone"))
                Roles.AddUserToRole(user1.Identity.Name, "Everyone");
        }

        void Appl_AuthorizeRequest(object sender, EventArgs e)
        {
            HttpContext context = HttpContext.Current;
            IPrincipal user = context.User;

            //MembershipUser muser = Membership.GetUser(user.Identity.Name);

            //string[] roles = Roles.GetRolesForUser(user.Identity.Name);

            //switch (roles.Length)
            //{
            //    case 0:
            //        //something went wrong on authentication, everyone is Everyone
            //        break;
            //    case 1:
            //        break;
            //    default:
            //        //do nothing
            //        break;
            //}

            //for testing purposes
            if (user.Identity.Name == "EU\\NLHarinM")
                if (!Roles.IsUserInRole(user.Identity.Name, "Administrators"))
                    Roles.AddUserToRole(user.Identity.Name, "Administrators");
        }


        /// <summary>
        /// Adds a user to a role if it doesn't have it already
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="role"></param>
        private void AddUserToRoles(string userName, string role)
        {
            //while !Roles.IsUserInRole(role) returns false, a user might be already in a role.
            //probably a caching bug in the role manager
            if (!Roles.IsUserInRole(role))
                try
                {
                    Roles.AddUserToRole(userName, role);
                }
                catch { }
        }

        /// <summary>
        /// Adds a user to multiple roles
        /// </summary>
        /// <param name="userName">The user to add to the roles</param>
        /// <param name="roles">The roles to add the user to</param>
        private void AddUserToRoles(string userName, string[] roles)
        {
            foreach (string s in roles)
            {
                if (Roles.IsUserInRole(s))
                {

                }
                else
                {
                    try
                    {
                        Roles.AddUserToRole(userName, s);
                    }
                    catch { }
                }
            }
        }

        /// <summary>
        /// Removes the user from the roles, if he is in them
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="roles"></param>
        private void RemoveUserFromRoles(string userName, string[] roles)
        {
            foreach (string s in roles)
            {
                if (Roles.IsUserInRole(s))
                {
                    try
                    {
                        Roles.RemoveUserFromRole(userName, s);
                    }
                    catch { }
                }
            }
        }

        /// <summary>
        /// Does a directory search by domain user name and return the common name in the format:
        /// voorvoegsel achternaam, voornaam
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        private string GetCommonNameForUser(string userName)
        {
            RolePrincipal wp = (RolePrincipal)Thread.CurrentPrincipal;
            WindowsIdentity wi = (WindowsIdentity)wp.Identity;
            WindowsImpersonationContext wc = wi.Impersonate();

            string _fullName = string.Empty;
            try
            {
                string domainUserName = WindowsIdentity.GetCurrent().Name.Replace("\\", "/");

                System.DirectoryServices.DirectoryEntry dirEntry = new System.DirectoryServices.DirectoryEntry("WinNT://" + domainUserName);
                _fullName = dirEntry.Properties["FullName"].Value.ToString();
            }
            catch (System.Runtime.InteropServices.COMException COMex)
            {
                string error = COMex.Message;
            }
            catch (Exception e)
            {
                string error1 = e.Message;
            }

            wc.Undo();
            return _fullName;
        }

        /// <summary>
        /// strips the domain from the user logon name
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        private string GetUserNameFromLoginName(string userName)
        {
            string username = userName.Split('\\')[1];

            return username;
        }
    }
}
