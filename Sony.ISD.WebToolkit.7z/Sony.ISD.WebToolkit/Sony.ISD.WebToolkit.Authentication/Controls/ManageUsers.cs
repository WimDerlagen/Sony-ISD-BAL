using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web;
using System.Web.Profile;
using System.Web.Security;
using Sony.ISD.WebToolkit.Controls;
using Sony.ISD.WebToolkit.Components;
using Sony.ISD.WebToolkit.Authentication.Controls.Templates;

namespace Sony.ISD.WebToolkit.Authentication.Controls
{
    public class ManageUsers : Control
    {
        private RepeaterPlusNone Users;
        private Pager Pager;

        #region repeater templates
       
        private ITemplate headerTemplate = new ManageUsersHeaderTemplate();
        private ITemplate itemTemplate = new ManageUsersItemTemplate();
        private ITemplate alternateItemTemplate = new ManageUsersItemTemplate(true);
        private ITemplate footerTemplate = new ManageUsersFooterTemplate();
        private ITemplate noneTemplate = new ManageUsersNoneTemplate();

        public ITemplate HeaderTemplate
        {
            get { return headerTemplate; }
            set { headerTemplate = value; }
        }
        public ITemplate ItemTemplate
        {
            get { return itemTemplate; }
            set { itemTemplate = value; }
        }
        public ITemplate AlternateItemTemplate
        {
            get { return alternateItemTemplate; }
            set { alternateItemTemplate = value; }
        }
        public ITemplate FooterTemplate
        {
            get { return footerTemplate; }
            set { footerTemplate = value; }
        }
        public ITemplate NoneTemplate
        {
            get { return noneTemplate; }
            set { noneTemplate = value; }
        }

        #endregion

        public ManageUsers()
        {
            Users = new RepeaterPlusNone();
            Pager = new Pager();

            DataBind();
        }

        protected override void CreateChildControls()
        {
            Controls.Add(Users);
            Controls.Add(Pager);
        }

        public override void DataBind()
        {
            WTContext context = WTContext.Current;

            
            Users.HeaderTemplate = HeaderTemplate;
            Users.ItemTemplate = ItemTemplate;
            Users.AlternatingItemTemplate = AlternateItemTemplate;
            Users.FooterTemplate = FooterTemplate;
            Users.NoneTemplate = NoneTemplate;


            int totalrecords = 0;

            if (context.Role == string.Empty)
            {
                MembershipUserCollection coll = Membership.GetAllUsers(Pager.PageIndex, Pager.PageSize, out totalrecords);

                Pager.TotalRecords = totalrecords;

                Users.DataSource = coll;
                Users.DataBind();
            }
            else
            {
                string[] users = Roles.GetUsersInRole(context.Role);

                ArrayList usersInRole = new ArrayList();

                //Get only the users for the selecter page
                for (int i = (Pager.PageIndex * Pager.PageSize); i < (((Pager.PageIndex + 1) * Pager.PageSize) - 1); i++)
                {
                    //if the last page is not full, i will run outside the bounds of the array.
                    //altering the for condition might be neater
                    try
                    {
                        usersInRole.Add(Membership.GetUser(users[i]));
                    }
                    catch (IndexOutOfRangeException iex)
                    {
                        break;
                    }
                }

                Pager.TotalRecords = users.Length;

                Users.DataSource = usersInRole;
                Users.DataBind();
            }
        }
    }
}
