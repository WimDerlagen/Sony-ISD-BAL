using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web;
using System.Web.Profile;
using System.Web.Security;
using Sony.ISD.WebToolkit.Controls;

namespace Sony.ISD.WebToolkit.Authentication.Controls
{
    /// <summary>
    /// A simple wizard for user creation. This wizard should be used in a Windows authentication website
    /// A password is omitted because of windows authentication. A membership user is created to be able to make full use of
    /// the Membership provider. This wizard should not be used with forms authentication.
    /// </summary>
    public class CreateNTUserWizard : Control, INamingContainer
    {
        HtmlGenericControl div1 = new HtmlGenericControl("div");
        HtmlGenericControl div2 = new HtmlGenericControl("div");
        TextBox userName;
        Panel panel1 = new Panel();
        Panel panel2 = new Panel();


        
        protected override void CreateChildControls()
        {
            
            HtmlGenericControl table1 = new HtmlGenericControl("table");
            HtmlGenericControl caption1 = new HtmlGenericControl("caption");
            caption1.Controls.Add(new LiteralControl("Sign up a new account"));

            HtmlGenericControl tr1 = new HtmlGenericControl("tr");
            HtmlGenericControl td1 = new HtmlGenericControl("td");
            HtmlGenericControl td2 = new HtmlGenericControl("td");

            HtmlGenericControl tr2 = new HtmlGenericControl("tr");
            HtmlGenericControl td4 = new HtmlGenericControl("td");
            Button button = new Button();
            button.Text = "Create user";
            button.ID = "CreateUser";
            button.Click += new EventHandler(button_Click);

            td1.Controls.Add(new LiteralControl("Username"));
            userName = new TextBox();
            userName.ID = "UserName";

            td2.Controls.Add(userName);

            tr1.Controls.Add(td1);
            tr1.Controls.Add(td2);

            td4.Controls.Add(button);
            td4.Attributes.Add("colspan", "2");
            td4.Attributes.Add("align", "right");

            tr2.Controls.Add(td4);

            table1.Controls.Add(caption1);
            table1.Controls.Add(tr1);
            table1.Controls.Add(tr2);

            panel1.Controls.Add(table1);


            HtmlGenericControl table2 = new HtmlGenericControl("table");
            HtmlGenericControl caption2 = new HtmlGenericControl("caption");
            caption2.Controls.Add(new LiteralControl("User creation complete"));

            HtmlGenericControl tr3 = new HtmlGenericControl("tr");
            HtmlGenericControl td5 = new HtmlGenericControl("td");

            tr3.Controls.Add(td5);
            table2.Controls.Add(caption2);
            table2.Controls.Add(tr3);

            panel2.Controls.Add(table2);

            Controls.Add(panel1);
            Controls.Add(panel2);

            panel1.Visible = true;
            panel2.Visible = false;
        }

        void button_Click(object sender, EventArgs e)
        {
            if (userName.Text != string.Empty)
            {
                Membership.CreateUser(userName.Text, "1");
            }
        }
    }
}
