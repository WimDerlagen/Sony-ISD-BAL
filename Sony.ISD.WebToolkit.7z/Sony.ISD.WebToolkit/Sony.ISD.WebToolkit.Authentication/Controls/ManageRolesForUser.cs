using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web;
using System.Web.Profile;
using System.Web.Security;
using Sony.ISD.WebToolkit.Components;
using Sony.ISD.WebToolkit.Controls;
using Sony.ISD.WebToolkit.Authentication.Controls.Templates;

namespace Sony.ISD.WebToolkit.Authentication.Controls
{
    public class ManageRolesForUser : Control, INamingContainer
    {
        Literal UserName;
        ListBox AvailableRoles;
        ListBox RolesUserIsIn;
        Button Add;
        Button Remove;
        WTContext context = WTContext.Current;
        MembershipUser user = null;

        public ManageRolesForUser()
        {
            UserName = new Literal();
            AvailableRoles = new ListBox();
            RolesUserIsIn = new ListBox();
            Add = new Button();
            Remove = new Button();

        }

        protected override void CreateChildControls()
        {
            BindData();

            //create containing layers
            HtmlGenericControl div1 = new HtmlGenericControl("div");
            HtmlGenericControl div2 = new HtmlGenericControl("div");
            HtmlGenericControl div3 = new HtmlGenericControl("div");
            HtmlGenericControl div4 = new HtmlGenericControl("div");

            div1.Attributes.Add("class", "userRoles");
            div2.Attributes.Add("class", "availableRoles");
            div3.Attributes.Add("class", "rolesButtons");
            div4.Attributes.Add("class", "rolesForUser");


            //create contents
            HtmlGenericControl h3 = new HtmlGenericControl("h3");
            LiteralControl newrol = new LiteralControl("Rollen voor gebruiker: " + UserName.Text);
            h3.Controls.Add(newrol);

            AvailableRoles.CssClass = "availableRolesList";
            RolesUserIsIn.CssClass = "rolesForUserList";

            Add.Text = "Add -&gt;";
            Add.CssClass = "addButton";
            Remove.CssClass = "removeButton";
            Remove.Text = "&lt;- Remove";
            Add.Click += new EventHandler(Add_Click);
            Remove.Click += new EventHandler(Remove_Click);


            //add content to layers
            div2.Controls.Add(AvailableRoles);
            div3.Controls.Add(Add);
            div3.Controls.Add(Remove);
            div4.Controls.Add(RolesUserIsIn);

            div1.Controls.Add(h3);
            div1.Controls.Add(div2);
            div1.Controls.Add(div3);
            div1.Controls.Add(div4);


            Controls.Add(div1);
        }

        private void BindData()
        {
            //get user and roles
            Guid? userKey = context.UserID;
            if (userKey != null)
            {
                user = Membership.GetUser(userKey);

                UserName.Text = user.UserName;

                string[] rolesForUser = Roles.GetRolesForUser(user.UserName);
                string[] allRoles = Roles.GetAllRoles();


                LoadUserRoles(rolesForUser);
                LoadAvailableRoles(allRoles, rolesForUser);

            }

        }

        void Remove_Click(object sender, EventArgs e)
        {
            Roles.RemoveUserFromRole(user.UserName, RolesUserIsIn.SelectedValue);

            BindData();
        }

        void Add_Click(object sender, EventArgs e)
        {
            Roles.AddUserToRole(user.UserName, AvailableRoles.SelectedValue);

            BindData();
        }

        /// <summary>
        /// Loads the user roles to the RolesUserIsIn ListBox
        /// </summary>
        /// <param name="roles"></param>
        private void LoadUserRoles(string[] roles)
        {
            RolesUserIsIn.Items.Clear();

            foreach (string s in roles)
            {
                ListItem li = new ListItem();
                li.Text = s;
                li.Value = s;

                RolesUserIsIn.Items.Add(li);
            }
        }


        /// <summary>
        /// Loads the roles the user is not in, into the AvailableRoles ListBox
        /// </summary>
        /// <param name="roles"></param>
        /// <param name="userRoles"></param>
        private void LoadAvailableRoles(string[] roles, string[] userRoles)
        {
            AvailableRoles.Items.Clear();

            ArrayList avail = new ArrayList();

            foreach (string s in roles)
            {
                bool userIsIn = false;

                foreach (string p in userRoles)
                {
                    if (p == s)
                        userIsIn = true;
                }

                if (!userIsIn)
                    avail.Add(s);
            }


            foreach (string srole in avail)
            {
                ListItem li = new ListItem();
                li.Text = srole;
                li.Value = srole;

                AvailableRoles.Items.Add(li);
            }
        }
        
    }
}
