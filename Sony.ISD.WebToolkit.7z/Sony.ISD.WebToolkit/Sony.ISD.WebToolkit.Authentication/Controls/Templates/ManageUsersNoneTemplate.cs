using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Sony.ISD.WebToolkit.Controls;

namespace Sony.ISD.WebToolkit.Authentication.Controls.Templates
{
    internal class ManageUsersNoneTemplate : ITemplate
    {
        public void InstantiateIn(Control container)
        {
            container.Controls.Add(new LiteralControl("<tr><td colspan=\"3\" style=\"text-align: center;\">geen records gevonden</td></tr>"));
        }
    }
}
