using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Sony.ISD.WebToolkit.Controls;

namespace Sony.ISD.WebToolkit.Authentication.Controls.Templates
{
    internal class ManageUsersItemTemplate : ITemplate
    {
        private bool alt;

        public bool Alternate
        {
            get { return alt; }
            set { alt = value; }

        }

        public ManageUsersItemTemplate() { }
        public ManageUsersItemTemplate(bool alt) { this.alt = alt; }


        public void InstantiateIn(Control container)
        {

            HtmlGenericControl tr = new HtmlGenericControl("tr");
            HtmlGenericControl td1 = new HtmlGenericControl("td");
            HtmlGenericControl td2 = new HtmlGenericControl("td");
            HtmlGenericControl td3 = new HtmlGenericControl("td");

            if (alt)
            {
                td1.Attributes.Add("class", "usertd1 alt");
                td2.Attributes.Add("class", "usertd2 alt");
                td3.Attributes.Add("class", "usertd3 alt");
            }
            else
            {
                td1.Attributes.Add("class", "usertd1");
                td2.Attributes.Add("class", "usertd2");
                td3.Attributes.Add("class", "usertd3");
            }

            HyperLink name = new HyperLink();
            HyperLink userName = new HyperLink();
            Literal roles = new Literal();

            name.DataBinding += new EventHandler(name_DataBinding);
            userName.DataBinding += new EventHandler(userName_DataBinding);
            roles.DataBinding += new EventHandler(roles_DataBinding);

            td1.Controls.Add(name);
            td2.Controls.Add(userName);
            td3.Controls.Add(roles);

            tr.Controls.Add(td1);
            tr.Controls.Add(td2);
            tr.Controls.Add(td3);


            container.Controls.Add(tr);


        }

        void roles_DataBinding(object sender, EventArgs e)
        {
            Literal roles = (Literal) sender;
            RepeaterItem container = (RepeaterItem)roles.NamingContainer;
            MembershipUser user = (MembershipUser)container.DataItem;

            roles.Text = GetRolesString(Roles.GetRolesForUser(user.UserName));

        }

        void userName_DataBinding(object sender, EventArgs e)
        {
            HyperLink userName = (HyperLink)sender;
            RepeaterItem container = (RepeaterItem)userName.NamingContainer;
            MembershipUser user = (MembershipUser)container.DataItem;

            userName.Text = user.UserName;
            userName.NavigateUrl = string.Format("~/Users/RolesForUser/Default.aspx?UserID={0}", user.ProviderUserKey);
            
        }

        void name_DataBinding(object sender, EventArgs e)
        {
            HyperLink name = (HyperLink)sender;
            RepeaterItem container = (RepeaterItem)name.NamingContainer;
            MembershipUser user = (MembershipUser)container.DataItem;

            name.Text = user.UserName;
            name.NavigateUrl = string.Format("~/Users/RolesForUser/Default.aspx?UserID={0}", user.ProviderUserKey);
            
        }
        private string GetRolesString(string[] roles)
        {
            string output = string.Empty;

            foreach (string s in roles)
            {
                output += s;
                output += ", ";
            }

            if (output.Length > 1)
                output = output.Substring(0, output.Length - 2);

            return output;
        }
    }
}
