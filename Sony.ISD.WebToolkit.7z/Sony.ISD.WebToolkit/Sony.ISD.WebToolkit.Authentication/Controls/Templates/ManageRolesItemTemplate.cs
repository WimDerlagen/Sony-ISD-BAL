using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Sony.ISD.WebToolkit.Controls;

namespace Sony.ISD.WebToolkit.Authentication.Controls.Templates
{
    internal class ManageRolesItemTemplate : ITemplate
    {
        private bool alt;

        public bool Alternate
        {
            get { return alt; }
            set { alt = value; }

        }

        public ManageRolesItemTemplate() { }
        public ManageRolesItemTemplate(bool alt) { this.alt = alt; }

        public void InstantiateIn(Control container)
        {
  //          <tr>
//				<td >
//					<asp:Literal runat="server" ID="RoleLiteral" />
//				</td>
//				<td valign="top"><asp:HyperLink runat="server" ID="MembersLink" /></td>
//			</tr>

            HtmlGenericControl tr1 = new HtmlGenericControl("tr");
            HtmlGenericControl td1 = new HtmlGenericControl("td");
            HtmlGenericControl td2 = new HtmlGenericControl("td");

            if (alt)
            {
                td1.Attributes.Add("class", "roletd1 alt");
                td2.Attributes.Add("class", "roletd2 alt");
            }
            else
            {
                td1.Attributes.Add("class", "roletd1");
                td2.Attributes.Add("class", "roletd2");
            }

            Literal RoleLiteral = new Literal();
            RoleLiteral.DataBinding += new EventHandler(RoleLiteral_DataBinding);

            HyperLink MembersLink = new HyperLink();
            MembersLink.DataBinding += new EventHandler(MembersLink_DataBinding);

            td1.Controls.Add(RoleLiteral);
            td2.Controls.Add(MembersLink);

            tr1.Controls.Add(td1);
            tr1.Controls.Add(td2);

            container.Controls.Add(tr1);
        }

        void MembersLink_DataBinding(object sender, EventArgs e)
        {
            HyperLink members = (HyperLink)sender;
            RepeaterItem container = (RepeaterItem)members.NamingContainer;
            string role = (string)container.DataItem;

            string url = "~/Users/Default.aspx?Role={0}";

            members.Text = "Members";
            members.NavigateUrl = string.Format(url, role);
        }

        void RoleLiteral_DataBinding(object sender, EventArgs e)
        {
            Literal roles = (Literal)sender;
            RepeaterItem container = (RepeaterItem)roles.NamingContainer;
            string role = (string)container.DataItem;

            roles.Text = role;
        }


    }
}
