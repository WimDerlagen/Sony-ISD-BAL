using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Sony.ISD.WebToolkit.Controls;
using Sony.ISD.WebToolkit.Authentication.Properties;

namespace Sony.ISD.WebToolkit.Authentication.Controls.Templates
{
    internal class ManageRolesHeaderTemplate : ITemplate
    {
        public void InstantiateIn(Control container)
        {
            string table1 = "<table cellpadding=\"0\" class=\"rolesTable\" cellspacing=\"0\" border=\"0\">";

            HtmlGenericControl caption = new HtmlGenericControl("caption");
            caption.Controls.Add(new LiteralControl("Overzicht rollen"));

            HtmlGenericControl thead = new HtmlGenericControl("thead");
            HtmlGenericControl tr1 = new HtmlGenericControl("tr");
            HtmlGenericControl th1 = new HtmlGenericControl("th");
            HtmlGenericControl th2 = new HtmlGenericControl("th");

            LiteralControl name = new LiteralControl("Role name");
            LiteralControl mem = new LiteralControl("Role members");

            th1.Controls.Add(name);
            th2.Controls.Add(mem);
            tr1.Controls.Add(th2);

            LiteralControl tr2 = new LiteralControl("<tr><td colspan=\"2\"><hr /></td></tr>");


            container.Controls.Add(new LiteralControl(table1));
            container.Controls.Add(tr1);
            container.Controls.Add(tr2);

        }
    }
}
