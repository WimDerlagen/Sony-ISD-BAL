using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Sony.ISD.WebToolkit.Controls;
using Sony.ISD.WebToolkit.Authentication.Properties;

namespace Sony.ISD.WebToolkit.Authentication.Controls.Templates
{
    internal class ManageUsersHeaderTemplate : ITemplate
    {
        public void InstantiateIn(Control container)
        {
            string table1 = "<table cellpadding=\"0\" class=\"userTable\" cellspacing=\"0\" border=\"0\">";

            LinkButton name = new LinkButton();
            name.CommandName = "sort";
            name.CommandArgument = "Name";
            name.Text = "Name";

            StandardImageButton sort1 = new StandardImageButton();
            sort1.CommandName = "sort";
            sort1.CommandArgument = "Name";
            sort1.ImageUrl = "/up.gif";

            LinkButton userName = new LinkButton();
            userName.CommandName = "sort";
            userName.CommandArgument = "Username";
            userName.Text = "Username";

            StandardImageButton sort2 = new StandardImageButton();
            sort2.CommandName = "sort";
            sort2.CommandArgument = "UserName";
            sort2.ImageUrl = "/up.gif";

            LinkButton roles = new LinkButton();
            roles.CommandName = "sort";
            roles.CommandArgument = "Roles";
            roles.Text = "Rollen";

            StandardImageButton sort3 = new StandardImageButton();
            sort3.CommandName = "sort";
            sort3.CommandArgument = "Roles";
            sort3.ImageUrl = "/up.gif";


            HtmlGenericControl tr1 = new HtmlGenericControl("tr");
            HtmlGenericControl th1 = new HtmlGenericControl("th");
            HtmlGenericControl th2 = new HtmlGenericControl("th");
            HtmlGenericControl th3 = new HtmlGenericControl("th");

            //fill headercells
            th1.Controls.Add(name);
            th1.Controls.Add(sort1);
            th2.Controls.Add(userName);
            th2.Controls.Add(sort2);
            th3.Controls.Add(roles);
            th3.Controls.Add(sort3);

            //fill row
            tr1.Controls.Add(th1);
            tr1.Controls.Add(th2);
            tr1.Controls.Add(th3);

            LiteralControl tr2 = new LiteralControl("<tr><td colspan=\"3\"><hr /></td></tr>");

            container.Controls.Add(new LiteralControl(table1));
            container.Controls.Add(tr1);
            container.Controls.Add(tr2);
        }
    }
}
