using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web;
using System.Web.Profile;
using System.Web.Security;
using Sony.ISD.WebToolkit.Controls;
using Sony.ISD.WebToolkit.Authentication.Controls.Templates;

namespace Sony.ISD.WebToolkit.Authentication.Controls
{
    public class ManageRoles : Control
    {
        private RepeaterPlusNone RolesRepeater;
        private Pager Pager;

        #region repeater templates

        private ITemplate headerTemplate = new ManageRolesHeaderTemplate();
        private ITemplate itemTemplate = new ManageRolesItemTemplate();
        private ITemplate alternateItemTemplate = new ManageRolesItemTemplate(true);
        private ITemplate footerTemplate = new ManageRolesFooterTemplate();
        private ITemplate noneTemplate = new ManageRolesNoneTemplate();

        public ITemplate HeaderTemplate
        {
            get { return headerTemplate; }
            set { headerTemplate = value; }
        }
        public ITemplate ItemTemplate
        {
            get { return itemTemplate; }
            set { itemTemplate = value; }
        }
        public ITemplate AlternateItemTemplate
        {
            get { return alternateItemTemplate; }
            set { alternateItemTemplate = value; }
        }
        public ITemplate FooterTemplate
        {
            get { return footerTemplate; }
            set { footerTemplate = value; }
        }
        public ITemplate NoneTemplate
        {
            get { return noneTemplate; }
            set { noneTemplate = value; }
        }

        #endregion

        public ManageRoles()
        {
            RolesRepeater = new RepeaterPlusNone();
            Pager = new Pager();

            DataBind();
        }

        protected override void CreateChildControls()
        {
            Controls.Add(RolesRepeater);
            Controls.Add(Pager);
        }

        public override void DataBind()
        {
            RolesRepeater.HeaderTemplate = HeaderTemplate;
            RolesRepeater.ItemTemplate = ItemTemplate;
            RolesRepeater.AlternatingItemTemplate = AlternateItemTemplate;
            RolesRepeater.FooterTemplate = FooterTemplate;
            RolesRepeater.NoneTemplate = NoneTemplate;

            string[] roles = Roles.GetAllRoles();

            Pager.TotalRecords = roles.Length;

            RolesRepeater.DataSource = roles;
            RolesRepeater.DataBind();
        }
    }
}
