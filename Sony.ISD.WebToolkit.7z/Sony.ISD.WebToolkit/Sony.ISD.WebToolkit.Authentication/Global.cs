using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Sony.ISD.WebToolkit.Authentication.Properties;

namespace Sony.ISD.WebToolkit.Authentication
{
    public class Global
    {
        public static ArrayList GetResourceImages()
        {
            System.Drawing.Bitmap up = Resources.up;
            System.Drawing.Bitmap down = Resources.down;
            up.Tag = "up.gif";
            down.Tag = "down.gif";

            ArrayList res = new ArrayList();

            res.Add(up);
            res.Add(down);

            return res;

        }
    }
}
