using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Sony.ISD.WebToolkit.Controls.Interfaces;

namespace Sony.ISD.WebToolkit.Controls
{
    public abstract class PermissableControl : WebControl, IPermissableControl
    {
        protected abstract string friendlyName {get;}
        private Hashtable functions;

        public string FriendlyName
        {
            get { return friendlyName; }
        }


        public Hashtable Functions
        {
            get { return functions; }
        }


        public void AddRoleToFunction(string role, string function)
        {
            //get current roles for function
            string roles = (string) functions[function.GetHashCode()];

            //add new role
            if (!roles.Contains(role))
            {
                roles += ", " + role;

                functions[function.GetHashCode()] = roles;
            }
        }


        public void RemoveRoleFromFunction(string role, string function)
        {
            //get current roles
            string roles = (string)functions[function.GetHashCode()];
            string[] fields = roles.Split(',');
            string newRoles = string.Empty;

            //re-add roles, except the role to be removed
            foreach (string s in fields)
            {
                if (s != role)
                {
                    newRoles += s;
                    newRoles += ", ";
                }
            }

            //strip floating comma
            if (newRoles.Length > 1)
            {
                newRoles = newRoles.Substring(0, newRoles.Length - 2);
            }

            //assign new roles
            functions[function.GetHashCode()] = newRoles;
        }


        public bool HasPermission(string function, string[] userRoles)
        {
            //get current roles for function
            string[] roles = ((string)functions[function.GetHashCode()]).Split(',');
            bool match = false;

            foreach (string role in roles)
            {
                foreach (string uRole in userRoles)
                {
                    if (uRole.Equals(role))
                        match = true;
                }
            }

            return match;
        }

        public void LoadPermissions(string[] functions, string[] permissions)
        {
            Functions.Clear();

            for (int i = 0; i < functions.Length; i++)
            {
                Functions.Add(functions[i], permissions[i]);
            }
        }


    }
}
