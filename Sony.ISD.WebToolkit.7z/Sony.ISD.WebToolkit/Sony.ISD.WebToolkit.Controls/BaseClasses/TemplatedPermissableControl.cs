using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Sony.ISD.WebToolkit.Components;
using Sony.ISD.WebToolkit.Configuration;

namespace Sony.ISD.WebToolkit.Controls
{
    [
     ParseChildren(true),
     PersistChildren(false),
     ]
    public abstract class TemplatedPermissableControl : PermissableControl, INamingContainer
    {

        #region Composite Controls

        /// <exclude/>
        public override ControlCollection Controls
        {
            get
            {
                this.EnsureChildControls();
                return base.Controls;
            }
        }

        /// <exclude/>
        public override void DataBind()
        {
            this.EnsureChildControls();
            base.DataBind();
        }

        #endregion

        #region External Skin

        /// <summary>
        /// Gets the name of the theme being used.
        /// </summary>
        protected virtual string ThemeName
        {
            get
            {
                return "default";
            }
        }

        protected virtual string SkinFolder
        {
            get
            {
                return "~/Themes/" + ThemeName + "/Skins/"; //TODO Use correct skin folder
            }
        }

        private String SkinPath
        {
            get
            {
                return this.SkinFolder + ExternalSkinFileName;
            }
        }

        /// <summary>
        /// Gets the name of the skin file to load from
        /// </summary>
        protected virtual String ExternalSkinFileName
        {
            get
            {
                if (SkinName == null)
                    return CreateExternalSkinFileName(null);

                return SkinName;
            }
            set
            {
                SkinName = value;
            }
        }

        string skinName;
        public string SkinName
        {
            get
            {
                return skinName;
            }
            set
            {
                skinName = value;
            }
        }

        protected virtual string CreateExternalSkinFileName(string path)
        {
            return CreateExternalSkinFileName(path, "Skin-" + this.GetType().Name);
        }

        protected virtual string CreateExternalSkinFileName(string path, string name)
        {
            if (path != null && !path.EndsWith("/"))
                path = path + "/";

            return string.Format("{0}{1}.ascx", path, name);
        }


        private Boolean SkinFolderExists
        {
            get
            {
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    String folderPath = context.Server.MapPath(this.SkinFolder);
                    return System.IO.Directory.Exists(folderPath);
                }
                return true;
            }
        }

        private Boolean SkinFileExists
        {
            get
            {
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    String filePath = context.Server.MapPath(this.SkinPath);
                    return System.IO.File.Exists(filePath);
                }
                return true;
            }
        }

        private Boolean DefaultSkinFileExists
        {
            get
            {
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    String filePath = context.Server.MapPath(this.DefaultSkinPath);
                    return System.IO.File.Exists(filePath);
                }
                return true;
            }
        }

        protected virtual string DefaultSkinPath
        {
            get
            {
                return "~/Themes/default/Skins/" + ExternalSkinFileName;
            }
        }

        #endregion

        #region Public Properties

        /// <summary>
        /// The template used to override the default UI of the control.
        /// </summary>
        /// <remarks>
        /// All serverside controls that are in the default UI must exist and have the same ID's.
        /// </remarks>
        [
        Browsable(false),
        DefaultValue(null),
        Description("TODO SkinTemplate Description"),
        PersistenceMode(PersistenceMode.InnerProperty),
        ]
        public ITemplate SkinTemplate
        {
            get
            {
                return _skinTemplate;
            }
            set
            {
                _skinTemplate = value;
                ChildControlsCreated = false;
            }
        }
        private ITemplate _skinTemplate;

        #endregion

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
        }

        /// <summary>
        /// No End Span
        /// </summary>
        /// <param name="writer"></param>
        public override void RenderEndTag(HtmlTextWriter writer)
        {
            //we don't need a span tag
        }

        /// <exclude/>
        public override Control FindControl(string id)
        {
            Control ctrl = base.FindControl(id);
            if (ctrl == null && this.Controls.Count == 1)
            {
                ctrl = this.Controls[0].FindControl(id);
            }
            return ctrl;
        }

        /// <exclude/>
        protected override void CreateChildControls()
        {
            Controls.Clear();

            //	System.Diagnostics.Debug.WriteLine("Creating child controls...");
            //	System.Diagnostics.Debug.WriteLine("Theme name empty:"+(!Globals.IsNullorEmpty(ThemeName)).ToString());
            //	System.Diagnostics.Debug.WriteLine("SkinFolderExists"+SkinFolderExists.ToString());
            //	System.Diagnostics.Debug.WriteLine("Skinfile and page not null:"+ SkinFileExists.ToString() +",  "+this.Page.ToString());


            // 1) A custom theme setting is the most important
            Boolean _skinLoaded = false;
            if (!Globals.IsNullorEmpty(ThemeName))
            {
                if (SkinFolderExists)
                {
                    if (SkinFileExists && this.Page != null)
                    {
                        Control skin = this.Page.LoadControl(this.SkinPath);
                        this.Controls.Add(skin);
                        _skinLoaded = true;
                    }
                }
            }

            // 2) Next, look for an inline template
            if (!_skinLoaded && SkinTemplate != null)
            {
                SkinTemplate.InstantiateIn(this);
                _skinLoaded = true;
            }

            // 3) last resort is the default external skin
            if (!_skinLoaded && this.Page != null && this.DefaultSkinFileExists)
            {
                Control defaultSkin = this.Page.LoadControl(this.DefaultSkinPath);
                this.Controls.Add(defaultSkin);
                _skinLoaded = true;
            }

            // 4) If none of the skin locations were successful, throw.
            if (!_skinLoaded)
            {
                // throw new TRException(TRExceptionType.SkinNotFound);
            }

            AttachChildControls();
        }


        /// <summary>
        /// Override this method to attach templated or external skin controls to local references.
        /// </summary>
        /// <remarks>
        /// This will only be called if the non-default skin is used.
        /// </remarks>
        protected abstract void AttachChildControls();

        protected override void Render(HtmlTextWriter writer)
        {
            SourceMarker(true, writer);
            base.Render(writer);
            SourceMarker(false, writer);
        }

        [System.Diagnostics.Conditional("DEBUG")]
        protected void SourceMarker(bool isStart, HtmlTextWriter writer)
        {

            if (isStart)
            {
                writer.WriteLine("<!-- Start: {0} -->", this.GetType());

                if (System.IO.File.Exists(this.SkinPath))
                    writer.WriteLine("<!-- Skin Path: {0} -->", this.SkinPath);
                else if (SkinTemplate != null)
                    writer.WriteLine("<!-- Inline Skin: {0} -->", true);
                else
                    writer.WriteLine("<!-- Skin Path: {0} -->", this.DefaultSkinPath);

            }
            else
                writer.WriteLine("<!-- End: {0} -->", this.GetType());
        }



    }
}
