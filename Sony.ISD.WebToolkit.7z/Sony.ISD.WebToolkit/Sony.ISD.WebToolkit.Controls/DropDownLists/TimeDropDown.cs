using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Sony.ISD.WebToolkit.Controls
{
    public class TimeDropDown : DropDownList
    {
        string timeString = "{0}:{1}";
        public TimeDropDown()
        {
            DataBind();
        }

        public TimeSpan SelectedTime
        {
            get
            {
                int hour;
                int minute;
                string[] parts = this.SelectedValue.Split(':');

                hour = Convert.ToInt32(parts[0]);
                minute = Convert.ToInt32(parts[1]);

                return new TimeSpan(hour, minute, 0);
            }
        }

        public override void DataBind()
        {
            base.DataBind();

            this.Items.Clear();

            for (int i = 7; i < 25; i++)
            {
                ListItem li = new ListItem();
                ListItem li2 = new ListItem();
                string time;
                string time2;

                if (i < 10)
                {
                    time = string.Format(timeString, ("0" + i.ToString()), "00");
                    time2 = string.Format(timeString, ("0" + i.ToString()), "30");
                    
                    li.Text = time;
                    li.Value = time;

                    li2.Text = time2;
                    li2.Value = time2;
                }
                else
                {
                    time = string.Format(timeString, (i.ToString()), "00");
                    time2 = string.Format(timeString, (i.ToString()), "30");

                    li.Text = time;
                    li.Value = time;

                    li2.Text = time2;
                    li2.Value = time2;
                }

                Items.Add(li);
                Items.Add(li2);
            }
        }
    }


}
