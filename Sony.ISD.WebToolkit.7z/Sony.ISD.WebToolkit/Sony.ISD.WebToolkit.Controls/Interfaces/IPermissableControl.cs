using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Sony.ISD.WebToolkit.Controls.Interfaces
{
    public interface IPermissableControl
    {
        string FriendlyName { get;}
        Hashtable Functions { get;}
    }
}
