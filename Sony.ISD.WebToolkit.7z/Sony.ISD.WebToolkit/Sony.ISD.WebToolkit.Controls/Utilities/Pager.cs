using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using Sony.ISD.WebToolkit.Components;

namespace Sony.ISD.WebToolkit.Controls
{
    public class Pager : Label, INamingContainer
    {
        WTContext wtContext = WTContext.Current;
        HyperLink previousLink;
        HyperLink nextLink;
        HyperLink firstLink;
        HyperLink lastLink;
        HyperLink[] pagingHyperLinks;


        public override ControlCollection Controls
        {
            get
            {
                EnsureChildControls();
                return base.Controls;
            }
        }

        protected override void CreateChildControls()
        {
            Controls.Clear();

            // Add Page buttons
            //
            AddPageLinks();

            // Add Previous Next child controls
            //
            AddPreviousNextLinks();

            // Add First Last child controls
            //
            AddFirstLastLinks();

        }


        #region Render functions
        protected override void Render(HtmlTextWriter writer)
        {

            int totalPages = CalculateTotalPages();

            // Do we have data?
            //
            if (totalPages <= 1)
                return;

            AddAttributesToRender(writer);


            // Render the paging buttons
            //
            writer.AddAttribute(HtmlTextWriterAttribute.Class, this.CssClass, false);
            //writer.RenderBeginTag(HtmlTextWriterTag.Span);

            // Render the first button
            //
            RenderFirst(writer);

            // Render the previous button
            //
            RenderPrevious(writer);

            // Render the page button(s)
            //
            RenderPagingButtons(writer);

            // Render the next button
            //
            RenderNext(writer);

            // Render the last button
            //
            RenderLast(writer);

            //writer.RenderEndTag();

        }

        void RenderFirst(HtmlTextWriter writer)
        {

            int totalPages = CalculateTotalPages();

            if ((PageIndex >= 3) && (totalPages > 5))
            {
                firstLink.RenderControl(writer);

                LiteralControl l = new LiteralControl("&nbsp;...&nbsp;");
                l.RenderControl(writer);
            }
        }

        void RenderLast(HtmlTextWriter writer)
        {

            int totalPages = CalculateTotalPages();

            if (((PageIndex + 3) < totalPages) && (totalPages > 5))
            {
                LiteralControl l = new LiteralControl("&nbsp;...&nbsp;");
                l.RenderControl(writer);

                lastLink.RenderControl(writer);
            }

        }

        void RenderPrevious(HtmlTextWriter writer)
        {
            Literal l;

            if (HasPrevious)
            {
                previousLink.RenderControl(writer);

                l = new Literal();
                l.Text = "&nbsp;";
                l.RenderControl(writer);
            }

        }

        void RenderNext(HtmlTextWriter writer)
        {
            Literal l;

            if (HasNext)
            {

                l = new Literal();
                l.Text = "&nbsp;";
                l.RenderControl(writer);

                nextLink.RenderControl(writer);
            }

        }

        void RenderButtonRange(int start, int end, HtmlTextWriter writer)
        {

            for (int i = start; i < end; i++)
            {

                // Are we working with the selected index?
                //
                if (PageIndex == i)
                {

                    // Render different output
                    //
                    Literal l = new Literal();
                    //l.Text = "<span class=\"currentPage\">[" + (i + 1).ToString() + "]</span>";
                    l.Text = (i + 1).ToString();

                    l.RenderControl(writer);
                }
                else
                {
                    pagingHyperLinks[i].RenderControl(writer);
                }
                if (i < (end - 1))
                    writer.Write(" ");

            }

        }

        void RenderPagingButtons(HtmlTextWriter writer)
        {
            int totalPages;

            // Get the total pages available
            //
            totalPages = CalculateTotalPages();

            // If we have <= 5 pages display all the pages and exit
            //
            if (totalPages <= 5)
            {
                RenderButtonRange(0, totalPages, writer);
            }
            else
            {

                int lowerBound = (PageIndex - 2);
                int upperBound = (PageIndex + 3);

                if (lowerBound <= 0)
                    lowerBound = 0;

                if (PageIndex == 0)
                    RenderButtonRange(0, 5, writer);

                else if (PageIndex == 1)
                    RenderButtonRange(0, (PageIndex + 4), writer);

                else if (PageIndex < (totalPages - 2))
                    RenderButtonRange(lowerBound, (PageIndex + 3), writer);

                else if (PageIndex == (totalPages - 2))
                    RenderButtonRange((totalPages - 5), (PageIndex + 2), writer);

                else if (PageIndex == (totalPages - 1))
                    RenderButtonRange((totalPages - 5), (PageIndex + 1), writer);
            }
        }
        #endregion

        #region ControlTree functions
        void AddPageLinks()
        {
            // First add the lower page buttons
            //
            pagingHyperLinks = new HyperLink[CalculateTotalPages()];

            // Create the buttons and add them to 
            // the Controls collection
            //
            for (int i = 0; i < pagingHyperLinks.Length; i++)
            {
                pagingHyperLinks[i] = new HyperLink();
                pagingHyperLinks[i].EnableViewState = false;
                pagingHyperLinks[i].Text = (i + 1).ToString();
                pagingHyperLinks[i].ID = (i + 1).ToString();
                pagingHyperLinks[i].NavigateUrl = CreatePagerURL((i + 1).ToString());
                Controls.Add(pagingHyperLinks[i]);
            }
        }

        void AddFirstLastLinks()
        {
            int start = 1;
            firstLink = new HyperLink();
            firstLink.ID = "First";
            firstLink.Text = Strings.Utility_Pager_firstButton;
            firstLink.NavigateUrl = CreatePagerURL(start.ToString());
            Controls.Add(firstLink);

            int last = CalculateTotalPages();
            lastLink = new HyperLink();
            lastLink.ID = "Last";
            lastLink.Text = Strings.Utility_Pager_lastButton;
            lastLink.NavigateUrl = CreatePagerURL(last.ToString());
            Controls.Add(lastLink);
        }

        void AddPreviousNextLinks()
        {
            int previous;

            if (this.PageIndex < 2)
                previous = 1;
            else
                previous = this.PageIndex;

            previousLink = new HyperLink();
            previousLink.ID = "Prev";
            previousLink.Text = Strings.Utility_Pager_previousButton;
            previousLink.NavigateUrl = CreatePagerURL(previous.ToString());
            Controls.Add(previousLink);

            int next = this.PageIndex + 2;
            nextLink = new HyperLink();
            nextLink.ID = "Next";
            nextLink.Text = Strings.Utility_Pager_nextButton;
            nextLink.NavigateUrl = CreatePagerURL(next.ToString());
            Controls.Add(nextLink);
        }
        #endregion

        #region Private Properties
        private bool HasPrevious
        {
            get
            {
                if (PageIndex > 0)
                    return true;

                return false;
            }
        }

        private bool HasNext
        {
            get
            {
                if (PageIndex + 1 < CalculateTotalPages())
                    return true;

                return false;
            }
        }
        #endregion

        #region Helper methods and Public Properties
        private string CreatePagerURL(string pageIndex)
        {
            if (!Globals.IsNullorEmpty(UrlPattern))
                return string.Format(UrlPattern, pageIndex);

            if (wtContext.CurrentUri.AbsoluteUri.IndexOf("?") == -1)
            {
                return wtContext.CurrentUri.AbsoluteUri.ToString() + "?PageIndex=" + pageIndex;
            }
            else
            {
                if (wtContext.CurrentUri.AbsoluteUri.IndexOf("PageIndex=") == -1)
                    return wtContext.CurrentUri.AbsoluteUri.ToString() + "&PageIndex=" + pageIndex;
                else
                {
                    return Regex.Replace(wtContext.CurrentUri.AbsoluteUri.ToString(), @"PageIndex=(\d+\.?\d*|\.\d+)", "PageIndex=" + pageIndex);
                }
            }
        }

        string _urlPattern = null;
        public string UrlPattern
        {
            get { return _urlPattern; }
            set { _urlPattern = value; }
        }


        // *********************************************************************
        //  CalculateTotalPages
        //
        /// <summary>
        /// Static that caculates the total pages available.
        /// </summary>
        /// 
        // ********************************************************************/
        public int CalculateTotalPages()
        {
            int totalPagesAvailable;

            if (TotalRecords == 0)
                return 0;

            // First calculate the division
            //
            totalPagesAvailable = TotalRecords / PageSize;

            // Now do a mod for any remainder
            //
            if ((TotalRecords % PageSize) > 0)
                totalPagesAvailable++;

            return totalPagesAvailable;

        }

        public int PageIndex
        {
            get
            {
                int _pageIndex = 0;

                if (wtContext.QueryString["pageindex"] != null)
                    _pageIndex = int.Parse(wtContext.QueryString["pageindex"]) - 1;

                if (_pageIndex < 0)
                    return 0;
                else
                    return _pageIndex;
            }
            set
            {
                ViewState["PageIndex"] = value;
            }
        }

        public int PageSize
        {
            get
            {
                int pageSize = Convert.ToInt32(ViewState["PageSize"]);

                if (pageSize == 0)
                {
                    //return CSContext.Current.SiteSettings.ItemsPerPage;
                    return 100;
                }

                return pageSize;
            }
            set
            {
                ViewState["PageSize"] = value;
            }

        }

        private bool _causeValidation = true;
        public bool CausesValidation
        {
            get { return _causeValidation; }
            set { _causeValidation = value; }
        }

        public int TotalRecords
        {
            get
            {
                return Convert.ToInt32(ViewState["TotalRecords"]);
            }
            set
            {
                ViewState["TotalRecords"] = value;
            }
        }
        #endregion

    }
}
