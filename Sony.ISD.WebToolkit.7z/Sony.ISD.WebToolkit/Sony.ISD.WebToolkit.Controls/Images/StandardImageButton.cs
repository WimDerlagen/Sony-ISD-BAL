using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Sony.ISD.WebToolkit.Components;

namespace Sony.ISD.WebToolkit.Controls
{
    public class StandardImageButton : System.Web.UI.WebControls.ImageButton
    {
        protected override void Render(HtmlTextWriter writer)
        {
            this.ImageUrl = this.ResolveUrl(Globals.ImagePath + this.ImageUrl);
            base.Render(writer);
        }
    }
}
