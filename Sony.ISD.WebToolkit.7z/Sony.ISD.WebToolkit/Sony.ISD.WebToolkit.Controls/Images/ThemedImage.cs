using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Sony.ISD.WebToolkit.Components;
namespace Sony.ISD.WebToolkit.Controls.Images
{
    public class ThemedImage : System.Web.UI.WebControls.Image
    {
        protected override void Render(HtmlTextWriter writer)
        {
            this.ImageUrl = this.ResolveUrl(Globals.GetSkinPath() + this.ImageUrl);
            base.Render(writer);
        }
    }
}
