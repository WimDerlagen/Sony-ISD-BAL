using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace Sony.ISD.WebToolkit.Components.HttpHandlers
{
    [Obsolete]
    public class WTMailLinkHandler : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {

        }

        public bool IsReusable
        {
            get { return false; }
        }
    }
}
