using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Data.Odbc;
using System.Data;
using System.Data.Common;
using System.Collections;
using System.Security;
using System.Security.Principal;
using System.Threading;
using System.Web.Security;
using LumenWorks.Framework.IO.Csv;

namespace Sony.ISD.WebToolkit.Components
{
    public abstract class ImportServiceBase
    {
        private string commandText;
        
        private string connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0; Data Source={0};Extended Properties=""Excel 8.0;HDR=YES;""";
        private string importFilePath = "~/Import";
        private bool hasHeaders = true;
        private char delimiter = ';';

        public virtual string CommandText
        {
            get { return commandText; }
            set { commandText = value; }
        }

        public virtual string ConnectionString
        {
            get { return connectionString; }
            set { connectionString = value; }
        }

        public virtual string ImportFilePath
        {
            get { return importFilePath; }
            set { importFilePath = value; }
        }

        public virtual bool HasHeaders
        {
            get { return hasHeaders; }
            set { hasHeaders = value; }
        }

        public virtual char Delimiter
        {
            get { return delimiter; }
            set { delimiter = value; }
        }

        protected ArrayList ImportExcelDocument()
        {
            bool done = false;
            string conn = string.Format(ConnectionString, ImportFilePath);

            DbProviderFactory factory = DbProviderFactories.GetFactory("System.Data.OleDb");
            ArrayList items = new ArrayList();

            using (DbConnection connection = factory.CreateConnection())
            {
                connection.ConnectionString = conn;

                using (DbCommand command = connection.CreateCommand())
                {
                    // Televisie$ comes from the name of the worksheet
                    // command.CommandText = "SELECT [Employeenr.],[Aanhef],[Naam Employee],[Straatnaam],[Huisnummer],[Toevoeging huisnr.],[Postcode],[Woonplaats],[Woonland Woonadres],[Geboortedatum],[Datum in dienst],[Beroep],[Afdelingsnummer],[Business groep],[FTE],[Functie Omschrijving],[In dienst Sony Corp],[Lang Nationaliteit],[Roepnaam] FROM [Televisie$]";
                    command.CommandText = CommandText;

                    connection.Open();

                    using (DbDataReader dr = command.ExecuteReader())
                    {
                        //Not tested with IDataReader. DbDataReader seems to return an empty record before returning false at Read()
                        while (dr.Read())
                        {
                            object s = PopulateImportObject(dr);

                            items.Add(s);
                            //if (!done)
                            //    items.Add(s);
                            //else
                            //    break;
                        }
                    }
                }
            }

            return items;
        }

        protected ArrayList ImportCSVDocument()
        {
            ArrayList items = new ArrayList();

            using (CsvReader csv = new CsvReader(new StreamReader(ImportFilePath), HasHeaders, Delimiter))
            {
                int fieldCount = csv.FieldCount;
                string[] headers = csv.GetFieldHeaders();

                while (csv.ReadNextRecord())
                {
                    items.Add(PopulateImportObject(csv));
                }

            }

            return items;
 
        }


        //public abstract object PopulateExcelImportObject(DbDataReader reader, out bool done);

        protected abstract object PopulateImportObject(IDataReader reader);


        #region helper methods

        protected int GetIntFromIDataReader(System.Data.IDataReader reader, string field)
        {
            int returnValue = -1;

            try
            {
                returnValue = (int)reader[field];
            }
            catch (System.InvalidCastException invalidCast)
            {
                try
                {
                    returnValue = Convert.ToInt32(reader[field]);
                }
                catch (System.FormatException format)
                {
                    returnValue = 0;
                }
            }

            return returnValue;
        }

        protected decimal GetDecimalFromIDataReader(System.Data.IDataReader reader, string field)
        {
            decimal returnValue = -1;

            try
            {
                returnValue = (decimal)reader[field];
            }
            catch (System.InvalidCastException invalidCast)
            {
                try
                {
                    returnValue = Convert.ToDecimal(reader[field]);
                }
                catch (System.FormatException format)
                {
                    returnValue = 0;
                }
            }

            return returnValue;
        }


        #endregion
    }
}
