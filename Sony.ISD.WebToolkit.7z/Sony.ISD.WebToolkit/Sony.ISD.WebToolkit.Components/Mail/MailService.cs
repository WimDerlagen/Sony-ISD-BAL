using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.ISD.WebToolkit.Mail
{
    public class MailService
    {

        public static void QueueMail(System.Net.Mail.MailMessage mail)
        {

        }
    }
}
