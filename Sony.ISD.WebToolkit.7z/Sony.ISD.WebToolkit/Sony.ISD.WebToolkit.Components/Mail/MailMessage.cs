using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Sony.ISD.WebToolkit.Mail
{
    /// <summary>
    /// This class holds the e-mail template
    /// </summary>
    public abstract class MailMessage
    {
        string mailTemplate;

        /// <summary>
        /// The e-mail template
        /// </summary>
        public string MailTemplate
        {
            get { return mailTemplate; }
            set { mailTemplate = value; }
        }
    }
}
