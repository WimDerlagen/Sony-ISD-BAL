using System;
using System.Collections.Specialized;
using System.IO;
using System.Threading;
using System.Web;
using System.Collections;
using System.Web.Security;

namespace Sony.ISD.WebToolkit.Components
{
    /// <summary>
    /// The WTContext class forms an extension to the HttpContext class. It provides an easy access to application state properties.
    /// </summary>
    public class WTContext
    {
        private HybridDictionary _items = new HybridDictionary();
        private NameValueCollection _queryString = null;
        private string _siteUrl = null;
        private Uri _currentUri;

        bool _isEmpty = false;
        bool _isUrlReWritten = false;
        string _rawUrl;

        HttpContext _httpContext = null;
        DateTime requestStartTime = DateTime.Now;

        private static readonly string dataKey = "wtContextStore";
        #region constructor & init

        protected WTContext(Uri uri, string siteUrl)
        {
            Initialize(new NameValueCollection(), uri, uri.ToString(), siteUrl);
        }

        protected WTContext(HttpContext context)
        {
            this._httpContext = context;
            Initialize(new NameValueCollection(context.Request.QueryString), context.Request.Url, context.Request.RawUrl, GetSiteUrl());
        }

        protected WTContext(HttpContext context, bool includeQS)
		{
			this._httpContext = context;

            if(includeQS)
            {
			    Initialize(new NameValueCollection(context.Request.QueryString), context.Request.Url, context.Request.RawUrl, GetSiteUrl());
		    }
            else
            {
                Initialize(null, context.Request.Url, context.Request.RawUrl, GetSiteUrl());
            }
		}

        private void Initialize(NameValueCollection qs, Uri uri, string rawUrl, string siteUrl)
        {
            _queryString = qs;
            _siteUrl = siteUrl;
            _currentUri = uri;
            _rawUrl = rawUrl;

        }

        /// <summary>
        /// Creates an empty WTContext if the HTTPContext is unavailable
        /// </summary>
        /// <returns></returns>
        public static WTContext CreateEmptyContext()
        {
            WTContext wtContext = new WTContext(new Uri("http://CreateEmptyContext"), "http://CreateEmptyContext");
            wtContext._isEmpty = true;
            SaveContextToStore(wtContext, dataKey);
            return wtContext;
        }

        /// <summary>
        /// Creates an empty WTContext using a sitesettings ID
        /// </summary>
        /// <param name="settingsID"></param>
        /// <returns></returns>
        public static WTContext Create(int settingsID)
        {
            WTContext wtContext = new WTContext(new Uri("http://CreateContextBySettingsID"), "http://CreateContextBySettingsID");
            SaveContextToStore(wtContext, dataKey);
            return wtContext;
        }

        /// <summary>
        /// Creates a WTContext using the HTTPContext
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static WTContext Create(HttpContext context)
        {
            WTContext wtContext = new WTContext(context, true);
            SaveContextToStore(wtContext, dataKey);

            return wtContext;
        }

        /// <summary>
        /// Creates a WTContext using a Uri
        /// </summary>
        /// <param name="uri"></param>
        /// <param name="appName"></param>
        /// <returns></returns>
        public static WTContext Create(Uri uri, string appName)
        {
            WTContext wtContext = new WTContext(uri, appName);
            SaveContextToStore(wtContext, dataKey);
            return wtContext;
        }

        /// <summary>
        /// Creates a WTContext with a HTTPContext
        /// </summary>
        /// <param name="context">The current HTTPContext</param>
        /// <param name="isRewritten">Indicates whether SearchFriendlyUrls are rewritten</param>
        /// <returns></returns>
        public static WTContext Create(HttpContext context, bool isRewritten)
        {
            WTContext wtContext = new WTContext(context);
            wtContext.IsUrlReWritten = isRewritten;
            SaveContextToStore(wtContext, dataKey);
            return wtContext;
        }

        #endregion

        #region Status properties
        /// <summary>
        /// Gets or sets the current Uri
        /// </summary>
        public Uri CurrentUri { get { return _currentUri; } set { _currentUri = value; } }

        /// <summary>
        /// Indicates whether the urls are rewritten
        /// </summary>
        public bool IsUrlReWritten { get { return _isUrlReWritten; } set { _isUrlReWritten = value; } }

        #endregion

        #region Core Properties
        /// <summary>
        /// Simulates Context.Items and provides a per request/instance storage bag
        /// </summary>
        public IDictionary Items
        {
            get { return _items; }
        }

        /// <summary>
        /// Provides direct access to the .Items property
        /// </summary>
        public object this[string key]
        {
            get
            {
                return this.Items[key];
            }
            set
            {
                this.Items[key] = value;
            }
        }

        /// <summary>
        /// Allows access to QueryString values
        /// </summary>
        public NameValueCollection QueryString
        {
            get { return Context.Request.QueryString; }
        }

        /// <summary>
        /// Quick check to see if we have a valid web reqeust. Returns false if HttpContext == null
        /// </summary>
        public bool IsWebRequest
        {
            get { return this.Context != null; }
        }

        /// <summary>
        /// Indicates whether the user is authenticated
        /// </summary>
        public bool IsAuthenticated
        {
            get
            { //return !User.IsAnonymous; 
                return false;
            }
        }

      

        /// <summary>
        /// Gets the current HTTPContext
        /// </summary>
        public HttpContext Context
        {
            get
            {
                return _httpContext;
            }
        }

        /// <summary>
        /// Gets the current siteUrl
        /// </summary>
        public string SiteUrl
        {
            get { return _siteUrl; }
        }

      

        #endregion

        #region Helpers
        /// <summary>
        /// Indicates whether the context is empty
        /// </summary>
        public bool IsEmpty
        {
            get { return _isEmpty; }
        }

        // *********************************************************************
        //  GetGuidFromQueryString
        //
        /// <summary>
        /// Retrieves a value from the query string and returns it as an int.
        /// </summary>
        // ***********************************************************************/
        public Guid GetGuidFromQueryString(string key)
        {
            Guid returnValue = Guid.Empty;
            string queryStringValue;

            // Attempt to get the value from the query string
            //
            queryStringValue = QueryString[key];

            // If we didn't find anything, just return
            //
            if (queryStringValue == null)
                return returnValue;

            // Found a value, attempt to conver to integer
            //
            try
            {

                // Special case if we find a # in the value
                //
                if (queryStringValue.IndexOf("#") > 0)
                    queryStringValue = queryStringValue.Substring(0, queryStringValue.IndexOf("#"));

                returnValue = new Guid(queryStringValue);
            }
            catch { }

            return returnValue;

        }

        // *********************************************************************
        //  GetIntFromQueryString
        //
        /// <summary>
        /// Retrieves a value from the query string and returns it as an int.
        /// </summary>
        // ***********************************************************************/
        public int GetIntFromQueryString(string key, int defaultValue)
        {
            string queryStringValue;


            // Attempt to get the value from the query string
            //
            queryStringValue = this.QueryString[key];

            // If we didn't find anything, just return
            //
            if (queryStringValue == null)
                return defaultValue;

            // Found a value, attempt to conver to integer
            //
            try
            {

                // Special case if we find a # in the value
                //
                if (queryStringValue.IndexOf("#") > 0)
                    queryStringValue = queryStringValue.Substring(0, queryStringValue.IndexOf("#"));

                defaultValue = Convert.ToInt32(queryStringValue);
            }
            catch { }

            return defaultValue;

        }

        /// <summary>
        /// Converts a virtual path to an actual path
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public string MapPath(string path)
        {
            if (_httpContext != null)
                return _httpContext.Server.MapPath(path);
            else
                // Returns System\WOW for non web // return Directory.GetCurrentDirectory() + path.Replace("/", @"\").Replace("~", "");
                return PhysicalPath(path.Replace("/", Path.DirectorySeparatorChar.ToString()).Replace("~", ""));
        }


        public string PhysicalPath(string path)
        {
            return string.Concat(RootPath().TrimEnd(Path.DirectorySeparatorChar), Path.DirectorySeparatorChar.ToString(), path.TrimStart(Path.DirectorySeparatorChar));
        }

        private string _rootPath = null;

        private string RootPath()
        {
            if (_rootPath == null)
            {
                _rootPath = AppDomain.CurrentDomain.BaseDirectory;
                string dirSep = Path.DirectorySeparatorChar.ToString();

                _rootPath = _rootPath.Replace("/", dirSep);


                //logic for alternative filepaths
                //string filePath = Config.FilesPath;

                //if (filePath != null)
                //{
                //    filePath = filePath.Replace("/", dirSep);

                //    if (filePath.Length > 0 && filePath.StartsWith(dirSep) && _rootPath.EndsWith(dirSep))
                //    {
                //        _rootPath = _rootPath + filePath.Substring(1);
                //    }
                //    else
                //    {
                //        _rootPath = _rootPath + filePath;
                //    }
                //}
            }
            return _rootPath;
        }

        private string GetSiteUrl()
        {
            //NOTE: Watch this change. Should be safe, but not tested.
            //Virtualization means urls must be very precise.
            string hostName = _httpContext.Request.Url.Host.Replace("www.", string.Empty);
            string applicationPath = _httpContext.Request.ApplicationPath;

            if (applicationPath.EndsWith("/"))
                applicationPath = applicationPath.Remove(applicationPath.Length - 1, 1);

            return hostName + applicationPath;

        }
        #endregion

        #region State

        private string role = string.Empty;
        public string Role
        {
            get
            {
                if (role == string.Empty)
                {
                    role = QueryString["Role"];

                    if (role == null)
                        role = string.Empty;

                    return role;
                }

                return role;
            }
            set { role = value; }
        }

        private Guid? userId = null;
        /// <summary>
        /// Gets or sets the user id. The getter retreives the userid from the querystring
        /// </summary>
        public Guid? UserID
        {
            get
            {
                if (userId == null)
                {
                    userId = new Guid(QueryString["UserID"]);
                }

                return userId;
            }
            set { userId = value; }
        }


        #endregion


        #region Current

        /// <summary>
        /// Returns the current instance of the wtContext from the ThreadData Slot. If one is not found and a valid HttpContext can be found,
        /// it will be used. Otherwise, an exception will be thrown. 
        /// </summary>
        public static WTContext Current
        {
            get
            {
                HttpContext httpContext = HttpContext.Current;
                WTContext context = null;
                if (httpContext != null)
                {
                    context = httpContext.Items[dataKey] as WTContext;
                }
                else
                {
                    context = Thread.GetData(GetSlot(dataKey)) as WTContext;
                }

                if (context == null)
                {

                    if (httpContext == null)
                        throw new Exception("No wtContext exists in the Current Application. AutoCreate fails since HttpContext.Current is not accessible.");

                    context = new WTContext(httpContext, true);
                    SaveContextToStore(context, dataKey);
                }
                return context;
            }
        }
        

        protected static LocalDataStoreSlot GetSlot(string dataKey)
        {
            return Thread.GetNamedDataSlot(dataKey);
        }

        protected static void SaveContextToStore(WTContext context, string dataKey)
        {
            if (context.IsWebRequest)
            {
                context.Context.Items[dataKey] = context;
            }
            else
            {
                Thread.SetData(GetSlot(dataKey), context);
            }

        }

        public static void Unload()
        {
            Thread.FreeNamedDataSlot(dataKey);
        }


        public void Redirect(string url)
        {
            Context.Response.Redirect(url);
        }


        #endregion
    }
}
