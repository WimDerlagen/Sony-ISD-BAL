using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.ISD.WebToolkit.Components
{
    /// <summary>
    /// Enum to indicate the sort order
    /// </summary>
    public enum SortOrder
    {
        Ascending = 0,
        Descending
    }
}
