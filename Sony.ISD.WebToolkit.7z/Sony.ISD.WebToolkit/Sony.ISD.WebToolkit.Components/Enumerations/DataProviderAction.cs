using System;
using System.Collections.Generic;
using System.Text;

namespace Sony.ISD.WebToolkit.Components
{
    /// <summary>
    /// Used to indicate what the dataprovider should do
    /// </summary>
    public enum DataProviderAction
    {
        /// <summary>
        /// Indicates to do a create action
        /// </summary>
        Create = 1,
        /// <summary>
        /// Indicates to do an update action
        /// </summary>
        Update,
        /// <summary>
        /// Indicates to do a delete action
        /// </summary>
        Delete
    }
}
